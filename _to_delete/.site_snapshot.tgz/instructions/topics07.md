# MLAI401 — Topic 07: Generative & Agentic AI
*(See complete specification in [topic07.md](file:///Volumes/Data/MLAI_Projects/MLAI401/instructions/topic07.md))*

## Overview & Alignment with `topics.md`

```
7. Generative & Agentic AI
   ├── 1. Generative AI & Large Language Models
   │   ├── Next-Token Prediction & Autoregressive Modeling
   │   ├── Prompt Engineering (Zero-shot, Few-shot, Chain-of-Thought)
   │   └── Sampling & Decoding (Temperature, Top-p, Top-k)
   │
   ├── 2. Retrieval-Augmented Generation (RAG)
   │   ├── Dense Embeddings & Vector Space
   │   ├── Cosine Similarity Distance
   │   ├── Document Chunking Strategies
   │   └── Complete RAG Architecture (Retrieve → Augment → Generate)
   │
   ├── 3. Agentic AI & Autonomous Architectures
   │   ├── Tools & Function Calling
   │   ├── Memory (Scratchpad Working Memory vs. Long-Term Vector Memory)
   │   ├── Planning & Task Decomposition (Subgoals, Tree-of-Thoughts)
   │   ├── The ReAct Loop (Thought → Act → Observe → Replan)
   │   └── Multi-Agent Systems (Manager-Worker, Peer-to-Peer, Generator-Critic)
   │
   └── 4. AI Ethics, Safety & Alignment
       ├── Bias, Fairness & Representation
       ├── Hallucination, Grounding & Reliability
       └── Safety Guardrails, Jailbreaks & Prompt Injection
```

Refer to the full specification document at [instructions/topic07.md](file:///Volumes/Data/MLAI_Projects/MLAI401/instructions/topic07.md).
