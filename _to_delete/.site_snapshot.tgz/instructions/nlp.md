### 📋 NLP Claim Verification & Evidence Retrieval Formulation

Formulate the automated fact-checking and retrieval problem across two core NLP paradigms:

```text
Pipeline A: Traditional Statistical NLP
Text → Preprocessing → TF-IDF / Features → Naïve Bayes → Probability / Prediction → Evaluation

Pipeline B: Semantic Retrieval & RAG
Claim → Text Embeddings → Vector Similarity Retrieval → Top-K Evidence → RAG Reasoning & Verdict
```

---

### 1. Traditional NLP Pipeline Formulation

1. **Text Normalization & Preprocessing:**
   - Case folding: $T_{\text{lower}} = \text{lowercase}(T)$
   - Punctuation & special character stripping using regular expressions.
   - Whitespace tokenization: $W = [w_1, w_2, \dots, w_n]$
   - Stopword filtering: $W_{\text{filtered}} = \{w \in W \mid w \notin \text{Stopwords}\}$
   - N-gram feature generation: Unigrams + Bigrams $(w_i, w_{i+1})$.

2. **TF-IDF Feature Representation:**
   - **Term Frequency ($TF$):**
     $$\text{TF}(t, d) = \frac{f_{t,d}}{\sum_{t' \in d} f_{t',d}}$$
   - **Inverse Document Frequency ($IDF$):**
     $$\text{IDF}(t, D) = \log\left(\frac{1 + |D|}{1 + |\{d \in D : t \in d\}|}\right) + 1$$
   - **TF-IDF Vector Formulation:**
     $$\mathbf{x}_d = \left[ \text{TF}(t_1, d) \cdot \text{IDF}(t_1), \dots, \text{TF}(t_{|V|}, d) \cdot \text{IDF}(t_{|V|}) \right]$$
     Normalized via L2-norm: $\mathbf{\hat{x}}_d = \frac{\mathbf{x}_d}{\|\mathbf{x}_d\|_2}$.

3. **Multinomial Naïve Bayes Classifier:**
   - **Prior Probability with Laplace Smoothing:**
     $$P(C_k) = \frac{N_{C_k} + \alpha}{N + \alpha \cdot |C|}$$
   - **Feature Likelihood with Laplace Smoothing ($\alpha=1$):**
     $$P(w_i \mid C_k) = \frac{\sum_{d \in C_k} \text{TF-IDF}(w_i, d) + \alpha}{\sum_{w \in V} \sum_{d \in C_k} \text{TF-IDF}(w, d) + \alpha \cdot |V|}$$
   - **Log-Space MAP Decision Rule (Underflow Prevention):**
     $$\hat{y} = \arg\max_{C_k \in \{\text{SUPPORTS}, \text{REFUTES}, \text{NOT ENOUGH INFO}\}} \left[ \log P(C_k) + \sum_{i=1}^{M} x_i \log P(w_i \mid C_k) \right]$$

4. **Multi-Class Evaluation Metrics:**
   - Accuracy $= \frac{\sum_{k} TP_k}{N_{\text{total}}}$
   - Precision$_k = \frac{TP_k}{TP_k + FP_k}$, Recall$_k = \frac{TP_k}{TP_k + FN_k}$
   - Macro-F1 $= \frac{1}{|C|} \sum_{k=1}^{|C|} \frac{2 \cdot \text{Precision}_k \cdot \text{Recall}_k}{\text{Precision}_k + \text{Recall}_k}$
   - Confusion Matrix $M \in \mathbb{R}^{3 \times 3}$.

---

### 2. Semantic Retrieval & RAG Extension Formulation

1. **Document & Claim Representation in Vector Space:**
   - Map each reference passage $d_j \in \text{Corpus}$ and query claim $q$ to normalized embedding vectors $\mathbf{v}_{d_j}, \mathbf{v}_q \in \mathbb{R}^D$.

2. **Vector Similarity & Evidence Extraction:**
   - **Cosine Similarity:**
     $$\text{sim}(q, d_j) = \frac{\mathbf{v}_q \cdot \mathbf{v}_{d_j}}{\|\mathbf{v}_q\|_2 \|\mathbf{v}_{d_j}\|_2}$$
   - **Top-$K$ Evidence Candidates:**
     $$\mathcal{E}_q = \text{Top-}K_{d_j \in \text{Corpus}} \left( \text{sim}(q, d_j) \right)$$
   - **Evidence Thresholding:**
     If $\max_{d_j} \text{sim}(q, d_j) < \tau$, label stance as $\text{NOT ENOUGH INFO}$ and set evidence ID to $\text{NONE}$.

3. **Retrieval Performance Evaluation:**
   - **Precision@$K$:** Proportion of top-$K$ retrieved passages that are true ground-truth evidence.
   - **Recall@$K$:** Proportion of ground-truth evidence passages successfully retrieved in top-$K$.
   - **Mean Reciprocal Rank (MRR):**
     $$\text{MRR} = \frac{1}{|Q|} \sum_{i=1}^{|Q|} \frac{1}{\text{rank}_i}$$

4. **Evidence-Grounded RAG Reasoning & Stance Synthesis:**
   - Given Claim $q$ and Retrieved Evidence $\mathcal{E}_q$:
     - Compare factual propositions (dates, entities, quantities, relationships).
     - Assign Verdict:
       - $\mathbf{SUPPORTS}$: Evidence directly confirms claim propositions.
       - $\mathbf{REFUTES}$: Evidence directly contradicts claim propositions.
       - $\mathbf{NOT\ ENOUGH\ INFO}$: Evidence is insufficient or top similarity falls below threshold $\tau$.
     - Synthesize concise explanation directly citing factual entities from retrieved evidence.
