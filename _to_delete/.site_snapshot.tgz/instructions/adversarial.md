# MLAI401 - Adversarial Search & Games

## Goal

One **single** Adversarial Search & Games lecture page, `adversarial.html`, that explains how multi-agent competitive environments and game trees are formulated, searched, pruned, evaluated under resource constraints, extended with chance, and solved with Monte Carlo sampling.

Layout: single viewport, concept-first

The page is a fixed-height shell below the navbar, built to need no page scrolling on a normal desktop or projector screen:

* A slim top bar — an "Adversarial Search & Games" breadcrumb and the page title.
* A simple topic selector bar:
  Game Terminology | Minimax & Alpha-Beta | Heuristics & Resource Limits | Chance & Monte Carlo Tree Search | Evaluating Game Search
* A two-column main area below the topic tabs:
  * Concept column (50%, left) — the current step's definition, formal AIMA notation, and a live teaching tip.
  * Illustration column (50%, right) — visual/interactive supporting illustration for the current concept (game tree, pruning badges, evaluation meters, or live interactive game boards).
  * Both columns must remain visually balanced.
  * **Typography consistency:** the Concept and Illustration columns must draw from the same font stack, sizes, weights, and color tokens (Outfit/Plus Jakarta Sans, `--text-primary/secondary/muted`, etc.) — never a stray unstyled control falling back to browser defaults.

┌──────────────────────────────┬──────────────────────────────┐
│          CONCEPT             │        ILLUSTRATION          │
│                              │                              │
│  Concept Selector bar        │                              │
│  Definition                  │     Interactive Game Tree    │
│  AIMA Formula / Notation     │     Dynamic Highlighting     │
│  Teaching Tip                │     Live State / Step Readout│
│                              │                              │
└──────────────────────────────┴──────────────────────────────┘

**Concept Selector:** If the concept selector becomes too long (more than 6) to fit comfortably in one row, wrap the concepts into **two or three balanced rows** rather than shrinking the font size or overcrowding the layout.

---

### Game Terminology & Problem Formulation

Introduce the core terminology and mathematical formulation of adversarial search problems where two or more competitive agents with conflicting utility functions interact in a shared environment.

Include a brief introduction explaining that unlike classical search where an agent plans a full trajectory to a static goal, game playing requires finding a **contingency strategy** that accounts for every possible countermove by an opponent. In teaching tips, show actual game state representations (e.g., `to_move = MAX`, `utility = +1`, `board = { (1,1): 'X', ... }`, `legal_actions = {(1,2), (2,2), ...}`).

| Concept | Definition | AIMA Formula / Notation | Teaching Tip | Illustration Note |
|---|---|---|---|---|
| **Adversarial Environment** | A multi-agent environment where agents have diametrically opposing utility functions (one agent's gain is the opponent's loss). | Multi-agent · Zero-sum: $\sum_i U_i(s) = 0$ | Classical search plans against physics; adversarial search plans against an active mind trying to defeat you. | Show a 2-agent competitive environment diagram (MAX vs. MIN) with opposing utility vectors $(+1, -1)$. |
| **Formal Game Definition** | A game is formally defined as a tuple $\langle S_0, \text{Player}, \text{Actions}, \text{Result}, \text{Is-Terminal}, \text{Utility} \rangle$. | $s_0 \in S$ · $\text{PLAYER}(s)$ · $\text{ACTIONS}(s)$ · $\text{RESULT}(s, a)$ · $\text{TERMINAL-TEST}(s)$ · $\text{UTILITY}(s, p)$ | Contrast with classical search: `GOAL-TEST` is replaced by `TERMINAL-TEST` and `PATH-COST` is replaced by `UTILITY`. | Interactive card showing the 6 formal components with concrete values for a Tic-Tac-Toe / Fig 5.2 state. |
| **Game Tree & Plies** | A tree where nodes represent game states and edges represent legal moves. A ply represents one player's single turn (a half-move). | $\text{depth} = \text{plies}$ · $1 \text{ move} = 2 \text{ plies}$ (MAX + MIN) | In Chess, a "move" is a White turn + Black reply. In AI search trees, each individual decision level is $1 \text{ ply}$. | Display a 3-ply game tree clearly marking Level 0 (MAX root), Level 1 (MIN children), Level 2 (MAX grandchildren), and Terminal leaves. |
| **Zero-Sum vs. General-Sum** | In zero-sum games, the sum of all payoffs is constant for all terminal outcomes. In general-sum games, payoffs can be win-win or lose-lose. | Zero-Sum: $U_{\text{MAX}}(s) = -U_{\text{MIN}}(s)$ · Constant-sum | In zero-sum games, maximizing your payoff is mathematically identical to minimizing your opponent's payoff. | Payoff comparison badge: show a Tic-Tac-Toe win $(+1, -1)$, draw $(0, 0)$, and loss $(-1, +1)$ side by side. |
| **Perfect vs. Imperfect Information** | Perfect information games give full visibility of the entire game state to all players at all times. Imperfect information hides state details. | Perfect: Chess, Go, Tic-Tac-Toe · Imperfect: Poker, Battleship | Perfect information means no hidden cards, fog of war, or dice rolls. | Side-by-side board state vs. hand of cards with hidden opponent values. |
| **Deterministic vs. Stochastic Games** | Deterministic games have definite outcomes for each action; stochastic games incorporate chance elements (dice, card draws). | Deterministic: $\text{RESULT}(s, a) = s'$ · Stochastic: $P(s' \mid s, a)$ | Deterministic games produce tree branches for actions only; stochastic games add chance nodes between decisions. | Show deterministic branching (action $\to$ state) alongside stochastic branching (action $\to$ chance node $\to$ probabilities). |

---

### Minimax & Alpha-Beta Pruning

Explain how players compute optimal decisions by assuming the opponent plays rationally to minimize MAX's outcome, and how Alpha-Beta pruning safely skips subtrees without changing the final decision.

Every algorithm visualizer in this section must feature **step-by-step interactive steppers** (Run/Pause, Prev/Next, Reset), highlighting the current node, backed-up minimax values, current $\alpha$ and $\beta$ intervals, and pruned subtree branches with clear visual badges.

| Concept | Definition | AIMA Formula / Notation | Teaching Tip | Illustration Note |
|---|---|---|---|---|
| **Minimax Value** | The utility for MAX of being in a state, assuming both players play optimally from there to the end of the game. | $\text{MINIMAX}(s) = \begin{cases} \text{UTILITY}(s) & \text{if } \text{TERMINAL}(s) \\ \max_{a} \text{MINIMAX}(\text{RESULT}(s, a)) & \text{if } \text{PLAYER}(s) = \text{MAX} \\ \min_{a} \text{MINIMAX}(\text{RESULT}(s, a)) & \text{if } \text{PLAYER}(s) = \text{MIN} \end{cases}$ | MAX chooses the action leading to the highest value; MIN chooses the action leading to the lowest value. | Full AIMA Fig 5.2 2-ply game tree (root A, children B, C, D; leaves with values 3, 12, 8, 2, 4, 6, 14, 5, 2). Highlight MAX root choosing B ($\text{value}=3$). |
| **Minimax Decision Trace** | Depth-first traversal of the full game tree, propagating leaf utility values upward from children to parents. | $\text{MAX-VALUE}(s) \leftrightarrow \text{MIN-VALUE}(s)$ | Think: bottom-up valuation. Minimax explores leaves first, then backs up the true game-theoretic value. | Interactive stepper tracing post-order DFS node-by-node across all 9 leaves, showing the value assignment at each internal node. |
| **Alpha ($\alpha$) and Beta ($\beta$) Bounds** | $\alpha$ is the best (highest) value MAX can guarantee so far along the path; $\beta$ is the best (lowest) value MIN can guarantee. | $\alpha = \text{best for MAX}$ ($-\infty \text{ init}$) · $\beta = \text{best for MIN}$ ($+\infty \text{ init}$) | $[\alpha, \beta]$ is the active window of viable values. If a node's value falls outside, it cannot influence the root. | Display dynamic $[\alpha, \beta]$ badges floating next to each visited node in the game tree during traversal. |
| **Alpha-Beta Pruning ($\alpha \ge \beta$)** | Halting exploration of a subtree as soon as it is mathematically impossible for that branch to affect the root decision. | $\alpha \ge \beta \implies \text{PRUNE}$ · $\text{v} \ge \beta \implies \text{return } v$ (at MAX) · $\text{v} \le \alpha \implies \text{return } v$ (at MIN) | Pruning does **not** alter the final minimax move or value — it only saves computation by ignoring irrelevant branches. | Step-by-step trace of AIMA Fig 5.7. Show branch $C3$ (value 6) pruned because $C$ already has $\le 2 \le \alpha=3$, and $D2, D3$ pruned because $D1=14 \ge \beta$. Pruned branches grayed out with a red scissor icon. |
| **Move Ordering Impact** | The number of pruned nodes depends heavily on the order in which child actions are examined. | Best ordering: $O(b^{m/2})$ · Random ordering: $O(b^{3m/4})$ · Worst ordering: $O(b^m)$ | Perfect move ordering lets Alpha-Beta search twice as deep in the same amount of time ($b^{m/2} = (\sqrt{b})^m$). | Side-by-side tree comparison: same tree searched Left-to-Right (suboptimal ordering, few prunes) vs. Optimal ordering (maximum prunes). |

---

### Heuristic Evaluation & Resource Limits

Introduce how game-playing programs handle intractable search depths (e.g., Chess with $b \approx 35, m \approx 80 \implies 35^{80}$ states) by replacing terminal tests with depth cutoffs and exact utilities with heuristic evaluation functions.

| Concept | Definition | AIMA Formula / Notation | Teaching Tip | Illustration Note |
|---|---|---|---|---|
| **Depth Cutoff & Real-Time Limits** | Replacing the terminal test with a depth limit $d$ or time constraint, returning an estimated state quality. | $\text{CUTOFF-TEST}(s, \text{depth}) \implies \text{depth} \ge d \lor \text{TERMINAL}(s)$ | Real-time agents must pick a move before their clock runs out; search stops at ply $d$ and estimates the outcome. | Visual game tree truncated with a horizontal "Horizon Line" at depth $d=3$; leaf nodes above the true terminal layer. |
| **Evaluation Function ($\text{EVAL}(s)$)** | An estimate of the expected utility from a non-terminal state, maintaining the relative ordering of terminal values. | $\text{EVAL}(s) = \sum_{i=1}^n w_i f_i(s)$ (Weighted Linear Sum) | A good eval function must agree with true utilities on terminal states and correlate strongly with winning chances. | Interactive chess/checkers feature breakdown: Material score ($w_{\text{queen}}=9, w_{\text{rook}}=5, w_{\text{pawn}}=1$) + Positional features = Total $\text{EVAL}$. |
| **Quiescence Search** | Extending search beyond the cutoff depth for non-quiescent (turbulent) states until positions stabilize. | $\text{QUIESCENT}(s) = \text{True if no active captures/tactics}$ | Evaluating right in the middle of a queen capture blunder gives a disastrously false score; search deeper until the trade finishes. | Show a 2-ply blunder where a simple cutoff evaluates White as $+9$ (took queen), while Quiescence search reveals Black recaptures immediately ($+9 - 9 = 0$). |
| **The Horizon Effect** | When a damaging move by the opponent is delayed beyond the search horizon by making useless stalling moves. | $\text{Search Horizon} = d$ · Inevitable loss pushed to $d+1$ | The agent thinks it avoided losing a piece, but it only delayed the loss while sacrificing secondary pieces. | Step diagram showing a pushed capture across the cutoff boundary with futile checking moves. |
| **Transposition Tables** | A hash table of previously evaluated states and their bounds to prevent redundant re-evaluations in game DAGs. | $\text{Key}(s) = \text{Zobrist Hash}(s) \to \langle \text{depth}, \text{value}, \text{flag}, \text{best\_move} \rangle$ | Games are directed graphs, not trees; identical board states can be reached via transposed move sequences (e.g., 1. e4 e5 2. Nf3 vs 1. Nf3 e5 2. e4). | Graph transposition showing two converging paths into the same board node with a "Cache Hit" badge. |

---

### Chance & Monte Carlo Tree Search (MCTS)

Explain how adversarial search extends to games of chance using Expectiminimax, and how modern AI handles enormous state spaces (like Go) via selective simulation with Monte Carlo Tree Search.

| Concept | Definition | AIMA Formula / Notation | Teaching Tip | Illustration Note |
|---|---|---|---|---|
| **Expectiminimax & Chance Nodes** | Game trees containing chance nodes (circle nodes) that compute the mathematical expectation over all random outcomes. | $\text{EXPECTIMINIMAX}(s) = \sum_{s'} P(s' \mid s, a) \cdot \text{EXPECTIMINIMAX}(s')$ | Chance nodes compute weighted averages, whereas MAX/MIN nodes take extreme values ($\max$ and $\min$). | 3-tier game tree: MAX (triangle $\triangle$) $\to$ CHANCE (circle $\bigcirc$ with dice roll probabilities $1/6, 2/6, 3/6$) $\to$ MIN (inverted triangle $\triangledown$). |
| **Utility Scale & Monotonic Transformations** | Unlike minimax where any monotonic transformation preserves move decisions, expectiminimax requires positive linear transformations. | $U'(s) = a U(s) + b \quad (a > 0)$ · Nonlinear monotonic transforms break expected values | $E[2X] = 2E[X]$, but $E[X^2] \neq (E[X])^2$. Nonlinear scaling changes which chance branch has the highest expected value! | Numerical comparison showing two chance branches where $U \to U^3$ flips the optimal action. |
| **MCTS: Selection & UCB1** | Traversing the tree from the root to a leaf node by selecting children that maximize the Upper Confidence Bound for Trees. | $\text{UCB1}(n) = \frac{U(n)}{N(n)} + C \sqrt{\frac{\ln N(\text{parent})}{N(n)}}$ | Balances **Exploitation** (win rate $\frac{U}{N}$) and **Exploration** (bonus for rarely visited nodes with small $N$). | Interactive UCB1 calculator: adjust $U$, $N$, and $N_{\text{parent}}$ to see the exploitation vs. exploration tradeoff slider. |
| **MCTS: Expansion & Simulation** | Creating a new child node in the tree and running a fast random rollout (default policy) until reaching a terminal state. | $\text{Rollout Policy}: a \sim \text{Uniform}(\text{ACTIONS}(s))$ | MCTS does not need an evaluation function; it estimates state quality simply by playing out games to the end! | Animated playout sequence: node in tree $\to$ rapid random dashed-line descent to a terminal win $(+1)$ or loss $(0)$. |
| **MCTS: Backpropagation & Decision** | Propagating the simulation outcome up the search path to increment visit counts $N$ and accumulate utility $U$. | $N(n) \leftarrow N(n) + 1$ · $U(n) \leftarrow U(n) + \text{result}$ · Action: $\arg\max_a N(\text{child}_a)$ | The final move chosen at the root is the **most visited** child ($\max N$), not necessarily the one with the highest single win rate. | Upward green glow tracing back to root, incrementing badges $N=42 \to 43, U=29 \to 30$ on each ancestor. |
| **Asymmetric Tree Growth** | MCTS dynamically focuses search effort on promising variations while leaving poor moves shallowly explored. | $\text{Tree depth varies per branch}$ ($d_{\text{promising}} \gg d_{\text{poor}}$) | Traditional minimax is symmetric and uniform-depth; MCTS naturally grows deep tentacles where games are contested. | Asymmetric tree diagram showing one deeply explored branch ($N=1500$) alongside pruned/shallow branches ($N=3$). |

---

### Evaluating Game Search Algorithms

Compare game search strategies across time complexity, space complexity, optimality against different opponents, and suitability for real-world games.

| Property | Minimax | Alpha-Beta Pruning (Best Order) | Alpha-Beta (Cutoff + Eval) | Expectiminimax | Monte Carlo Tree Search (MCTS) |
|---|---|---|---|---|---|
| **Time Complexity** | $O(b^m)$ | $O(b^{m/2})$ | $O(b^{d})$ | $O(b^m \cdot n^m)$ ($n$ chance outcomes) | $O(N \cdot \text{length})$ ($N$ rollouts) |
| **Space Complexity** | $O(bm)$ (DFS stack) | $O(bm)$ | $O(bd)$ | $O(bm)$ | $O(\text{Tree Nodes}) \le O(N)$ |
| **Completeness** | Complete (finite trees) | Complete (finite trees) | Complete up to depth $d$ | Complete (finite trees) | Complete as $N \to \infty$ |
| **Optimality vs. Optimal Opponent** | Optimal (guaranteed minimax value) | Optimal (identical to Minimax) | Heuristically bounded | Optimal in expected utility | Converges to Minimax optimal |
| **Optimality vs. Suboptimal Opponent** | Suboptimal (does not exploit blunders) | Suboptimal (does not exploit blunders) | Heuristic | Expected utility | Adapts dynamically to opponent weakness |
| **Dominant Use Cases** | Small games (Tic-Tac-Toe, Connect-3) | Classical board games (Chess, Checkers) | Tournament engines with clock constraints | Backgammon, Monopoly, Pig | Go, Shogi, General Game Playing |

---

### Practice Exercises

Include verified step-by-step practice problems with full mathematical derivations and Mermaid tree diagrams, suitable for student self-testing.

#### Exercise 01: Minimax Value Computation & Propagation

Given the 3-ply zero-sum game tree below where terminal leaf utilities for MAX are provided, calculate the minimax values for all intermediate nodes and state the optimal opening action for MAX.

```mermaid
graph TD
    A["A (MAX)"] --> B["B (MIN)"]
    A --> C["C (MIN)"]
    B --> D["D (MAX)"]
    B --> E["E (MAX)"]
    C --> F["F (MAX)"]
    C --> G["G (MAX)"]
    D --> D1["4"]
    D --> D2["7"]
    E --> E1["2"]
    E --> E2["8"]
    F --> F1["1"]
    F --> F2["5"]
    G --> G1["3"]
    G --> G2["6"]
```

**Solution:**
1. **Level 2 (MAX nodes D, E, F, G):**
   * $\text{Value}(D) = \max(4, 7) = 7$
   * $\text{Value}(E) = \max(2, 8) = 8$
   * $\text{Value}(F) = \max(1, 5) = 5$
   * $\text{Value}(G) = \max(3, 6) = 6$
2. **Level 1 (MIN nodes B, C):**
   * $\text{Value}(B) = \min(\text{Value}(D), \text{Value}(E)) = \min(7, 8) = 7$
   * $\text{Value}(C) = \min(\text{Value}(F), \text{Value}(G)) = \min(5, 6) = 5$
3. **Level 0 (MAX root A):**
   * $\text{Value}(A) = \max(\text{Value}(B), \text{Value}(C)) = \max(7, 5) = 7$
   * **Optimal Action:** MAX chooses move $A \to B$, achieving guaranteed utility $7$.

$$\boxed{\text{Node Values: } D=7, E=8, F=5, G=6 \implies B=7, C=5 \implies A=7 \text{ (Action: } A \to B\text{)}}$$

---

#### Exercise 02: Alpha-Beta Pruning Step-by-Step Trace

Trace the Alpha-Beta search algorithm on the game tree below from left to right. Specify:
1. The backed-up values for every evaluated node.
2. The exact $[\alpha, \beta]$ intervals at each step.
3. Which leaf nodes and subtrees are pruned (never evaluated).

```mermaid
graph TD
    A["A (MAX)"] --> B["B (MIN)"]
    A --> C["C (MIN)"]
    B --> B1["B1 (MAX)"]
    B --> B2["B2 (MAX)"]
    C --> C1["C1 (MAX)"]
    C --> C2["C2 (MAX)"]
    B1 --> L1["3"]
    B1 --> L2["5"]
    B2 --> L3["2"]
    B2 --> L4["9"]
    C1 --> L5["1"]
    C1 --> L6["4"]
    C2 --> L7["8"]
    C2 --> L8["7"]
```

**Solution Trace:**
1. **At root A:** Initialize $[\alpha=-\infty, \beta=+\infty]$. Explore child $B$.
2. **At node B:** $[\alpha=-\infty, \beta=+\infty]$. Explore child $B1$.
3. **At node B1:** $[\alpha=-\infty, \beta=+\infty]$.
   * Leaf $L1=3$: $v = \max(-\infty, 3) = 3$. Update $\alpha = \max(-\infty, 3) = 3$.
   * Leaf $L2=5$: $v = \max(3, 5) = 5$. Update $\alpha = 5$.
   * Return $v=5$ to parent $B$.
4. **At node B:** $v = \min(+\infty, 5) = 5$. Update $\beta = \min(+\infty, 5) = 5$. Active window at $B$ is $[\alpha=-\infty, \beta=5]$.
5. **Explore child B2:** Pass down $[\alpha=-\infty, \beta=5]$.
   * Leaf $L3=2$: $v = \max(-\infty, 2) = 2$. $\alpha = \max(-\infty, 2) = 2$.
   * Leaf $L4=9$: $v = \max(2, 9) = 9$. Since $v=9 \ge \beta=5$, prune or finish. Return $v=9$.
6. **At node B:** $v = \min(5, 9) = 5$. Return $v=5$ to root $A$.
7. **At root A:** $v = \max(-\infty, 5) = 5$. Update $\alpha = \max(-\infty, 5) = 5$. Active window at $A$ is $[\alpha=5, \beta=+\infty]$.
8. **Explore child C:** Pass down $[\alpha=5, \beta=+\infty]$.
9. **Explore child C1:** Pass down $[\alpha=5, \beta=+\infty]$.
   * Leaf $L5=1$: $v = \max(-\infty, 1) = 1$. $\alpha = 5$.
   * Leaf $L6=4$: $v = \max(1, 4) = 4$. Return $v=4$ to parent $C$.
10. **At node C:** $v = \min(+\infty, 4) = 4$. Update $\beta = \min(+\infty, 4) = 4$.
    * **Pruning Condition Check:** $\alpha = 5 \ge \beta = 4$ ($\alpha \ge \beta$).
    * **PRUNE!** The entire remaining subtree of $C$ (node $C2$ and leaves $L7, L8$) is pruned!
11. **At root A:** $v = \max(5, 4) = 5$. Optimal move is $A \to B$ with minimax value $5$.

$$\boxed{\text{Pruned Nodes: } C2, L7 (8), L8 (7) \quad \text{due to } \alpha=5 \ge \beta=4 \text{ at node } C}$$

---

#### Exercise 03: Expectiminimax Decision with Dice Roll

Consider a game where MAX chooses action $a_1$ or $a_2$.
* If MAX chooses $a_1$, a coin is flipped: Heads (probability $0.5$) leads to state with utility $+10$; Tails (probability $0.5$) leads to state with utility $-4$.
* If MAX chooses $a_2$, a 4-sided die is rolled:
  * Roll 1 (prob $0.25$): utility $+20$
  * Roll 2 (prob $0.25$): utility $-10$
  * Roll 3 (prob $0.25$): utility $+4$
  * Roll 4 (prob $0.25$): utility $0$

Calculate the expected utility of chance nodes $C(a_1)$ and $C(a_2)$, and determine MAX's optimal decision.

**Solution:**
1. **Expected Value for Action $a_1$:**
   $$\text{EV}(a_1) = 0.5 \times (+10) + 0.5 \times (-4) = 5.0 - 2.0 = +3.0$$
2. **Expected Value for Action $a_2$:**
   $$\text{EV}(a_2) = 0.25 \times (+20) + 0.25 \times (-10) + 0.25 \times (+4) + 0.25 \times (0) = 5.0 - 2.5 + 1.0 + 0 = +3.5$$
3. **Decision at MAX root:**
   $$\text{Decision} = \arg\max(\text{EV}(a_1), \text{EV}(a_2)) = \arg\max(3.0, 3.5) = a_2$$

$$\boxed{\text{EV}(a_1) = 3.0, \quad \text{EV}(a_2) = 3.5 \implies \text{MAX chooses action } a_2}$$

---

#### Exercise 04: MCTS UCB1 Calculation & Selection Step

In an MCTS search tree, the root node has been visited $N = 100$ times. Three legal actions have the following statistics:
* Action $A_1$: Visited $N_1 = 40$ times, total utility $U_1 = 28$ wins.
* Action $A_2$: Visited $N_2 = 50$ times, total utility $U_2 = 30$ wins.
* Action $A_3$: Visited $N_3 = 10$ times, total utility $U_3 = 8$ wins.

Using the exploration constant $C = \sqrt{2} \approx 1.414$, calculate the UCB1 value for each action and determine which child MCTS will select for the next rollout.

**Formula:**
$$\text{UCB1}(i) = \frac{U_i}{N_i} + C \sqrt{\frac{\ln N}{N_i}}$$
Given $\ln(100) \approx 4.6052$:

**Calculations:**
1. **Action $A_1$:**
   * Exploitation: $\frac{28}{40} = 0.7000$
   * Exploration: $1.414 \times \sqrt{\frac{4.6052}{40}} = 1.414 \times \sqrt{0.11513} = 1.414 \times 0.3393 = 0.4798$
   * $\text{UCB1}(A_1) = 0.7000 + 0.4798 = 1.1798$

2. **Action $A_2$:**
   * Exploitation: $\frac{30}{50} = 0.6000$
   * Exploration: $1.414 \times \sqrt{\frac{4.6052}{50}} = 1.414 \times \sqrt{0.09210} = 1.414 \times 0.3035 = 0.4291$
   * $\text{UCB1}(A_2) = 0.6000 + 0.4291 = 1.0291$

3. **Action $A_3$:**
   * Exploitation: $\frac{8}{10} = 0.8000$
   * Exploration: $1.414 \times \sqrt{\frac{4.6052}{10}} = 1.414 \times \sqrt{0.46052} = 1.414 \times 0.6786 = 0.9596$
   * $\text{UCB1}(A_3) = 0.8000 + 0.9596 = 1.7596$

**Result:** MCTS selects Action $A_3$ because it has the highest UCB1 score ($1.7596$), driven by high win rate combined with a strong exploration bonus due to its low visit count.

$$\boxed{\text{UCB1}(A_1) \approx 1.18, \quad \text{UCB1}(A_2) \approx 1.03, \quad \text{UCB1}(A_3) \approx 1.76 \implies \text{Select } A_3}$$
