# Two-Room Vacuum Robot Demo

## Objective
Create an **interactive visual demo** comparing:
- Table-Driven Agent
- Simple Reflex Agent
- Model-Based Reflex Agent

Keep explanations minimal. Use visualization, state changes, and agent actions.

## Environment
```text
┌─────────────┬─────────────┐
│   Room A    │   Room B    │
│    Dirty    │    Dirty    │
│     🤖      │             │
└─────────────┴─────────────┘
```

- State: `(Location, A Status, B Status)`
- Percept: `(Current Location, Current Room Status)`
- Actions: `Suck | Left | Right | NoOp`
- Score: `+10` per dirty room cleaned; `-1.5` per Left/Right action.
- Complete when both rooms are clean.
- Always show: `Score | Actions | Complete? | Stops?`

## Controls
```text
Agent: [Table-Driven] [Simple Reflex] [Model-Based]
Start: [A Dirty | B Dirty ▼]
[Step] [Run] [Pause] [Reset]
```

- Use the same starting state when comparing agents.
- `Step` performs one action and updates the visualization.

## Visualization
Keep the rooms as the main visualization. Highlight robot location, room status, current percept, selected action, score, and action count.

### Table-Driven
Show the growing percept history:
```text
Percept History
(A, Dirty)
     ↓
   TABLE
     ↓
    Suck
```

### Simple Reflex
Show only the current percept:
```text
(A, Dirty)
     ↓
Dirty → Suck
     ↓
    Suck
```

Do not show memory/history. When both rooms are clean:
```text
Environment: ✓ Complete
Agent:       ? Does not know
```
The agent continues moving because it only observes the current room.

### Model-Based Reflex
Show the internal model:
```text
Agent Model
A: Clean
B: ?
```

Update it after each percept/action:
```text
(B, Dirty)
     ↓
Agent Model
A: Clean
B: Dirty
     ↓
    Suck
```

When both are known clean:
```text
A: Clean ✓
B: Clean ✓
     ↓
    NoOp
```

## Comparison
| Agent | Complete | Actions | Score | Stops |
|---|---:|---:|---:|---:|
| Table-Driven | live | live | live | live |
| Simple Reflex | live | live | live | live |
| Model-Based | live | live | live | live |

Show the action sequence:
```text
Suck → Right → Suck → NoOp
```

Count actions through the first state where both rooms are clean. Show `NoOp` separately as the stopping action.

## Visual Focus
```text
Table-Driven:   History → Table → Action
Simple Reflex:  Current Percept → Rule → Action
Model-Based:    Percept + Memory → Rule → Action
```

- Keep everything in one interactive demo.
- Do not create separate pages.
- Keep environment state and agent knowledge visually distinct.
- Keep controls and metrics visible.
- Prefer visual changes over explanations.
- Keep animations simple.
