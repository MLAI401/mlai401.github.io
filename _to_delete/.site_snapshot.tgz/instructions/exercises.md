### Search Problems

> *Content reference: Artificial Intelligence: A Modern Approach (Russell & Norvig). Style/format reference: this project's own `instructions/search.md` and `instructions/pseudocode.md` — terminology and notation are taken directly from them.*

### Question 01.
A search problem presented by the below graph has start state (START) and goal state (O). Assume successors are considered in alphabetical order. For DFS and IDS, push successors onto the stack in reverse alphabetical order so that they are
popped in alphabetical order.

Using the search graph below, apply each search algorithm (BFS, DFS, IDS, UCS), find expansion order, solution path, and path cost.

```
graph TD
    START((START))

    START -->|5| A((A))
    START -->|1| B((B))

    A -->|4| C((C))
    A -->|3| D((D))

    B -->|1| E((E))
    B -->|5| F((F))

    C -->|4| G((G))
    C -->|3| H((H))

    E -->|1| I((I))
    E -->|4| J((J))

    G -->|3| M((M))
    G -->|2| N((N))

    I -->|1| O((O))
    I -->|3| P((P))

    M -->|3| Q((Q))
    M -->|2| R((R))

    Q -->|3| S((S))
    Q -->|2| T((T))

    S -->|2| U((U))
    S -->|2| V((V))

```

#### Solution

The graph is a **tree**: every node has exactly one parent, so there is only *one* path from START to any node, in particular to the goal O. This means every algorithm below must return the *same* solution path and cost — the only thing that differs between algorithms is the **expansion order** (how much work each one does to find it). That contrast is the whole point of the exercise.

Successor lists (alphabetical order):

```
START: A, B        C: G, H        M: Q, R
A: C, D            E: I, J        Q: S, T
B: E, F            G: M, N        S: U, V
I: O, P            (D, F, H, J, N, O, P, R, T, U, V are leaves)
```

Goal test convention used (matches `instructions/pseudocode.md` and `instructions/search.md`): **BFS uses the early goal test** (a child is tested the moment it is generated); **DFS, IDS and UCS use the late goal test** (a node is tested only after it is popped/selected from the frontier).

**BFS (FIFO queue, early goal test)**

Level by level: {START} → {A, B} → {C, D, E, F} → {G, H, I, J} → early goal test fires the instant O is generated as a child of I (before J, and before O would ever need to be popped).

- Expanded Node Order: `START, A, B, C, D, E, F, G, H, I`
- Solution Path: `START → B → E → I → O`
- Path Cost: `1 + 1 + 1 + 1 = 4`

**DFS (LIFO stack, alphabetical successors, late goal test)**

Because A precedes B alphabetically, DFS plunges all the way down the *entire* A‑subtree — including the long dead‑end chain A → C → G → M → Q → S → U/V/T/R → back up to N, H, D — before it ever tries B. Only after that whole subtree is exhausted does it try B, immediately find the goal.

- Expanded Node Order: `START, A, C, G, M, Q, S, U, V, T, R, N, H, D, B, E, I`
- Solution Path: `START → B → E → I → O`
- Path Cost: `4`

This is a good illustration of why DFS can be badly inefficient even when BFS solves the same problem in far fewer expansions.

**IDS (repeated depth‑limited DFS, ℓ = 0, 1, 2, …)**

O sits at depth 4, so IDS needs 5 iterations (ℓ = 0..4) to reach it:

| ℓ | Nodes selected this iteration | Goal found? |
|---|---|---|
| 0 | START | No |
| 1 | START, A, B | No |
| 2 | START, A, C, D, B, E, F | No |
| 3 | START, A, C, G, H, D, B, E, I, J, F | No |
| 4 | START, A, C, G, M, N, H, D, B, E, I, **O** | Yes |

- Expanded Node Order (final, successful iteration): `START, A, C, G, M, N, H, D, B, E, I`
- Solution Path: `START → B → E → I → O`
- Path Cost: `4`
- Total node selections across *all* iterations: 1 + 3 + 7 + 11 + 12 = 34 — noticeably more work than a single BFS/UCS pass, which is the price IDS pays (repeated shallow re‑exploration) for BFS‑like optimality at DFS‑like memory.

**UCS (priority queue ordered by g(n), late goal test)**

Cumulative costs: g(A)=5, g(B)=1, g(E)=2, g(I)=3, g(O)=4 (and every off‑path node has strictly larger g than the node that eventually reaches O, so it is never selected before O is found).

Expansion trace: select START(0) → expand → frontier {B(1), A(5)}; select B(1) → expand → frontier {E(2), A(5), F(6)}; select E(2) → expand → frontier {I(3), A(5), F(6), J(6)}; select I(3) → expand → generates O(4), frontier {O(4), A(5), F(6), J(6), P(6)}; select O(4) → **goal test succeeds → STOP**.

- Expanded Node Order: `START, B, E, I`
- Solution Path: `START → B → E → I → O`
- Path Cost: `4`

UCS is the cheapest of the four here (only 4 expansions) because low edge costs happen to lie along the true solution path, so "always chase the lowest cumulative cost" beelines straight to the answer.

| Algorithm | Expanded Node Order | Solution Path | Cost |
|---|---|---|---|
| BFS | START, A, B, C, D, E, F, G, H, I | START → B → E → I → O | 4 |
| DFS | START, A, C, G, M, Q, S, U, V, T, R, N, H, D, B, E, I | START → B → E → I → O | 4 |
| IDS | START, A, C, G, M, N, H, D, B, E, I (final iter.) | START → B → E → I → O | 4 |
| UCS | START, B, E, I | START → B → E → I → O | 4 |

⸻

### Question 02: Using an appropriate search graph below, find expansion order, solution path, and path cost for each search algorithm (UCS, Greedy, A*).
```
graph LR
    S((S)) -->|1| A((A))
    S -->|1| B((B))
    A -->|1| C((C))
    B -->|2| C
    C -->|3| G((G))

    S ~~~ HS["h=2"]
    A ~~~ HA["h=4"]
    B ~~~ HB["h=1"]
    C ~~~ HC["h=1"]
    G ~~~ HG["h=0"]
```

#### Solution

Alphabetical order at ties (`A` before `B`).

**(a) UCS** — order by `g(n)`:
```
g(A)=1, g(B)=1 → A first
g(C) = min(g(A)+1, g(B)+2) = min(2,3) = 2   [via A]
g(G) = g(C)+3 = 5
```
`Order: S,A,B,C` · `Path: S→A→C→G` · `Cost: 5`

**(b) Greedy** — order by `h(n)`:
```
h(S)=2 → children h(A)=4, h(B)=1 → B (min h)
h(C)=1 → C
h(G)=0 → G
```
`Order: S,B,C` · `Path: S→B→C→G` · `Cost: 1+2+3 = 6`

**(c) A\*** — order by `f(n)=g(n)+h(n)`:
```
f(A)=1+4=5,  f(B)=1+1=2        → B first
f(C)=g(B)+2+h(C)=3+1=4         → C next  (4<5)
f(G)=g(C)+3+0=6+0=6
pop A(f=5): g(C via A)=1+1=2 < 3 → f(C)=2+1=3, C reopened
f(G) via new C = 2+3+0 = 5 < 6 → update, then G popped
```
`Order: S,B,C,A,C` (C expanded twice) · `Path: S→A→C→G` · `Cost: 5`

| Algorithm | Order | Path | Cost |
|---|---|---|---|
| UCS | S,A,B,C | S→A→C→G | 5 |
| Greedy | S,B,C | S→B→C→G | 6 |
| A* | S,B,C,A,C | S→A→C→G | 5 |

\boxed{h(A)=4 > c(A,C)+h(C)=1+1=2 \;\Rightarrow\; h \text{ admissible but not consistent} \;\Rightarrow\; \text{A* re-expands } C}

⸻

### Search Algorithm Properties

### Question 03: Early Goal Test

Draw a small weighted search graph to illustrate why an Early Goal Test is safe for BFS but not for UCS. Label the start and goal nodes and include edge costs. Use your graph to briefly explain the difference.

#### Solution

```
graph TD
    S((S)) -->|10| G((G))
    S -->|1| A((A))
    A -->|1| G
```

**BFS** (orders by depth only):
```
depth(G) = 1  (direct child of S)
⇒ no node at depth < 1 remains ⇒ early test on G is safe
```

**UCS** (orders by g(n)):
```
generated together: g(A)=1, g(G)=10
early test on G ⇒ reports cost 10
true cost: g(A) + c(A,G) = 1+1 = 2 < 10
late test: pop min(g) = A(1) first ⇒ g(G): 10 → 2 ⇒ G popped at cost 2
```

\boxed{\text{depth cannot decrease after generation, but } g(n) \text{ can} \;\Rightarrow\; \text{early test safe for BFS, unsafe for UCS}}

⸻

### Question 04: Prove the time and space complexity of BFS, DFS, IDS, UCS, A*, Greedy Search using Mathematical Induction.

#### Solution

```
graph TD
    R((root)) --> A1((•))
    R --> A2((•))
    A1 --> B1((•))
    A1 --> B2((•))
    A2 --> B3((•))
    A2 --> B4((•))
```
*(generic branching tree: b children per node, level k holds ≤ b^k nodes)*

`b`=branching factor, `d`=shallowest-goal depth, `m`=max depth, `C*`=optimal cost, `ε`=min step cost.

**Lemma** — `N(k) ≤ b^k` (nodes at level `k`).
```
Base:  N(0) = 1 = b^0
Step:  N(k+1) ≤ b·N(k) ≤ b^{k+1}                                    ∎
```
`Σ_{k=0}^{d} b^k = O(b^d)`.

**BFS** — stops at level `d`: `Time = Space = Σ_{k=0}^{d} b^k = O(b^d)`.

**DFS** — stack size `S(k) ≤ 1+(b-1)k`:
```
Base:  S(0) = 1
Step:  S(k+1) = S(k) - 1 + b ≤ 1+(b-1)(k+1)                          ∎
```
`Space = O(bm)` at depth `m`; `Time = Σ_{k=0}^{m} b^k = O(b^m)`.

**IDS** — `Time = Σ_{ℓ=0}^{d} O(b^ℓ) = O(b^d)` (geometric sum, `b>1` ⇒ dominated by last term). `Space = O(bd)` (one DFS branch live at a time).

**UCS** — layer by cost band `j = ⌊g(n)/ε⌋`; identical Lemma re-indexed by `j`, bounded by `j* = ⌊C*/ε⌋`:
`Time = Space = O(b^{1+⌊C*/ε⌋})`.

**A\*** — admissible `h` gives, for any node `n` on an optimal path, `f(n)=g(n)+h(n) ≤ g(n)+h*(n) = C*`; layering by `⌊f(n)/ε⌋` reuses the same Lemma:
`Time = Space = O(b^{1+⌊C*/ε⌋})` (`h≡0` reduces this exactly to UCS's bound).

**Greedy** — no cost pruning ⇒ worst case matches the DFS/tree bound: `Time = Space = O(b^m)`.

| Algorithm | Time | Space |
|---|---|---|
| BFS | O(b^d) | O(b^d) |
| DFS | O(b^m) | O(bm) |
| IDS | O(b^d) | O(bd) |
| UCS | O(b^(1+⌊C*/ε⌋)) | O(b^(1+⌊C*/ε⌋)) |
| Greedy | O(b^m) | O(b^m) |
| A* | O(b^(1+⌊C*/ε⌋)) | O(b^(1+⌊C*/ε⌋)) |

\boxed{N(k) \le b^k \;\Rightarrow\; \text{every row above is the same induction, re-indexed by depth or cost band}}

⸻

### Question 05: Using proof by contradiction, prove that A* is cost-optimal.

#### Solution

```
graph TD
    S((S)) -->|2| n((n))
    n -->|3| G1((G1))
    S -->|8| G2((G2))
```
`h(n)=2` (admissible: true remaining cost `h*(n)=3`, and `2≤3`).

*Assume* A* selects `G2` first, with `g(G2)=8 > C*=5` (`C*` via `S→n→G1`).

`n` lies on the optimal path, so:
```
g(n) + h*(n) = C*  =  2 + 3 = 5
```
Admissibility (`h(n) ≤ h*(n)`):
```
f(n) = g(n)+h(n) ≤ g(n)+h*(n) = C* = 5
```
Since `h(G2)=0`: `f(G2) = g(G2) = 8`. So:
```
f(n) ≤ 5 < 8 = f(G2)
```
A* always pops `min f` next, so `n` (or lower) pops before `G2` — **contradicts** `G2` being selected first.

\boxed{f(n) \le C^* < f(G_2) \;\Rightarrow\; \text{contradiction} \;\Rightarrow\; \text{A* is cost-optimal}}

⸻

### Question 06: Prove that IDS is Optimal only if all cost steps are equal.

#### Solution

Equal step cost `c`: `cost(path) = c · depth(path)`, so `d₁<d₂ ⟹ c·d₁ < c·d₂` — shallowest ⟺ cheapest, and IDS always returns the shallowest goal.

Counterexample when costs differ:
```
graph TD
    S -->|10| G1((G1))
    S -->|1| A((A))
    A -->|1| G2((G2))
```
```
ℓ=1: IDS finds G1 first → cost 10 → returns it, stops
true optimum: G2, cost 1+1 = 2
10 > 2  ⇒  IDS is not optimal here
```

\boxed{\text{cost} = c\cdot\text{depth} \iff \text{shallowest} = \text{cheapest} \iff \text{IDS optimal}}

⸻

### Question 07: Prove that UCS is complete and optimal.

#### Solution

```
graph TD
    S((S)) -->|2| n((n))
    n -->|3| G((G))
    S -->|8| G2((G2))
```
Assume `b` finite, every step cost `≥ ε > 0`.

**Completeness.** Nodes with `g(n) ≤ K` number at most `b^{1+⌊K/ε⌋}` (finite, for finite `K`). A goal at finite cost `C*` therefore lies in a finite region UCS fully explores in finite time.

**Optimality (contradiction).** Suppose UCS selects `G2` with `g(G2)=8 > C*=5` (`C*` via `S→n→G`). `n` is on the optimal path:
```
g(n) = 2 ≤ C* = 5 < 8 = g(G2)
```
UCS always pops `min g` next, so `n` pops before `G2` — contradiction.

\boxed{g(n) \le C^* < g(G_2) \;\Rightarrow\; \text{contradiction} \;\Rightarrow\; \text{UCS complete (finite } b,\ \varepsilon>0\text{) and cost-optimal}}

⸻

### Question 08: Prove that DFS is not cost optimal.

#### Solution

```
graph TD
    S -->|10| A
    A -->|0| G1((G1))
    S -->|1| B
    B -->|1| G2((G2))
```
Alphabetical order: `A` before `B`.
```
pop S → push B,A (A on top) → pop A → expand → generates G1
pop G1 → goal test succeeds → STOP
```
```
DFS returns:  S→A→G1,  cost = 10+0 = 10
true optimum: S→B→G2,  cost = 1+1  = 2
```
`10 > 2` and `B, G2` are never even visited.

\boxed{10 > 2 \;\Rightarrow\; \text{DFS is not cost-optimal}}
