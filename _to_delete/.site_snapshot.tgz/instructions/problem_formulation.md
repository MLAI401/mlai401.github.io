Problem Formulation Page

A lecture illustration page for Problem Formulation, at problem_formulation.html.
It is not a running demo — it never runs BFS/DFS/UCS/A*, and never mentions a
frontier or node expansion. Linked from the Curriculum page: on the Topic 01
card, the icon + "Topic 01" badge and the "Problem Formulation" title are both
links straight to this page (no separate "Open" list row).

Layout: single viewport, concept-first

The page is a fixed-height shell below the navbar, built to need no page
scrolling on a normal desktop or projector screen:

* A slim top bar — a "Curriculum" breadcrumb and the page title.
* A two-column main area below the top bar:
  * Concept column (50%, left) — a 9-step concept tab bar
    (flow-progress-bar), wrapped into two balanced rows so it fits the
    half-width column, followed by the current step's definition, formal
    notation, and a live teaching tip. The tab bar is the page's PRIMARY
    navigation: clickable, and steppable with Prev/Next buttons or the
    Left/Right arrow keys.
  * Illustration column (50%, right) — visual/supporting illustration
    for the current concept.
  * Both columns are the same size and must remain visually balanced.

Below ~900px width or ~640px height the layout falls back to a normal
scrolling single-column stack, since nine concepts will not fit one small
screen. No unnecessary animation.

Concepts (the 9 tab steps, in order)

1. State
2. State Space
3. Abstraction
4. Initial State
5. Actions
6. Transition Model
7. Goal / Goal Test
8. Step Cost / Path Cost
9. Formulated Problem — closing step. Assembles the pieces above into one
   summary for whichever example is selected. The page ends here — still no
   search.
**Concept Selector:** Wrap the concepts into **two balanced rows** rather than shrinking the font size or overcrowding the layout.

Each step (2–9, minus 3) renders the same shape: a one- or two-sentence
definition, the AIMA formal notation in a formula box, and a teaching tip
that pulls REAL, LIVE values from whichever example is currently selected
(current state, current legal actions, the last RESULT(s,a) actually
computed from a click, whether the current state passes the goal test,
actions taken so far). Step 3, Abstraction, is the exception: the Real World
→ Remove Irrelevant Detail → State diagram fills the concept column itself
for that one step, since the diagram IS the concept there, not a side
illustration.

Examples

Four, not one — Two-Room Vacuum World, 8-Puzzle, Maze, and Find Path. Only
one is shown at a time; each keeps its own persistent, independent state, so
switching examples and back never loses progress. Switching the example
never changes which concept step is being taught.

The example switch is a small, secondary control INSIDE the illustration
column — below the concept tab bar, above the illustration itself: a
compact 2×2 grid of buttons, not a prominent top-level tab row.

* Two-Room Vacuum World — state (Location, RoomA, RoomB); actions Suck /
  Left / Right (always legal, Suck just has no effect if already clean);
  goal = both rooms Clean; unit step cost. Reuses VacuumEnvironment from
  demos/vaccum_demo/environment.js, so the numbers match the Playground.
* 8-Puzzle — state = arrangement of 9 tiles (blank = 0); actions move the
  blank Up/Down/Left/Right, legality depends on the blank's position; goal
  = fixed solved arrangement; unit step cost. Reuses PuzzleState from
  demos/puzzle_demo/puzzle.js. Clicking a tile adjacent to the blank slides
  it in.
* Maze — a small 5×5 grid (18 open cells, 7 walls) with a fixed start and
  goal; state = (row, col); actions move into an open, in-bounds cell;
  clicking an adjacent open cell moves there directly; unit step cost.
  Defined as a small local grid in the page's own script — independent of
  the search-focused maze_demo, since this page never runs a search over
  it.
* Find Path — route-finding on a small weighted map of 8 cities (A–H, the
  same road network as the Search & Planning route-finding demo, kept as an
  independent copy so this page never loads that demo's search code);
  state = current city; actions = Go(x) for each outgoing road, clicked
  directly; goal = reach city H. The one example where step cost is NOT a
  flat 1 — it's the road's distance — so "actions taken" and "path cost so
  far" genuinely diverge here, unlike the other three.

Abstraction

Step 3 illustrates, per selected example:

Real World → Remove irrelevant detail → State representation

Each example lists a few real-world details that are dropped (crossed out)
against the few that are kept, then the resulting formal state. E.g. for
the Vacuum World: robot color, battery %, room temperature, and furniture
layout are dropped; which room the robot is in and whether each room is
dirty are kept, producing s = (Location, RoomA, RoomB).

Presentation notes

* Prefer illustrations over paragraphs; short definitions, formula boxes,
  teaching tips — no long prose.
* Follows the existing site theme and navbar (glass panels, gradients,
  Outfit/Plus Jakarta Sans fonts).
* **Typography consistency:** the Concept and Illustration columns must
  draw from the same font stack, sizes, weights, and color tokens
  (Outfit/Plus Jakarta Sans, `--text-primary/secondary/muted`, etc.) —
  never a stray unstyled control quietly falling back to the browser
  default font. Neither column should read as more prominent than the
  other purely because of type choices.
* All interaction is click-based (no typing); Left/Right arrow keys move
  between concept steps only, never between examples or within an
  illustration, to avoid clashing with example interaction.
