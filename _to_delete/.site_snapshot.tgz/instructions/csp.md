# MLAI401 - Constraint Satisfaction Problems (Topic 04)

## Goal

One **single** Constraint Satisfaction lecture page, `csp.html`, that explains how a problem is described as a set of **variables, domains and constraints**, how constraint propagation shrinks the domains before (and during) search, how backtracking search with ordering heuristics and inference finds a solution, how local search (min-conflicts) repairs complete assignments, and how the **structure** of the constraint graph makes some CSPs easy.

Content reference: *Artificial Intelligence: A Modern Approach* (AIMA, 4th ed.), **Chapter 6 — Constraint Satisfaction Problems** (§6.1–6.5).

Deliverables (same structure as Topics 02 and 03):

| File | Role |
|---|---|
| `csp.html` | Single-viewport lecture page (concept column + illustration column) |
| `demos/csp_demo/csp_engine.js` | Zero-dependency CSP engine shared by the lecture page and the playground (`window.CSPEngine`) |
| `demos/csp_demo/ui.js` | Lecture page controller — topic tabs, concept chips, illustrations, steppers |
| `demos/csp_demo/csp_lab.js` | Playground controller for `playground.html#view-csp` |
| `python_sandbox/csp.py` | Project scheduler code; its `backtracking_search` is traced in the Code Trace topic |
| `python_sandbox/07_CSP_Heuristics.py` | Standalone Australia / n-queens implementations of MRV + Degree, LCV, forward checking, AC-3 (MAC), min-conflicts and the efficiency comparison — the code traced in the Code Trace topic |
| `topic04_reading.html` | Textbook-style reading notes + practice exercises |
| `curriculum.html` | Topic 04 card links to lecture, reading notes and playground |

Layout: single viewport, concept-first — identical shell to `adversarial.html`:

* Slim top bar — Curriculum breadcrumb, `Topic 04` badge, title, **Reading Notes** and **Interactive Demo** buttons.
* Topic selector bar:
  Search → Games → CSP | CSP Formulation | Constraint Propagation | Backtracking Search | Local Search & Structure | Evaluating CSP Solvers | Code Trace
* Two-column main area (50 / 50):
  * Concept column — topic intro, concept chips (wrapped into balanced rows when > 3), Definition, AIMA notation, Teaching Tip.
  * Illustration column — interactive or static illustration of the current concept.
* **Notation is written in HTML/Unicode** (subscripts, ∈, ≠, ⟨ ⟩, →) — never raw LaTeX strings, because the site does not load a math renderer.
* **Typography consistency:** both columns use the site tokens (Outfit / Plus Jakarta Sans, `--text-primary/secondary/muted`, `--border-light`). Topic 04 accent colour: teal `#0d9488`.
* Running example throughout: **Map colouring of Australia** (AIMA Fig 6.1) — variables `WA, NT, Q, NSW, V, SA, T`, domain `{red, green, blue}`, constraints `adjacent regions ≠`.

┌──────────────────────────────┬──────────────────────────────┐
│          CONCEPT             │        ILLUSTRATION          │
│  Concept chips               │  Australia map / constraint  │
│  Definition                  │  graph / domain table /      │
│  AIMA notation               │  stepper with readout        │
│  Teaching Tip                │                              │
└──────────────────────────────┴──────────────────────────────┘

---

### 1. CSP Formulation

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Variables, Domains, Constraints** | A CSP is a triple of variables, their domains, and constraints that restrict the combinations of values. | `⟨X, D, C⟩` · `X = {X₁…Xₙ}` · `Dᵢ` · `Cⱼ = ⟨scope, rel⟩` | A CSP is a *factored* representation: a state is a set of variable/value pairs, not a black box. | Switchable example cards: Map colouring · Course scheduling · Sudoku, each showing X, D, C concretely. |
| **Assignments & Solutions** | An assignment gives values to some (partial) or all (complete) variables; it is consistent if it violates no constraint. A solution is complete **and** consistent. | `{WA=red, NT=green}` · consistent · complete · solution | Colour the map yourself — the readout tells you whether the assignment is partial/complete and consistent. | Click-to-colour Australia map; conflicting borders flash red; status badges. |
| **Constraint Graph** | Nodes are variables; an edge joins two variables that share a constraint. | `G = (X, E)`, `(Xᵢ, Xⱼ) ∈ E ⇔ ∃ C with scope {Xᵢ, Xⱼ}` | Tasmania has no edges — an independent subproblem. SA has degree 5 — the hardest region. | Map and constraint graph side by side; hovering a region highlights its node & edges. |
| **Constraint Types** | Unary (one variable), binary (two), global / higher-order (any number, e.g. *Alldiff*). | `⟨(SA), SA ≠ green⟩` · `⟨(SA,WA), SA ≠ WA⟩` · `Alldiff(F,T,U,W,R,O)` | Every finite-domain constraint can be turned into binary constraints (dual graph / auxiliary variables). | Four example cards with arity badges. |
| **Hard vs. Soft Constraints** | Hard constraints must hold (feasibility); soft (preference) constraints carry a cost — a *constraint optimisation problem* (COP). | `solution ⊨ all hard C` · minimise `Σ wₖ · penaltyₖ` | Timetabling: no double-booking is hard; "Dr. X prefers mornings" is soft. | H1–H6 / S1–S5 checklist from the course-scheduling problem below. |
| **CSP as a Search Problem** | Incremental formulation: initial state `{}`, action = assign one unassigned variable, goal = complete consistent assignment. | naïve tree leaves `n!·dⁿ` · commutativity → `dⁿ` | Because assignment order does not matter, we only branch on **one** variable per level. | Calculator: n, d → naïve vs. commutative leaves. |

### 2. Constraint Propagation (Inference)

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Node Consistency** | Every value in a variable's domain satisfies its unary constraints. | `∀ x ∈ Dᵢ : C(Xᵢ = x)` | Pre-filter rooms that are too small / slots the instructor cannot teach. | Scheduling domain grid; "Apply node consistency" strikes out values. |
| **Arc Consistency** | `Xᵢ` is arc-consistent w.r.t. `Xⱼ` if every value in `Dᵢ` has some supporting value in `Dⱼ`. | `REVISE(Xᵢ, Xⱼ)` · AIMA: `Y = X²`, `X, Y ∈ {0…9}` | Arc consistency is directional: revise X→Y and Y→X separately. | Buttons revise X→Y / Y→X on the `Y = X²` example. |
| **AC-3 Algorithm** | Queue of arcs; revise each; when `Dᵢ` shrinks, re-queue all `(Xₖ, Xᵢ)`. | `O(c·d³)` · returns false on empty domain | AC-3 on WA=red, Q=green detects failure **before** any search. | Stepper: queue, current arc, domains on the map. |
| **Path & k-Consistency** | Path consistency checks triples; k-consistency: any consistent k−1 assignment extends to a kth variable. | `{Xᵢ, Xⱼ} path-consistent w.r.t. Xₘ` | Two-colouring the WA-NT-SA triangle is arc-consistent but has no solution — path consistency catches it. | Triangle with 2 or 3 colours toggle. |
| **Global Constraints** | Special-purpose propagation for n-ary constraints such as `Alldiff` and `Atmost`. | `Alldiff: m vars, n values, m > n ⇒ fail` | Pigeonhole reasoning finds inconsistency immediately. | Pigeonhole counter. |
| **Sudoku as a CSP** | 81 variables, domain {1..9}, 27 Alldiff constraints. | `Alldiff(row)`, `Alldiff(col)`, `Alldiff(box)` | Easy Sudokus are solved by AC-3 alone. | 4×4 Sudoku with step / run AC-3. |

### 3. Backtracking Search

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Backtracking Search** | Depth-first search that assigns one variable at a time and backs up when no legal value remains. | `BACKTRACK(assignment, csp)` (AIMA Fig 6.5) | Pure backtracking = DFS + consistency check. | **Map colouring \| Timetable (easy) \| Timetabling** switch (easy timetable described in §6). Map: stepper on Australia with trace log (default fixed order WA, NT, Q, NSW, V, SA, T). Timetabling: the mini timetable below — rooms × slots grid (tried value dashed, clashing course outlined red), course table (instructor, cohort, current domain size, assignment) and log; same variable-order / value-order / inference selectors (course order: 8 assignments, 2 backtracks). |
| **MRV (Minimum Remaining Values)** | Choose the variable with the fewest legal values ("fail-first"). | `argminᵥ |legal(v)|` | After WA=red, NT=green, SA has only blue → choose SA. | Remaining-values badges on the map. |
| **Degree Heuristic** | Tie-breaker: choose the variable involved in the most constraints on unassigned variables. | `argmaxᵥ |{u unassigned : (u,v) ∈ E}|` | At the start every region has 3 values; SA has degree 5. | Degree badges. |
| **LCV (Least-Constraining Value)** | Try the value that rules out the fewest choices for neighbours. | `argmin_x Σ_{u∈N(v)} ruled_out(u, x)` | Variable: fail-first. Value: fail-last. | Q=red vs Q=blue comparison. |
| **Forward Checking** | After `X = x`, delete inconsistent values from every unassigned neighbour. | AIMA Fig 6.7 | Stops when a domain empties — but misses NT/SA both {blue}. | Fig 6.7 domain table stepper. |
| **MAC** | Maintaining Arc Consistency — run AC-3 on arcs `(Xⱼ, Xᵢ)` after every assignment. | `MAC = BACKTRACK + AC-3` | Strictly stronger than forward checking. | FC vs MAC side-by-side. |
| **Conflict-Directed Backjumping** | Jump back to the most recent variable in the conflict set instead of the chronologically last one. | `conf(Xⱼ) ← conf(Xⱼ) ∪ conf(Xᵢ) − {Xⱼ}` | With order Q, NSW, V, T, SA: SA fails → jump to V, not T. | Chronological vs backjump arrows. |

### 4. Local Search & Problem Structure

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Min-Conflicts** | Start from a complete assignment; repeatedly pick a conflicted variable and give it the value with the fewest conflicts. | `MIN-CONFLICTS(csp, max_steps)` (AIMA Fig 6.8) | Solves million-queens in ~50 steps on average. | 8-queens stepper with conflict counts. |
| **Plateaus & Constraint Weighting** | Sideways moves and weights on constraints help escape plateaus. | `wᵢ ← wᵢ + 1` for violated constraints | Weights focus search on hard constraints. | Conflict history chart. |
| **Independent Subproblems** | Connected components can be solved separately. | `O(d^c · n/c)` vs `O(dⁿ)` | n=80, c=20, d=2: 4·2²⁰ vs 2⁸⁰. | Calculator. |
| **Tree-Structured CSPs** | Topological sort + directional arc consistency backward + assignment forward. | `TREE-CSP-SOLVER` · `O(n·d²)` | No backtracking needed on a tree. | Stepper on AIMA Fig 6.10 tree. |
| **Cutset Conditioning** | Assign a cycle cutset S, solve the remaining tree for each assignment. | `O(d^c · (n−c)·d²)` | Removing SA makes Australia a tree. | Toggle SA → graph becomes tree. |
| **Tree Decomposition** | Cover the graph with overlapping subproblems arranged as a tree. | tree width `w` · `O(n·d^{w+1})` | Australia decomposes into triangles around SA. | AIMA Fig 6.13 decomposition. |

### 5. Evaluating CSP Solvers

| Property | Backtracking | + MRV / Degree / LCV | + Forward Checking | MAC (AC-3) | Min-Conflicts | Tree-CSP Solver |
|---|---|---|---|---|---|---|
| Complete | Yes | Yes | Yes | Yes | No | Yes (trees) |
| Worst-case time | `O(dⁿ)` | `O(dⁿ)` | `O(dⁿ)` | `O(dⁿ)` | unbounded | `O(n·d²)` |
| Space | `O(n)` | `O(n)` | `O(n·d)` | `O(n·d)` | `O(n)` | `O(n·d)` |
| Detects failure early | No | Partly | Empty neighbour domain | Any arc inconsistency | — | Yes |
| Best for | Tiny problems | General CSPs | General CSPs | Tight problems (Sudoku) | Large loose problems (n-queens, scheduling repair) | Tree-structured graphs |

Illustrations: (a) **live benchmark** that runs every configuration on Australia, 8-queens and a random 20-region map and reports assignments, backtracks and constraint checks; (b) complexity table; (c) properties table.

### 6. Code Trace (`csp.html#code`)

Goal: students read the actual Python and watch each line run. Every concept is a line-by-line stepper modelled on the CPP201 "Trace the Code" demo.

Layout (differs from the other topics):

* **Concept column** — topic intro, concept chips, then the **Python source** (line numbers, `→` arrow + highlight on the lines executing in the current step; the panel auto-scrolls to the active line). Definition / AIMA notation / Teaching Tip boxes are **not shown** on this topic (the code replaces them; the texts are kept in `CODE_CONCEPTS` for reference).
* **Illustration column** — preset selector, toolbar (`Step k of N`, ← Prev, Next →, ▶ Run / Pause, ↻ Reset), step name, **state panel** (map + concept-specific tables) and a **What's happening?** box. A one-line summary of the whole run sits underneath.
* Shared renderer: `renderCodeTrace()` in `demos/csp_demo/ui.js`; one trace generator per concept (`traceBacktrackingCode`, `traceMRV`, `traceLCV`, `traceFC`, `traceAC3`, `traceMinConflicts`) that returns `{ lines, kind, title, explain, …state }` steps.

| Concept (chip) | Code traced | Presets | State panel | Key point |
|---|---|---|---|---|
| **Backtracking Code Trace** (Map colouring \| Timetable (easy) \| Timetabling switch) | `backtracking_search` in `python_sandbox/csp.py` | Map: orders WA, NT, Q, NSW, V, SA, T (default, 8 calls, 0 backtracks) · WA, NSW, NT, Q, SA, V, T (13 calls, 5 backtracks) · SA first (8 calls, 0 backtracks). Timetabling: course-list order (9 calls, 2 backtracks) · MA101, MA201 first (7 calls, 0 backtracks) | Map (value being tried is tinted, clashes marked) or timetable grid (tried (slot, room) dashed, clashing course outlined, reason H1/H3/H5 in the explanation) · call stack (one frame per `backtrack()` call) · `assignment`, `nodes_expanded`, `backtracks` | A backtrack is a recursive call returning `None`; the caller unassigns and tries the next value. |
| **MRV + Degree** | `mrv()` — legal-value count, `min_size`, `candidates`, degree tie-breaker | `{}` · WA = red · WA = red, NT = green | Map with legal-value badges · table Var / legal colours / # / degree / role (candidate, ★ chosen) | Empty assignment: 7-way tie on 3 values → degree picks SA (degree 5). WA = red, NT = green: SA is the only variable with 1 legal value. |
| **LCV** | `lcv()` — `ruled_out(val)` per neighbour, `sorted(..., key=ruled_out)` | D(Q) after WA = red, NT = green (FC domains) · D(NSW) after WA = red, NT = green, Q = red · D(SA) with empty assignment | Map with domain dots · table value / neighbours hit / count · final order chips | Q = red rules out 1, Q = blue rules out 2 → try red first. Ties keep the original order (stable sort). |
| **Forward Checking** | `forward_checking()` | AIMA Fig 6.7: WA = red, Q = green, V = blue · WA = red, NT = green, Q = red | Map with domain dots + arrow to the neighbour being checked · Fig 6.7-style domain table (one row per assignment, live row during the call) | After V = blue, D(SA) = ∅ → `return False` before SA is ever tried. FC misses NT = SA = {blue}. |
| **AC-3** | `ac3()` + `revise()` (appends re-queued arcs without de-duplication, exactly as written) | WA = red, Q = green (16 arcs popped → False) · WA = red (24 → True) · WA = red, SA ≠ green (36 → True, fully solved domains) | Map with domain dots + current arc · queue chips (next arc outlined, re-queued arcs amber) · revise table x / supporting y | AC-3 detects the WA = red, Q = green dead end with no search. `mac()` = AC-3 on arcs into the variable just assigned. |
| **Min-Conflicts** | `min_conflicts()` — greedy complete start, then repair loop | Seeds 1, 2, 3 (6, 2 and 1 repair moves) | Map with full assignment + conflicting borders · `current`, `conflicted`, conflicting borders, `nodes_expanded` · value → conflicts table | The page uses a seeded JS RNG, so choices differ from Python's `random`; the algorithm is identical. |
| **Compare Efficiency** | `measure()`, `SOLVERS`, `compare()` | Australia · Australia with order WA, NSW, NT, Q, SA, V, T · 8-Queens · 20-Queens · random 30-region map | Table: solver / solved / nodes visited (log bar) / backtracks / time (ms), measured live with `performance.now()` (averaged over 20 runs when < 5 ms) on the shared JS engine | 20-Queens: basic backtracking ≈ 199,636 nodes vs 28 (MRV/Degree + LCV + FC) and 21 (MAC). |

#### Mini timetable (Backtracking Search + Backtracking Code Trace)

A small version of the course-scheduling CSP so every step fits on screen (`TT` in `demos/csp_demo/ui.js`):

* **Slots:** Mon 09:00, Mon 10:30, Tue 09:00, Tue 10:30 · **Rooms:** HALL (120, lecture), R101 (60, lecture), LAB1 (30, lab).
* **Courses (variables):** CS101 (110, Chen, Y1) · CS101L (lab, 28, Chen, Y1) · MA101 (55, Patel, Y1) · CS201 (58, Chen, Y2) · CS201L (lab, 30, Garcia, Y2) · MA201 (45, Patel, Y2).
* **Domains:** node-consistent `(slot, room)` pairs — H2 (capacity & room type) and H4 (Chen unavailable Tue 10:30, Patel unavailable all Tuesday) already applied → |D| = 3, 3, 4, 6, 4, 4.
* **Binary constraints:** H1 same room & slot · H3 same instructor & slot · H5 same cohort & slot (`ttReason()` names the violated one).

#### Timetable (easy) (Backtracking Search + Backtracking Code Trace)

Third option in the **Map colouring | Timetable (easy) | Timetabling** switch (`TTE` in `demos/csp_demo/ui.js`):

* Four courses — CS101, CS102, CS201, CS202 — each need a time slot from {9:00 AM, 10:30 AM, 1:00 PM}.
* CS101 & CS102 share an instructor; CS102 & CS201 share students; CS201 & CS202 share an instructor → these pairs must be at different times (constraint graph = chain CS101 — CS102 — CS201 — CS202).
* CS202's instructor is unavailable at 1:00 PM → unary constraint, applied to the domain (D(CS202) = {9:00 AM, 10:30 AM}).
* View: constraint graph (nodes coloured by slot: 9:00 red, 10:30 green, 1:00 blue; unassigned nodes show their domain), edge legend (clashing edge highlighted), and a slot board with the course chips. Orders: CS101 → CS202 or CS202 → CS101 (Backtracking Search also offers MRV / MRV + Degree).
* Every course has fewer linked courses than slots, so plain backtracking never backtracks — a contrast with the Timetabling example.

#### `python_sandbox/07_CSP_Heuristics.py`

Standalone, dependency-free (`random`, `time`) and runnable with `python 07_CSP_Heuristics.py`.

1. **Variable ordering** — `mrv(assignment, csp)`: counts legal values with `is_consistent`, keeps the minimum, breaks ties with `degree(var)` = number of unassigned neighbours.
2. **Value ordering** — `lcv(var, assignment, csp)`: `ruled_out(val)` counts neighbour values that would violate the constraint; returns the domain sorted ascending.
3. **Inference** — `forward_checking(...)` prunes unassigned neighbours and fails on an empty domain; `ac3(csp, queue, removals)` + `revise(...)`; `mac(...)` fixes `var = value` and calls `ac3` on arcs into `var`. `backtracking_search_heuristics(csp, select_unassigned_variable, order_domain_values, inference)` restores `removals` on backtrack.
4. **Local search** — `min_conflicts(csp, max_steps)`: greedy complete start, random conflicted variable, value with fewest conflicts (random tie-break); counts iterations in `nodes_expanded`.
5. **Measure & compare** — `measure(solver, csp)` returns `(result, nodes_expanded, backtracks, elapsed_ms)`; `compare()` prints a table for Australia, Australia with a bad order, 8-Queens and 20-Queens.

Verified output (`random.seed(4)`; times vary by machine):

| Problem | Backtracking (nodes / backtracks) | BT + MRV/Degree + LCV + FC | BT + MRV/Degree + LCV + MAC | Min-Conflicts (iterations) |
|---|---|---|---|---|
| Australia | 8 / 0 | 8 / 0 | 8 / 0 | 2 |
| Australia, order WA, NSW, NT, Q, SA, V, T | 13 / 5 | 8 / 0 | 8 / 0 | 2 |
| 8-Queens | 114 / 105 | 28 / 28 | 10 / 5 | 1 |
| 20-Queens | 199,636 / 199,615 (~3.6 s) | 28 / 11 | 21 / 0 | 33 |


### 0. Search → Adversarial Search (Games) → CSP — first tab, opens the lecture

Goal: students recognise that all three explore a space of possibilities but solve different kinds of problems. Chips follow a narrative order and end on the transition message.

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **1 · What Is Each Problem Trying to Achieve?** | Search finds a path from an initial state to a goal; a game chooses the best action while accounting for an opponent; a CSP finds an assignment that satisfies all constraints. | `S₀ → … → goal` · `a* = argmaxₐ MINIMAX(RESULT(s, a))` · `{X₁ = v₁, …}` with every `Cⱼ` satisfied | State each goal as a question, then reveal the answer. | Three columns — Topic 02 route graph (NYC → LAX), Topic 03 Fig 5.2 MAX/MIN tree, Topic 04 Australia map — with a "Show the answer" toggle (path cost 8 · best move a₁ = 3 · valid colouring). |
| **2 · How Is the State Space Represented?** | Search: atomic state, successors via actions. Games: state + whose turn + utility → alternating MAX/MIN tree. CSP: factored state — variables, values, constraints. | `ACTIONS(s)`, `RESULT(s, a)` · `TO-MOVE(s)`, `UTILITY(s, p)` · `{Xᵢ = vᵢ}`, `Dᵢ`, `Cⱼ` | Compare what an algorithm can *see* inside one state. | Search / Game / CSP switch: atomic ATL box with action arrows; MAX/MIN tree with layer labels; constraint graph + variable/domain table. "State anatomy" strips compare all three. |
| **3 · What Counts as a Solution?** | A path → a strategy / best move → a complete, consistent assignment. | `[a₁ … aₖ]` minimising Σc · `π(s)` · complete ∧ consistent | "Does the order of steps matter in the answer?" | Three answer cards + table: step order, opponent, quality measure. |
| **4 · Same Exploration, Different Problem** | We are still searching through possibilities, but the type of problem, the state representation and the definition of a solution have changed. | T02 path → T03 best move in a MAX/MIN tree → T04 consistent assignment of a factored state | Reveal row by row, end on the key message. | 5-step reveal grid: stays the same → problem type → state representation → solution → key message banner. |

---

### Interactive Playground (`playground.html#view-csp`)

Sub-tabs:

1. **Map Colouring Solver** — Australia or random map, 2–4 colours; variable ordering (static / MRV / MRV+Degree), value ordering (static / LCV), inference (none / FC / MAC); Run/Pause/Prev/Next/Reset stepper; live domains table; counters.
2. **Course Scheduling** — the timetabling CSP below. Solve hard constraints with backtracking + MRV + FC, then improve soft score with min-conflicts-style local search. Click a course, then a cell, to move it by hand and watch violations update.
3. **N-Queens Min-Conflicts** — n = 4…32, step/run, conflict history.
4. **Sudoku (AC-3 + MAC)** — presets; propagate with AC-3, solve with MAC + MRV; counts of pruned values and backtracks.

### Course Scheduling — Constraint Engine & Problem Formulation
Formulate the scheduling problem into variables, domains, and constraints:
- **Variables:** one per course session. **Domain:** `(timeslot, room)` pairs — 3 days × 4 slots × 4 rooms = 48 values.
- **Hard Constraints (Feasibility - 0 Clashes Allowed):**
  1. *H1: No Room Double-Booking:* No two courses scheduled in the same room at the same time slot.
  2. *H2: Room Capacity & Type Compatibility:* Assigned room capacity $\ge$ course enrollment, and room type matches requirements (e.g. lab courses in Computer Labs).
  3. *H3: No Instructor Double-Booking:* An instructor cannot teach two courses simultaneously.
  4. *H4: Instructor Availability:* No assignments in an instructor's declared unavailable slots.
  5. *H5: No Student Cohort Clash:* Mandatory courses for the same student cohort cannot overlap in time.
  6. *H6: Complete Assignment:* Every required course in the curriculum must be scheduled.
- **Soft Constraints (Quality & Penalties):**
  1. *S1: Instructor Preferences:* Penalize assignments outside preferred slots.
  2. *S2: Room Utilization Fit:* Penalize heavily oversized rooms.
  3. *S3: Student Dead Hours:* Penalize gaps/dead hours in a cohort's daily schedule.
  4. *S4: Consecutive Session Fatigue:* Penalize $>2$ back-to-back classes for cohorts.
  5. *S5: Campus Transit:* Penalize consecutive classes in different buildings without transit time.
- H2 and H4 are **unary** (handled by node consistency); H1, H3, H5 are **binary**; H6 is the completeness goal test.

---

### Practice Exercises (reading notes §6)

1. **Formulating Australia** — count variables, binary constraints (9), complete assignments (3⁷ = 2187), naïve tree leaves (7!·3⁷ = 11,022,480) and the number of solutions (18).
2. **AC-3 trace** — X, Y, Z ∈ {1,2,3,4}, X < Y, Y < Z → X ∈ {1,2}, Y ∈ {2,3}, Z ∈ {3,4}.
3. **Forward checking trace** — WA=red, Q=green, V=blue → SA's domain is wiped out (AIMA Fig 6.7).
4. **Heuristics** — Degree picks SA first; with WA=red, NT=green MRV picks SA; LCV prefers Q=red over Q=blue.
5. **Min-conflicts step** — 4-queens rows `[1,2,0,2]` → move queen in column 1 to row 3 → solution `[1,3,0,2]`.
6. **Structure** — cutset {SA}: `3 · 6 · 3² = 162` vs `3⁷ = 2187` operations.
