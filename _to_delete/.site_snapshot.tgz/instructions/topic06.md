# MLAI401 — Learning & Decision Making (Topic 06) Specification

## 1. Goal & Architecture Overview

Create the comprehensive specification for **Topic 06: Learning & Decision Making**, covering how artificial intelligence agents transition from hand-coded rules to **extracting patterns from data (Supervised Machine Learning: Features, Naive Bayes, and Model Evaluation)**, **learning non-linear representations (Neural Networks & Gradient Descent)**, **discovering latent data groupings (Unsupervised Learning: K-Means)**, and **learning optimal sequential decision policies through environmental interaction (Reinforcement Learning: MDPs, Bellman Equations, and Q-Learning)**.

The topic is structured into four core pillars:
```
6. Learning & Decision Making
   │
   ├── 1. Machine Learning (Supervised Learning)
   │   ├── Features (Bag-of-Words, TF-IDF)
   │   ├── Naive Bayes Classification
   │   └── Model Evaluation (Confusion Matrix, Precision, Recall, F1)
   │
   ├── 2. Neural Networks
   │   ├── Perceptron
   │   ├── Neural Network Basics
   │   ├── Loss & Gradient Descent
   │   └── Deep Learning Overview
   │
   ├── 3. Unsupervised Learning
   │   └── K-means Clustering (Concept)
   │
   └── 4. Reinforcement Learning
       ├── Sequential Decisions & MDPs (States, Actions, Rewards, Transitions)
       ├── Model-Based Planning (Value Iteration & Bellman Optimality)
       └── Model-Free RL (Tabular Q-Learning, SARSA & Exploration)
```

Content reference:
* *Artificial Intelligence: A Modern Approach* (AIMA, 4th ed.):
  * **Part V — Machine Learning:** Chapter 19 (*Learning from Examples*: §19.1–19.3 Forms of Learning, Supervised Classification, §19.6 Model Evaluation & Cross-Validation), Chapter 20 (*Learning Probabilistic Models*: §20.1–20.2 K-Means Clustering), Chapter 21 (*Reinforcement Learning*: §21.1–21.3 Q-Learning, SARSA, Exploration), and Chapter 22 (*Deep Learning / NLP*: §22.1–22.4 Text Features, BoW, Multi-Layer Perceptrons).
  * **Part IV — Uncertain Knowledge and Reasoning:** Chapter 12 (§12.5 Naive Bayes Model) and Chapter 17 (*Making Complex Decisions*: §17.1–17.3 Sequential Decision Problems, MDPs, Value Iteration, Policy Iteration).
* Sutton & Barto, *Reinforcement Learning: An Introduction* (2nd ed., MIT Press, 2018):
  * **Part I — Tabular Solution Methods:** Chapter 3 (*Finite Markov Decision Processes*), Chapter 4 (*Dynamic Programming*), Chapter 6 (*Temporal-Difference Learning: Q-Learning & SARSA*).
* Manning, Raghavan, & Schütze, *Introduction to Information Retrieval* (Cambridge University Press, 2008):
  * Chapter 6 (*Scoring, term weighting and the vector space model*: TF-IDF) and Chapter 13 (*Text classification and Naive Bayes*).

### Target Deliverables

| File | Role |
|---|---|
| `learning.html` | Single-viewport interactive lecture page (concept column + visual illustration column) |
| `demos/learning_demo/ml_engine.js` | Pure zero-dependency ML engine: Tokenizer, Bag-of-Words, TF-IDF vectorizer, Naive Bayes, Confusion Matrix, Perceptron/Neural Net forward pass, and K-Means clustering (`window.MLEngine`) |
| `demos/learning_demo/rl_engine.js` | Pure zero-dependency RL engine: GridWorld MDP, Bellman Value Iteration, Tabular Q-Learning, and SARSA (`window.RLEngine`) |
| `demos/learning_demo/ui.js` | Lecture page controller — topic tabs, concept chips, interactive visualizers, steppers |
| `demos/learning_demo/learning_lab.js` | Playground controller for `playground.html#view-learning` (Text Classification & K-Means) and `playground.html#view-rl` (Grid World RL) |
| `python_sandbox/10_Machine_Learning.py` | Standalone Python implementation of Bag-of-Words, TF-IDF, Naive Bayes with Laplace Smoothing, Confusion Matrix / Metrics, Perceptron / 2-Layer Neural Net, and K-Means Clustering |
| `python_sandbox/11_Reinforcement_Learning.py` | Standalone Python implementation of GridWorld MDP, Bellman Value Iteration, and Tabular Q-Learning / SARSA |
| `python_sandbox/learning.py` | Clean reference classes (`TextCorpus`, `TFIDFVectorizer`, `NaiveBayesClassifier`, `Perceptron`, `KMeans`, `GridWorldMDP`, `QLearner`) used across demos |
| `topic06_reading.html` | Comprehensive textbook-style reading notes + step-by-step worked practice problems with full solutions |
| `curriculum.html` | Updated Topic 06 curriculum card linking to lecture, reading notes, and playground |

---

## 2. Design & Layout Specification

Follows the unified MLAI401 design system established in Topics 01–05:

* **Viewport Strategy:** Single-viewport, concept-first layout without page scroll on standard 1080p desktop displays.
* **Top Navigation Bar:** Breadcrumb (`Curriculum > Topic 06`), topic badge (`Topic 06`), title, and action buttons (`Reading Notes`, `Interactive Demo`).
* **Topic Selector Tabs:**
  1. `0 · Progression: Knowledge & Logic → Learning & Decisions`
  2. `1 · Text Features: Bag-of-Words & TF-IDF`
  3. `2 · Naive Bayes Classification`
  4. `3 · Model Evaluation & Performance Metrics`
  5. `4 · Neural Networks & Gradient Optimization`
  6. `5 · Unsupervised Learning: K-Means Clustering`
  7. `6 · Sequential Decisions & MDPs`
  8. `7 · Model-Based Planning: Value Iteration`
  9. `8 · Model-Free RL: Tabular Q-Learning`
  10. `9 · Evaluating Learning & Decision Systems`
  11. `10 · Code Trace`
* **Two-Column Split (50% / 50%):**
  * **Left Column (Concept):** Topic introduction, responsive concept chips, formal Definition, AIMA / Sutton-Barto notation box, Teaching Tip.
  * **Right Column (Illustration / Visualizer):** Dynamic visualizer, TF-IDF term weight bar chart, Naive Bayes posterior breakdown, Interactive Confusion Matrix calculator, Neural network activation flow / loss bowl, Voronoi K-Means clustering canvas, Grid World value heatmap, Q-table directional policy display, interactive parameter controls, step controls (`Prev`, `Next`, `Run/Pause`, `Reset`), and live execution log.
* **Visual Theme & Palette:** Accent colors: **Vibrant Emerald & Amber** (`#10b981` / `#f59e0b`), highlighting text features (cyan `#06b6d4`), Naive Bayes posterior bars (emerald `#10b981`), neural layer activations (violet `#8b5cf6`), cluster centroids (amber `#f59e0b`), true/false positives (emerald `#10b981` / rose `#f43f5e`), goal states (`#10b981`), hazard traps (`#f43f5e`), and value iteration heatmaps (gradient from `#312e81` indigo to `#f59e0b` amber).
* **Formula Formatting Rule:** Pure HTML/Unicode (`TF-IDF(t, d) = TF(t, d) × IDF(t)`, `P(c|x) = α P(c) ∏ P(xᵢ|c)`, `w ← w - α ∇L`, `V*(s) = max_a ∑ P(s'|s,a)[R + γ V*(s')]`, `Q(s,a) ← Q(s,a) + α[r + γ max Q(s',a') - Q(s,a)]`) — never raw unprocessed LaTeX syntax.

```
┌─────────────────────────────────────────────────────────────┐
│ NAVBAR: Breadcrumb | Topic 06 Badge | Title | Notes | Demo  │
├─────────────────────────────────────────────────────────────┤
│ TOPIC TABS: Progression | Features | Naive Bayes | NN | RL ...│
├──────────────────────────────┬──────────────────────────────┤
│ CONCEPT COLUMN (50%)         │ ILLUSTRATION COLUMN (50%)    │
│                              │                              │
│ • Concept Chip Selector      │ • Interactive Feature Chart /│
│ • Clear Definition           │   Neural Net / MDP Grid      │
│ • Formal AIMA Notation       │ • Step Controls & Execution  │
│ • Teaching Tip & Code Intuition│ • Live Value Readout & Logs │
└──────────────────────────────┴──────────────────────────────┘
```

---

## 3. Running Problem Formulations

### Running Example 1: Spam Detection & Document Classification (Machine Learning)
* **Problem:** Classify incoming messages as **Spam** ($c = 1$) or **Ham / Legitimate** ($c = 0$) using statistical text features.
* **Vocabulary & Features:**
  * Raw text documents: $D = \{d_1, \dots, d_N\}$.
  * **Bag-of-Words (BoW):** Unordered word frequency counts across dictionary $V = \{w_1, \dots, w_{|V|}\}$.
  * **TF-IDF:** Downweights ubiquitous words (e.g. *"the"*, *"is"*) while boosting rare, highly discriminative keywords (e.g. *"lottery"*, *"prize"*, *"meeting"*).
* **Classification via Multinomial Naive Bayes:**
  * Prior class probabilities: $P(\text{Spam}) = 0.30$, $P(\text{Ham}) = 0.70$.
  * Feature likelihood with Laplace Add-1 smoothing: $P(w_i \mid c) = \frac{\text{count}(w_i, c) + 1}{\sum_w \text{count}(w, c) + |V|}$.
  * Decision rule: $\hat{c} = \arg\max_{c \in \{\text{Spam}, \text{Ham}\}} \left[ \log P(c) + \sum_{i=1}^d \log P(w_i \mid c) \right]$.
* **Evaluation:**
  * Test set evaluated with Confusion Matrix: True Positives ($TP$), False Positives ($FP$), True Negatives ($TN$), False Negatives ($FN$).
  * Metric trade-offs: Precision ($\frac{TP}{TP+FP}$) vs. Recall ($\frac{TP}{TP+FN}$) vs. F1-Score harmonic mean.

### Running Example 2: Non-Linear Decision Boundaries & XOR (Neural Networks)
* **Problem:** Classify points in 2D space where linear separators fail (e.g. the classic XOR pattern $(0,0)\to 0, (1,1)\to 0, (0,1)\to 1, (1,0)\to 1$).
* **Architecture:**
  * Single Perceptron: $h(\mathbf{x}) = \text{step}(\mathbf{w}^T \mathbf{x} + b)$ — fails on XOR.
  * Multi-Layer Perceptron (MLP): 2 inputs $\to$ 2 hidden neurons with non-linear activation (ReLU / Sigmoid) $\to$ 1 output neuron.
  * Optimization: Minimizing Binary Cross-Entropy Loss via Gradient Descent ($\mathbf{w} \gets \mathbf{w} - \alpha \nabla_\mathbf{w} L$).

### Running Example 3: Spatial Customer Segmentation (Unsupervised Learning)
* **Dataset:** $N$ unlabeled 2D customer coordinates $\mathbf{x}_i = \langle \text{Income}, \text{SpendingScore} \rangle$.
* **Goal:** Partition data into $K=3$ cohesive clusters minimizing Within-Cluster Sum of Squares (WCSS).
* **Algorithm (K-Means):**
  1. *Assignment Step:* Assign each point $\mathbf{x}_i$ to the closest centroid $\boldsymbol{\mu}_k = \arg\min_j \|\mathbf{x}_i - \boldsymbol{\mu}_j\|^2$.
  2. *Update Step:* Recalculate centroids as the mean of assigned points: $\boldsymbol{\mu}_k = \frac{1}{|C_k|} \sum_{\mathbf{x} \in C_k} \mathbf{x}$.

### Running Example 4: The Classic 4×3 Grid World & Cliff Walking (Reinforcement Learning)
* **Environment (AIMA Fig 17.1 & Sutton-Barto):**
  * Grid of 12 cells $(x, y)$ with start at $(1, 1)$, an impassable wall at $(2, 2)$, a terminal goal state $+1.0$ at $(4, 3)$, and a terminal hazard trap $-1.0$ at $(4, 2)$.
  * **Living Step Reward:** $R(s) = -0.04$ for every non-terminal transition (encourages shortest paths).
  * **Transition Model (Stochastic Dynamics):** Actions $\{ \text{Up}, \text{Down}, \text{Left}, \text{Right} \}$. Action succeeds with probability $0.8$; veers $90^\circ$ left with prob $0.1$; veers $90^\circ$ right with prob $0.1$.
  * **Discount Factor:** $\gamma = 0.99$ (or adjustable $0.0 \dots 1.0$).
* **Demonstrations:**
  * **Model-Based Planning (Known MDP):** Value Iteration computing $V^*(s) = \max_a \sum_{s'} P(s' \mid s, a) [R(s, a, s') + \gamma V^*(s')]$.
  * **Model-Free Learning (Unknown MDP):** Q-Learning agent discovering the optimal policy $\pi^*(s) = \arg\max_a Q(s, a)$ from scratch using Temporal Difference error $\delta = r + \gamma \max_{a'} Q(s', a') - Q(s, a)$ under $\epsilon$-greedy exploration.

---

## 4. Topic-by-Topic Concepts & Interactive Visualizers

### 0. Progression: Knowledge & Logic → Learning & Decisions
*The bridge connecting hand-engineered symbolic reasoning to empirical data-driven learning and sequential reward optimization.*

| Concept | Definition | AIMA / Sutton-Barto Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **1 · Handcrafted Rules vs. Empirical Learning** | In Topics 01–05, knowledge bases and heuristics were manually engineered. Machine Learning extracts patterns, features, and decision boundaries directly from empirical data. | Handcrafted: $KB \models \alpha$ · Learning: $h \gets \text{LEARN}(D)$ | When domain rules are too complex or fuzzy to write by hand (e.g. spam filtering, vision), we let data train the statistical parameters. | Dual comparison: 50 lines of brittle `if-else` string rules vs. compact statistical likelihood table. |
| **2 · Static Classification vs. Sequential Decisions** | Supervised classification makes static, one-shot predictions on independent samples ($x \to y$). Reinforcement Learning makes sequential decisions where actions affect future states and rewards. | Static: $\hat{y} = \arg\max_c P(c \mid \mathbf{x})$ · Sequential: $s_t \xrightarrow{a_t} r_{t+1}, s_{t+1}$ | A spam classifier inspects an isolated email; an RL agent navigates a maze where each step determines future survival. | Split view: Single-sample classification card vs. closed-loop agent-environment interaction diagram. |
| **3 · The Learning Problem Spectrum** | Supervised learning (labeled input-output pairs $\langle \mathbf{x}, y \rangle$), Neural Networks (non-linear representations), Unsupervised learning (latent clustering), and Reinforcement learning (reward feedback $r$). | Supervised: $(x, y)$ · Unsupervised: $x$ · RL: $(s, a, r, s')$ | Supervised = studying with answer key; Unsupervised = finding patterns in stars; RL = learning to ride a bike. | 4-card paradigm selector highlighting input, feedback mechanism, and optimization objective. |

---

### 1. Machine Learning: Features (Bag-of-Words & TF-IDF)
*How unstructured text is transformed into numerical feature vectors for statistical classification.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Tokenization & Vocabulary** | Splitting raw text into discrete word tokens, normalizing case, removing punctuation/stopwords, and constructing a fixed vocabulary index $V$. | $V = \{w_1, w_2, \dots, w_{|V|}\}$ · $d = [t_1, t_2, \dots, t_L]$ | The vocabulary size $|V|$ defines the dimensionality of the feature space. | Interactive string tokenizer: enter text $\to$ live token stream and vocabulary index badges. |
| **Bag-of-Words (BoW) Representation** | Represents a document as an unordered multiset of word counts, disregarding grammar and word order but preserving word frequencies. | $\mathbf{x} = \langle c(w_1, d), c(w_2, d), \dots, c(w_{|V|}, d) \rangle$ | Simple yet surprisingly powerful for text classification, spam detection, and topic categorization. | Word frequency bar chart for sample emails (comparing spam word spikes vs. legitimate emails). |
| **Term Frequency (TF)** | Relative frequency of a term $t$ in document $d$, measuring local term importance: $\text{TF}(t, d) = \frac{\text{count}(t, d)}{\sum_{t'} \text{count}(t', d)}$ (or raw count). | $\text{TF}(t, d) = \frac{f_{t,d}}{\sum_{t' \in d} f_{t',d}}$ | Normalizing by document length prevents longer documents from dominating feature scales. | Dual document comparison with length-normalized term frequency gauges. |
| **Inverse Document Frequency (IDF)** | Measures how much information a word provides across the entire corpus: $\text{IDF}(t, D) = \log\left(\frac{N}{|\{d \in D : t \in d\}|}\right)$. | $\text{IDF}(t) = \log\left(\frac{N}{DF(t)}\right)$ where $N = |D|$ | Common words like *"the"* appear in all documents ($\text{IDF} \to 0$); rare words like *"lottery"* have high $\text{IDF}$. | Interactive IDF curve: drag document frequency $DF \to$ watch IDF weight decay toward 0. |
| **TF-IDF Weighting & Vector Space** | Combines local frequency with global rarity: $\text{TF-IDF}(t, d) = \text{TF}(t, d) \times \text{IDF}(t)$. | $\mathbf{x}_{\text{tfidf}} = \langle \text{TF-IDF}(w_1, d), \dots \rangle$ | High TF-IDF means a word is frequent in *this* document but rare in the general corpus. | Interactive TF-IDF matrix table showing raw counts converting to weighted importance scores. |

---

### 2. Machine Learning: Naive Bayes Classification
*Probabilistic generative classification using Bayes' Rule and conditional independence assumptions.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Generative Classification & MAP Rule** | Models the joint distribution $P(\mathbf{x}, c) = P(c)P(\mathbf{x} \mid c)$ and chooses the class maximizing the posterior probability (Maximum A Posteriori). | $c^* = \arg\max_{c \in C} P(c \mid \mathbf{x}) = \arg\max_{c \in C} P(c) P(\mathbf{x} \mid c)$ | Instead of learning a direct boundary, Naive Bayes models what Spam and Ham emails "look like" statistically. | Prior balance scale: Prior $P(c)$ multiplied by likelihood product $P(\mathbf{x} \mid c) \to$ posterior. |
| **Conditional Independence Assumption** | Assumes all feature attributes $x_1, \dots, x_d$ are conditionally independent given the class label $c$: $P(\mathbf{x} \mid c) = \prod_{i=1}^d P(x_i \mid c)$. | $P(x_1, \dots, x_d \mid c) = \prod_{i=1}^d P(x_i \mid c)$ | The assumption is "naive" because words correlate, but in practice it performs remarkably well and is extremely fast! | Factorization visualizer: 2D joint likelihood table decomposing into 1D independent feature products. |
| **Multinomial Naive Bayes Model** | Represents text as a sequence of word tokens drawn from a categorical distribution over vocabulary $V$ for class $c$. | $P(d \mid c) = \prod_{i=1}^L P(w_i \mid c)$ | Standard formulation for text classification: word count likelihoods multiply across all document positions. | Live text classifier: type an email $\to$ see individual word likelihood multipliers light up in green/red. |
| **Laplace (Add-1) Smoothing** | Adds a pseudo-count $\alpha = 1$ to all word counts to prevent zero probabilities from multiplying out the entire likelihood to 0. | $\hat{P}(w \mid c) = \frac{\text{count}(w, c) + \alpha}{\sum_{w'} \text{count}(w', c) + \alpha |V|}$ | If an unseen word occurs in a test document, unsmoothed probability is 0. Laplace smoothing saves the calculation! | Zero-probability trap demonstration: unsmoothed $P(\text{Spam}) = 0.0$ vs smoothed $P(\text{Spam}) = 0.82$. |
| **Log-Space Computation** | Computing probabilities in log space to prevent numerical floating-point underflow from multiplying dozens of small numbers. | $\log P(c \mid \mathbf{x}) \propto \log P(c) + \sum_{i=1}^d \log P(x_i \mid c)$ | Adding log-probabilities converts tiny multiplications into stable additions: $\log(a \cdot b) = \log a + \log b$. | Underflow comparison: Raw product $10^{-45} \approx 0.0$ vs. Log-sum $-103.6$ (stable). |

---

### 3. Machine Learning: Model Evaluation & Performance Metrics
*Rigorous statistical validation of classification performance and threshold trade-offs.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Confusion Matrix (TP, FP, TN, FN)** | A 2×2 contingency table recording actual vs. predicted class outcomes: True Positive ($TP$), False Positive ($FP$), True Negative ($TN$), False Negative ($FN$). | $\begin{pmatrix} TP & FN \\ FP & TN \end{pmatrix}$ | $FP$ = Type I Error (False Alarm, legitimate email marked spam); $FN$ = Type II Error (Missed spam). | Interactive 2×2 Confusion Matrix with editable counts and instant dynamic metric recalculations. |
| **Accuracy & Accuracy Paradox** | Proportion of correct predictions over total examples: $\text{Accuracy} = \frac{TP + TN}{TP + TN + FP + FN}$. | $\text{Acc} = \frac{TP + TN}{N}$ | On imbalanced datasets (e.g. 99% non-fraud), a naive classifier predicting all-negative achieves 99% accuracy but is useless! | Imbalanced dataset visualizer showing 99% accuracy fail state. |
| **Precision (Positive Predictive Value)** | Proportion of predicted positive cases that were truly positive: $\text{Precision} = \frac{TP}{TP + FP}$. | $\text{Precision} = \frac{TP}{TP + FP}$ | "When the model flags an email as Spam, how often is it actually Spam?" High precision avoids deleting good mail. | Target diagram: ratio of true hits inside the predicted positive boundary. |
| **Recall (Sensitivity / True Positive Rate)** | Proportion of actual positive cases that were correctly identified: $\text{Recall} = \frac{TP}{TP + FN}$. | $\text{Recall} = \frac{TP}{TP + FN}$ | "Out of all real spam in the world, what fraction did the model catch?" High recall avoids leaking spam. | Target diagram: fraction of all real positive dots enclosed by the classifier. |
| **F1-Score (Harmonic Mean)** | The harmonic mean of Precision and Recall, balancing false alarms against missed detections. | $F_1 = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}} = \frac{2 TP}{2 TP + FP + FN}$ | The harmonic mean heavily penalizes extreme imbalances (if Precision is 1.0 but Recall is 0.0, F1 is 0.0). | Interactive Precision-Recall trade-off slider with live F1-Score curve. |

---

### 4. Neural Networks & Gradient Optimization
*How artificial neurons combine into multi-layer architectures to learn non-linear representations via gradient descent.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **The Perceptron & Linear Separability** | The fundamental biological-inspired computing unit that computes a weighted sum of inputs and applies a threshold activation: $h(\mathbf{x}) = \text{sign}(\mathbf{w}^T \mathbf{x} + b)$. | $z = \mathbf{w}^T \mathbf{x} + b = \sum_{j=1}^d w_j x_j + b$ · $h(\mathbf{x}) = \text{step}(z)$ | A single perceptron can only learn linear decision boundaries. It famously fails on non-linear problems like XOR! | Interactive 2D hyperplane: drag weight vector $\mathbf{w}$ to rotate the separating boundary; XOR failure demo. |
| **Neural Network Basics (Layers & Activations)** | Networks composed of input, hidden, and output layers. Non-linear activation functions (ReLU, Sigmoid, Tanh) allow networks to bend and shape complex decision surfaces. | $\mathbf{h} = g(\mathbf{W}_1 \mathbf{x} + \mathbf{b}_1)$ · $\hat{y} = \sigma(\mathbf{W}_2 \mathbf{h} + b_2)$ · $\text{ReLU}(z) = \max(0, z)$ | Without non-linear activation functions, any deep multi-layer network mathematically collapses into a single linear transformation! | Interactive forward pass diagram: input signals propagate through weights $\mathbf{W}$ and activation curves to output. |
| **Loss Functions & Gradient Descent** | Quantifying error (Loss $L(\mathbf{w})$) and updating weights in the opposite direction of the gradient: $\mathbf{w} \gets \mathbf{w} - \alpha \nabla_\mathbf{w} L$. | Cross-Entropy: $L = -[y \log \hat{y} + (1-y) \log(1-\hat{y})]$ · $\mathbf{w}^{(t+1)} = \mathbf{w}^{(t)} - \alpha \nabla L$ | Think of a hiker in thick fog feeling the slope underfoot and taking small steps downhill toward the lowest point. | 2D/3D loss bowl contour surface: watch weight point descend down the gradient slope toward the minimum. |
| **Deep Learning Overview (Representations & Backprop)** | Deep architectures learn hierarchical representations (low-level edges $\to$ mid-level textures $\to$ high-level objects). Backpropagation applies the chain rule to compute gradients across all layers. | $\frac{\partial L}{\partial \mathbf{W}_1} = \frac{\partial L}{\partial \hat{y}} \frac{\partial \hat{y}}{\partial \mathbf{h}} \frac{\partial \mathbf{h}}{\partial \mathbf{z}_1} \frac{\partial \mathbf{z}_1}{\partial \mathbf{W}_1}$ | Deep learning replaces manual feature engineering: the network learns optimal feature representations directly from raw data. | Hierarchical feature abstraction pipeline: Pixels $\to$ Edges $\to$ Parts $\to$ Object recognition. |

---

### 5. Unsupervised Learning: K-Means Clustering
*Discovering natural groupings and latent structures in unlabeled data.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Unsupervised Clustering Goal** | Partitioning $N$ unlabeled data points $\mathbf{x}_1, \dots, \mathbf{x}_N \in \mathbb{R}^d$ into $K$ disjoint clusters $C_1, \dots, C_K$ such that intra-cluster distance is minimized. | $\min_{C_1, \dots, C_K} \sum_{k=1}^K \sum_{\mathbf{x} \in C_k} \|\mathbf{x} - \boldsymbol{\mu}_k\|^2$ | No labels $y$ are provided! The algorithm discovers the natural cluster boundaries on its own. | Unlabeled 2D point cloud with 3 natural spatial groupings. |
| **The K-Means Algorithm Cycle** | Alternating between two steps until convergence: (1) Assignment Step: Assign each point to the nearest centroid; (2) Update Step: Move centroids to the arithmetic mean of assigned points. | Assign: $c_i = \arg\min_k \|\mathbf{x}_i - \boldsymbol{\mu}_k\|^2$ · Update: $\boldsymbol{\mu}_k = \frac{1}{|C_k|} \sum_{i \in C_k} \mathbf{x}_i$ | K-Means is guaranteed to monotonically decrease the objective function (WCSS) and converge in finite steps. | Step-by-step Voronoi canvas: points recolor to nearest centroid; centroids jump to new cluster center of mass. |
| **Voronoi Tessellation & WCSS** | The decision boundaries between cluster centroids form convex Voronoi polygons. Within-Cluster Sum of Squares (WCSS) measures total cluster compactness/inertia. | $\text{WCSS} = \sum_{k=1}^K \sum_{\mathbf{x} \in C_k} \|\mathbf{x} - \boldsymbol{\mu}_k\|^2$ | Centroids define the centers of Voronoi cells; any point inside a cell is closest to that cell's centroid. | Voronoi polygon cell overlays drawn in real-time over the clustering canvas. |
| **Choosing $K$: The Elbow Method** | Plotting WCSS against cluster count $K \in \{1, 2, \dots, 8\}$. The optimal $K$ is located at the "elbow" where adding more clusters yields diminishing returns. | $\Delta \text{WCSS}(K) = \text{WCSS}(K) - \text{WCSS}(K+1)$ | Increasing $K$ always reduces WCSS (at $K=N$, WCSS is 0), so we look for the sharp bend in the curve. | Interactive Elbow Curve plot with cursor selecting optimal bend $K^*=3$. |

---

### 6. Reinforcement Learning: Sequential Decisions & MDPs
*Formulating sequential decision problems with stochastic dynamics, states, actions, and delayed rewards.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **The RL Agent-Environment Loop** | At each time step $t$, the agent observes state $s_t \in S$, executes action $a_t \in A$, and receives numerical reward $r_{t+1}$ and next state $s_{t+1}$. | $s_t \xrightarrow{a_t} r_{t+1}, s_{t+1} \xrightarrow{a_{t+1}} \dots$ | Unlike supervised learning, there is no supervisor telling the agent the correct action—only a scalar reward signal. | Animated feedback loop: Agent brain emits Action $\to$ Environment world returns State & Reward. |
| **Markov Decision Process (MDP) Tuple** | A formal sequential decision framework defined by the 5-tuple: $\langle S, A, P(s' \mid s, a), R(s, a, s'), \gamma \rangle$. | $\text{MDP} = \langle S, A, P, R, \gamma \rangle$ | The Markov property means state $s_{t+1}$ depends only on current state $s_t$ and action $a_t$, not past history. | 4×3 Grid World environment diagram highlighting states, directional actions, and terminal reward cells. |
| **Return & Discount Factor ($\gamma$)** | The cumulative discounted reward accumulated over the trajectory: $G_t = \sum_{k=0}^\infty \gamma^k R_{t+k+1}$ where $\gamma \in [0, 1)$. | $G_t = R_{t+1} + \gamma R_{t+2} + \gamma^2 R_{t+3} + \dots$ | $\gamma$ models patience: $\gamma \to 0$ makes agent myopic (immediate reward); $\gamma \to 1$ makes agent farsighted. | Discount multiplier timeline: $\gamma^0=1.0, \gamma^1=0.9, \gamma^2=0.81, \dots$ showing exponential decay. |
| **Policy ($\pi$) & State-Value Function ($V^\pi(s)$)** | A policy $\pi(s)$ specifies what action to take in state $s$. Value $V^\pi(s)$ is the expected return starting from $s$ under policy $\pi$. | $V^\pi(s) = \mathbb{E}_\pi [G_t \mid S_t = s]$ | A policy is a full navigation map telling the agent what to do in every conceivable situation. | Grid World overlay showing directional policy arrows $\pi(s)$ on each grid cell. |
| **Action-Value Function ($Q^\pi(s, a)$)** | The expected return of taking action $a$ in state $s$, and thereafter following policy $\pi$. | $Q^\pi(s, a) = \mathbb{E}_\pi [G_t \mid S_t = s, A_t = a]$ | $V(s)$ measures "how good is this state"; $Q(s, a)$ measures "how good is taking action $a$ in this state". | 4-quadrant cell showing individual $Q$-values for Up, Down, Left, Right inside a single grid square. |

---

### 7. Reinforcement Learning: Model-Based Planning (Value Iteration)
*Solving known MDPs using Dynamic Programming and Bellman Equations.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **The Bellman Expectation Equation** | Expresses the value of a state as the immediate expected reward plus the discounted expected value of successor states. | $V^\pi(s) = \sum_a \pi(a \mid s) \sum_{s'} P(s' \mid s, a) [R(s, a, s') + \gamma V^\pi(s')]$ | Value functions satisfy recursive consistency: the value of today is today's reward plus tomorrow's value. | Backup diagram: Root state $s \to$ action branches $a \to$ stochastic outcome states $s'$. |
| **The Bellman Optimality Equation** | The optimal state value $V^*(s)$ equals the expected return of the best possible action chosen greedily. | $V^*(s) = \max_{a \in A} \sum_{s'} P(s' \mid s, a) [R(s, a, s') + \gamma V^*(s')]$ | At optimality, the agent picks the action that maximizes immediate reward plus expected future return. | Visual equation breakdown linking $\max_a$ operator to the highest-value transition branch. |
| **Value Iteration Algorithm** | Dynamic programming algorithm that turns the Bellman Optimality Equation into an iterative update rule: $V_{k+1}(s) \gets \max_a \sum_{s'} P(s' \mid s, a) [R + \gamma V_k(s')]$. | $V_{k+1}(s) \gets \max_a \sum_{s'} P(s' \mid s, a) [R(s, a, s') + \gamma V_k(s')]$ | Guaranteed to converge to the unique optimal values $V^*$ for any discount factor $\gamma < 1$ (contraction mapping). | Step-by-step 4×3 Grid World value heatmap: watch values diffuse outward from $+1.0$ goal across iterations. |
| **Policy Extraction from $V^*$** | Once optimal values $V^*(s)$ are computed, the optimal policy $\pi^*(s)$ is extracted by 1-step lookahead. | $\pi^*(s) = \arg\max_{a \in A} \sum_{s'} P(s' \mid s, a) [R(s, a, s') + \gamma V^*(s')]$ | Acting greedily with respect to the optimal value function yields the globally optimal policy! | Interactive toggle: flip between numerical value heatmap and extracted policy arrow grid. |

---

### 8. Reinforcement Learning: Model-Free RL (Tabular Q-Learning)
*Learning optimal policies directly from environmental interaction without knowing transition probabilities or reward models.*

| Concept | Definition | Mathematical Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Model-Based vs. Model-Free RL** | Model-based planning requires knowing $P(s' \mid s, a)$ and $R$; Model-free learning learns directly from trial-and-error experience samples $\langle s, a, r, s' \rangle$. | Model-Based: Known $P, R \to \text{Plan}$ · Model-Free: Samples $\to Q(s, a)$ | Model-free RL is essential when the physics of the environment are too complex to model explicitly. | Split illustration: Blueprint transition matrix vs. agent exploring an unknown black-box game. |
| **Temporal Difference (TD) Error** | The difference between the estimated value before an action and the new estimate after observing reward $r$ and next state $s'$. | $\text{TD Target} = r + \gamma \max_{a'} Q(s', a')$ · $\delta_t = \text{TD Target} - Q(s, a)$ | TD learning updates beliefs based on immediate actual outcome rather than waiting until the end of the episode. | TD Error gauge showing surprise $\delta = (r + \gamma Q_{\text{next}}) - Q_{\text{current}}$. |
| **Tabular Q-Learning Algorithm** | An off-policy temporal-difference control algorithm that updates state-action values toward the greedy optimal choice. | $Q(s, a) \gets Q(s, a) + \alpha \left[ r + \gamma \max_{a'} Q(s', a') - Q(s, a) \right]$ | **The master equation of Model-Free RL!** Proven to converge to $Q^*$ with probability 1 if all pairs are visited infinitely often. | Step-by-step Q-table cell update: highlights current $Q(s, a)$, reward $r$, $\max Q(s', a')$, and new updated value. |
| **Exploration vs. Exploitation ($\epsilon$-Greedy)** | The dilemma between exploiting known high-reward actions vs. exploring uncertain actions to discover better long-term policies. | $\pi(a \mid s) = \begin{cases} \arg\max_a Q(s, a) & \text{with prob } 1 - \epsilon \\ \text{Random action} & \text{with prob } \epsilon \end{cases}$ | If you never explore, you get trapped in suboptimal habits; if you only explore, you never reap the rewards. | Dice roll visualizer showing $(1-\epsilon)$ greedy exploit vs. $\epsilon$ exploration roll. |
| **SARSA (On-Policy TD Control)** | Updates $Q(s, a)$ using the actual action $a'$ chosen by current policy: $Q \gets Q + \alpha [r + \gamma Q(s', a') - Q(s, a)]$. | $Q(s, a) \gets Q(s, a) + \alpha \left[ r + \gamma Q(s', a') - Q(s, a) \right]$ | Q-Learning is optimistic (assumes optimal future play); SARSA is cautious (accounts for mistakes during exploration). | Side-by-side path comparison on Cliff Walking: Q-Learning hugs the cliff edge, SARSA takes safe inland path. |

---

### 9. Evaluating Learning & Decision Systems

Comprehensive multi-dimensional comparison across Supervised Learning, Neural Networks, Unsupervised Clustering, and Reinforcement Learning:

| Dimension | 1. Naive Bayes (Supervised ML) | 2. Neural Networks (Deep Learning) | 3. K-Means (Unsupervised) | 4. Value Iteration (Model-Based MDP) | 5. Q-Learning (Model-Free RL) |
|---|---|---|---|---|---|
| **Core Goal** | Classify static inputs $\mathbf{x} \to y$ | Learn non-linear mapping $\mathbf{x} \to y$ | Group unlabeled points into $K$ clusters | Find optimal policy $\pi^*(s)$ in known MDP | Learn optimal policy $\pi^*(s)$ by trial-and-error |
| **Input Data** | Labeled pairs $\{(\mathbf{x}_i, y_i)\}$ | Labeled feature vectors | Unlabeled points $\{\mathbf{x}_i\}$ | Known transition $P$ and reward $R$ | Experience tuples $(s, a, r, s')$ |
| **Key Assumption** | Conditional independence of features | Differentiable loss surface | Spherical clusters with equal variance | Markov property; fully known dynamics | Markov property; sufficient exploration |
| **Optimization Method** | Closed-form counts (MLE + Laplace) | Gradient Descent & Backprop | Alternating Expectation-Maximization | Bellman Optimality dynamic programming | Temporal Difference bootstrapping |
| **Computational Complexity** | **$O(N \cdot d)$ Ultra-fast linear** | $O(N \cdot \text{epochs} \cdot |\text{weights}|)$ | $O(N \cdot K \cdot d \cdot \text{iters})$ | $O(|A| \cdot |S|^2)$ per iteration | $O(1)$ constant time per step |
| **Handling Delayed Feedback** | None (instant supervised labels) | None (instant supervised labels) | None (unlabeled data) | Full credit assignment via $\gamma$ | Full credit assignment via TD target |
| **Best Application** | Spam filtering, text classification | Computer vision, NLP, speech | Customer segmentation, compression | Robot path planning with known maps | Game playing, robotics in unknown worlds |

---

### 10. Code Trace Specification (`learning.html#code`)

Interactive line-by-line stepping through clean, runnable Python code with real-time state visualization:

```
┌──────────────────────────────────────┬──────────────────────────────────────┐
│ PYTHON SOURCE TRACE (Left 50%)       │ RUNTIME STATE & VISUALIZER (Right 50%)│
│                                      │                                      │
│ • Line numbers with execution arrow  │ • Active feature vectors / Q-table   │
│ • Highlighted active expressions     │ • Confusion matrix & value heatmaps  │
│ • Step commentary & variable watch   │ • Step k of N | Prev | Next | Run/Pause│
└──────────────────────────────────────┴──────────────────────────────────────┘
```

#### Presets Traced

1. **`trace_tfidf` (`python_sandbox/10_Machine_Learning.py`):**
   * **Problem:** 3-document corpus; compute $\text{TF}$, $\text{IDF}$, and final $\text{TF-IDF}$ vector for document $d_1$.
   * **State Display:** Live vocabulary index $V$, document frequency table $DF(t)$, $\text{IDF}(t)$ scores, and normalized feature vector $\mathbf{x}_{\text{tfidf}}$.
2. **`trace_naive_bayes` (`python_sandbox/10_Machine_Learning.py`):**
   * **Problem:** Classify test document *"cheap lottery prize"* into Spam vs. Ham with Laplace Add-1 smoothing.
   * **State Display:** Prior log-odds $\log P(c)$, word conditional likelihoods $\log P(w \mid c)$, accumulating log-posterior sum, and final classification badge $\text{Spam}$.
3. **`trace_perceptron` (`python_sandbox/10_Machine_Learning.py`):**
   * **Problem:** 1 training step of Perceptron learning rule on misclassified point $(x_1=1, x_2=0, y=1)$ with weights $\mathbf{w}=[0.5, -0.5], b=-0.1$.
   * **State Display:** Dot product $z = \mathbf{w}^T \mathbf{x} + b$, prediction $\hat{y}=0$, error $e = (1 - 0) = 1$, weight update $\mathbf{w} \gets \mathbf{w} + \alpha y \mathbf{x}$.
4. **`trace_kmeans_step` (`python_sandbox/10_Machine_Learning.py`):**
   * **Problem:** 1 iteration of K-Means clustering on 6 2D points with $K=2$ centroids.
   * **State Display:** Euclidean distance matrix, assignment vector $[c_1, \dots, c_6]$, cluster mean calculations, and updated centroid positions $\boldsymbol{\mu}_1, \boldsymbol{\mu}_2$.
5. **`trace_value_iteration` (`python_sandbox/11_Reinforcement_Learning.py`):**
   * **Problem:** 1 iteration of Bellman Value Iteration on 4×3 Grid World with living reward $R=-0.04, \gamma=0.99$.
   * **State Display:** 4 directional expected returns $\sum P(s' \mid s, a)[R + \gamma V(s')]$ for cell $(3, 3)$, $\max_a$ selection, and value update $V_{k+1}(3,3)$.
6. **`trace_q_learning_step` (`python_sandbox/11_Reinforcement_Learning.py`):**
   * **Problem:** Agent in state $(3, 3)$ takes action $\text{Right}$, receives reward $-0.04$, lands in terminal state $(4, 3)$ with reward $+1.0$.
   * **State Display:** Prior $Q((3,3), \text{Right})$, TD Target $r + \gamma \max Q$, TD Error $\delta$, learning rate $\alpha=0.2$, and updated $Q$-value.

---

## 5. Python Sandbox Scripts

### File 1: `python_sandbox/10_Machine_Learning.py`
Standalone, zero-dependency Python script runnable directly with `python 10_Machine_Learning.py`:
* `TextCorpus` and `TFIDFVectorizer` classes implementing tokenization, document frequency, and $\text{TF-IDF}$ feature extraction.
* `NaiveBayesClassifier` class with Laplace Add-1 smoothing, log-space inference, and training.
* `Perceptron` and simple `MultiLayerPerceptron` classes with forward propagation, activation functions, and gradient descent.
* `KMeans` class implementing Lloyd's algorithm, Voronoi centroid updates, and WCSS inertia calculation.
* `evaluate_classifier(y_true, y_pred)` computing Confusion Matrix, Accuracy, Precision, Recall, and F1-Score.
* **Built-in Test Cases:**
  * SMS Spam Collection benchmark dataset.
  * XOR classification with Single Perceptron vs. Multi-Layer Network.
  * Synthetic 2D cluster dataset with K-Means convergence test.

### File 2: `python_sandbox/11_Reinforcement_Learning.py`
Standalone, zero-dependency Python script runnable directly with `python 11_Reinforcement_Learning.py`:
* `GridWorld` class with stochastic transition dynamics, obstacles, living rewards, and terminal states.
* `value_iteration(mdp, gamma, epsilon)` — Exact dynamic programming planning.
* `q_learning(mdp, episodes, alpha, gamma, epsilon)` — Tabular off-policy TD learning with $\epsilon$-greedy exploration.
* `sarsa(mdp, episodes, alpha, gamma, epsilon)` — On-policy TD control.
* **Built-in Test Cases:**
  * Classic AIMA 4×3 Grid World benchmark.
  * Cliff Walking environment (comparing Q-Learning vs. SARSA paths).

---

## 6. Reading Notes & Practice Exercises (`topic06_reading.html`)

Textbook-style reading notes structured into four comprehensive modules, followed by fully worked-out analytical practice problems:

### Module Structure
1. **Module 1: Supervised Machine Learning (Features, Naive Bayes & Evaluation)**
   * Feature engineering: Bag-of-Words and TF-IDF mathematical derivations.
   * Naive Bayes generative classifier: MAP rule, conditional independence, Laplace Add-1 smoothing, and log-space computation.
   * Model evaluation: Confusion Matrix ($TP, FP, TN, FN$), Accuracy, Precision, Recall, F1-Score harmonic mean, and threshold trade-offs.
2. **Module 2: Neural Networks & Gradient Optimization**
   * The Perceptron model, decision hyperplanes, and linear separability (XOR limitation).
   * Multi-layer architectures, hidden representations, non-linear activation functions (ReLU, Sigmoid).
   * Loss functions (Cross-Entropy, MSE), Gradient Descent optimization, learning rates, and backpropagation intuition.
3. **Module 3: Unsupervised Learning & K-Means Clustering**
   * Unsupervised clustering objectives and Within-Cluster Sum of Squares (WCSS).
   * The 2-step K-Means algorithm (Assignment and Centroid Update).
   * Voronoi tessellations, local minima, and determining optimal $K$ with the Elbow Method.
4. **Module 4: Reinforcement Learning (MDPs, Planning & Q-Learning)**
   * Sequential decisions: Agent-environment loop, Markov property, MDP tuple $\langle S, A, P, R, \gamma \rangle$, returns, and value functions $V(s), Q(s, a)$.
   * Model-based planning: Bellman Expectation and Optimality equations, Value Iteration algorithm, and policy extraction.
   * Model-free learning: Temporal Difference error, Tabular Q-Learning update rule, SARSA, and $\epsilon$-greedy exploration.

### Practice Problems Included

1. **Bag-of-Words & TF-IDF Calculation:**
   * Given a 3-document mini-corpus, compute term frequency $\text{TF}$, inverse document frequency $\text{IDF}$, and final $\text{TF-IDF}$ weight vectors for target keywords.
2. **Naive Bayes Spam Classification with Laplace Smoothing:**
   * Given training counts for Spam ($N=4$) and Ham ($N=6$), compute prior probabilities and smoothed word likelihoods for vocabulary $V$; classify test email *"buy lottery prize"* showing complete log-probability calculations.
3. **Confusion Matrix & Metric Calculation:**
   * Given test results $TP=45, FP=5, FN=15, TN=935$, compute Accuracy, Precision, Recall, and F1-Score; explain why Accuracy alone is deceptive.
4. **Perceptron Learning Rule Update Step:**
   * Given weights $\mathbf{w} = [0.2, -0.4]$, bias $b = 0.1$, learning rate $\alpha = 0.5$, and a misclassified training sample $(\mathbf{x} = [1, 2], y = 1)$: calculate the output $\hat{y}$, error, and updated weights $\mathbf{w}'$.
5. **K-Means 1-Step Centroid Update:**
   * Given 4 2D data points $A(1,1), B(2,1), C(4,5), D(5,5)$ and initial centroids $\boldsymbol{\mu}_1(1,2), \boldsymbol{\mu}_2(5,4)$: compute Euclidean distances, assign points to clusters, and recalculate new centroid coordinates.
6. **Bellman Value Iteration Step on 4×3 Grid World:**
   * Given living reward $R=-0.04$, discount $\gamma=0.9$, and current neighbor values: compute expected return for actions $\text{Up}, \text{Left}, \text{Right}, \text{Down}$ and find updated $V_{k+1}(s)$.
7. **Q-Learning Step-by-Step TD Update:**
   * Given current $Q(s, \text{East}) = 0.50$, learning rate $\alpha = 0.1$, reward $r = -0.04$, discount $\gamma = 0.9$, and next-state values $Q(s', \cdot) = [0.2, 0.8, 0.4, 0.1]$: compute the TD Target, TD Error $\delta$, and new value $Q(s, \text{East})$.

---

## 7. Interactive Playground Specifications (`playground.html#view-learning` & `playground.html#view-rl`)

Interactive lab sub-views:

1. **Text Classification & Naive Bayes Studio (`#view-learning`):**
   * Live interactive email classifier: enter custom text, inspect live tokenized Bag-of-Words and TF-IDF vectors.
   * View live log-likelihood contribution per word in real time with Spam vs. Ham posterior meter.
   * Interactive Confusion Matrix widget: adjust classification threshold slider $\theta \in [0, 1]$ and observe real-time trade-off curves for Precision, Recall, and F1.
2. **Neural Network Decision Boundary Studio (`#view-nn`):**
   * Interactive 2D point cloud with toggleable linear, circular, and XOR point distributions.
   * Add/remove hidden neurons; observe real-time decision boundary warping and loss curve descent.
3. **K-Means Clustering Lab (`#view-kmeans`):**
   * Click canvas to add 2D spatial points; adjust $K \in [2, 6]$.
   * Step through assignment and centroid update steps with animated Voronoi polygon cell boundaries and WCSS elbow curve.
4. **Grid World Reinforcement Learning Lab (`#view-rl`):**
   * Classic 4×3 Grid World and Cliff Walking grid visualizers with customizable living rewards and slip probabilities.
   * Step-by-step Value Iteration runner with color-coded value gradient heatmaps.
   * Live Q-Learning agent simulator: watch the agent explore via $\epsilon$-greedy, accumulate TD updates, and converge to the optimal policy.

---

## 8. Academic & Textbook References

### Primary Textbooks & Standard Curricula
* **AIMA (4th Edition):**
  * Chapter 12: *Quantifying Uncertainty* (§12.5 Naive Bayes Model).
  * Chapter 17: *Making Complex Decisions* (§17.1–17.3 MDPs, Value Iteration, Policy Iteration).
  * Chapter 19: *Learning from Examples* (§19.1–19.3 Supervised Classification, §19.6 Model Evaluation).
  * Chapter 20: *Learning Probabilistic Models* (§20.1–20.2 K-Means Clustering).
  * Chapter 21: *Reinforcement Learning* (§21.1–21.3 Q-Learning, Exploration).
  * Chapter 22: *Deep Learning for NLP* (§22.1–22.4 Text Representation, BoW, Multi-Layer Networks).
* **Sutton & Barto (2018):**
  * *Reinforcement Learning: An Introduction* (2nd ed., MIT Press). Chapters 3 (MDPs), 4 (Dynamic Programming), 6 (Temporal-Difference Learning).
* **Manning, Raghavan, & Schütze (2008):**
  * *Introduction to Information Retrieval* (Cambridge University Press). Chapters 6 (TF-IDF Vector Space Model) and 13 (Text Classification and Naive Bayes).
* **Goodfellow, Bengio, & Courville (2016):**
  * *Deep Learning* (MIT Press). Chapters 6 (Deep Feedforward Networks) and 9 (Optimization for Training Deep Models).

### Foundational Papers & Historical Milestones
* **Machine Learning & Text Classification:**
  * Spärck Jones, K. (1972). *A statistical interpretation of term specificity and its application in retrieval*. Journal of Documentation, 28(1), 11–21. (Origin of IDF).
  * Maron, M. E. (1961). *Automatic indexing: an experimental inquiry*. Journal of the ACM, 8(3), 404–417. (First paper on probabilistic Naive Bayes text classification).
  * McCallum, A., & Nigam, K. (1998). *A comparison of event models for Naive Bayes text classification*. AAAI Workshop on Learning for Text Categorization.
* **Neural Networks & Unsupervised Learning:**
  * Rosenblatt, F. (1958). *The perceptron: a probabilistic model for information storage and organization in the brain*. Psychological Review, 65(6), 386.
  * Minsky, M., & Papert, S. (1969). *Perceptrons: An Introduction to Computational Geometry*. MIT Press. (XOR limitation).
  * Rumelhart, D. E., Hinton, G. E., & Williams, R. J. (1986). *Learning representations by back-propagating errors*. Nature, 323(6088), 533–536.
  * Lloyd, S. (1982). *Least squares quantization in PCM*. IEEE Transactions on Information Theory, 28(2), 129–137. (K-Means algorithm).
* **Reinforcement Learning & Dynamic Programming:**
  * Bellman, R. (1957). *Dynamic Programming*. Princeton University Press. (The foundational Bellman Equations).
  * Watkins, C. J., & Dayan, P. (1992). *Q-learning*. Machine Learning, 8(3), 279–292. (Proof of Q-Learning convergence).
  * Rummery, G. A., & Niranjan, M. (1994). *On-line Q-learning using connectionist systems*. Cambridge University Technical Report. (SARSA algorithm).
