# MLAI401 — Topics 

1. Problem Formulation
          ↓
2. Search & Planning
   ├── Uninformed Search
   └── Informed / Heuristic Search
          ↓
3. Adversarial Search & Games
   ├── Game Formulation & Minimax
   ├── Alpha-Beta Pruning
   ├── Heuristics & Resource Limits
   └── Chance & Monte Carlo Tree Search (MCTS)
          ↓
4. Constraint Satisfaction
          ↓
5. Knowledge & Reasoning
   ├── Knowledge-Based Agents (Knowledge Base, TELL/ASK)
   ├── Logical Reasoning (Propositional Logic, Forward Chaining)
   ├── Probabilistic Reasoning (Bayes' Rule, Bayesian Networks)
   └── Temporal Reasoning (Hidden Markov Models — Concept Only)
          ↓
6. Learning & Decision Making
   ├── Machine Learning
   │   ├── Supervised Learning (Naive Bayes, Classification)
   │   ├── Neural Networks (Perceptron, Gradient Descent)
   │   └── Unsupervised Learning (K-means)
   ├── Markov Decision Processes (MDPs, Value Iteration)
   └── Reinforcement Learning (Q-learning)
          ↓
7. Generative & Agentic AI
   ├── Generative AI (LLMs, Prompting)
   ├── Retrieval-Augmented Generation (RAG)
   ├── Agentic AI
   │   ├── Tools
   │   ├── Memory
   │   ├── Planning
   │   ├── Act → Observe → Replan
   │   └── Multi-Agent Systems
   └── AI Ethics (Bias, Fairness, Reliability)

### demos
1. Vacuum World → Problem formulation / agents
2. Maze Abstraction → State-space formulation
3. 8-Puzzle State-Space → State-space formulation, reachability
4. Route Search → BFS, DFS, UCS, Greedy, A*
5. Game Tree & Board Visualizer → Minimax, Alpha-Beta, Cutoffs, MCTS
6. Map Coloring/Scheduling → CSP
7. Knowledge + Bayesian Reasoning → Knowledge, logic, uncertainty
8. Classification → ML
9. Grid World → RL
10. Goal-Driven Agent → LLM, tools, memory, planning, acting, replanning

### topic - subtopics and demo
| # | Topic | Demo | What the Demo Shows |
|---|---|---|---|
| 1 | Problem Formulation | Vacuum World | Goal, state, actions, transition model, goal test, path cost; reflex vs. problem-solving agent |
| 1 | Problem Formulation | Maze → State Space | Physical environment → abstraction → states → actions → graph |
| 1 | Problem Formulation | 8-Puzzle → State Space | Complete tile arrangement as a state; legal moves via the blank; 9! possible configurations vs. the 181,440 actually reachable |
| 2 | Search & Planning | Route-Finding Visualizer | One problem solved using BFS, DFS, UCS, Greedy Best-First, and A*; compare frontier, explored nodes, path, and cost |
| 2.1 | Uninformed Search | ↑ Route-Finding Visualizer | BFS/DFS use structure; UCS uses accumulated path cost `g(n)` |
| 2.2 | Informed Search | ↑ Route-Finding Visualizer | Greedy uses `h(n)`; A* uses `g(n) + h(n)`; role of heuristics |
| 3 | Adversarial Search & Games | Game Tree & Board Visualizer | Multi-agent competitive environments, game trees, and optimal decisions |
| 3.1 | Game Formulation & Minimax | ↑ Game Tree Visualizer | Formal game tuple, zero-sum utility, MAX vs. MIN turns, minimax value propagation |
| 3.2 | Alpha-Beta Pruning | ↑ Game Tree Visualizer | $[\alpha, \beta]$ search window, branch pruning ($\alpha \ge \beta$), and move ordering impact |
| 3.3 | Heuristics & Resource Limits | Board Evaluation Demo | Depth cutoff, heuristic evaluation function $\text{EVAL}(s)$, quiescence search, transposition tables |
| 3.4 | Chance & MCTS | Stochastic / MCTS Visualizer | Expectiminimax chance nodes, UCB1 selection, rollout simulation, backpropagation |
| 4 | Constraint Satisfaction | Map Coloring / Scheduling | Variables, domains, constraints, assignments, conflicts, and backtracking |
| 4.1 | Search → Games → CSP | ↑ CSP lecture (`csp.html#connections`) | All three explore possibilities, but the goal (path / best move / consistent assignment), the state representation (atomic / state + turn + utility / factored) and the solution change |
| 5 | Knowledge & Reasoning | Mini Knowledge Agent | Facts + rules → inference → new knowledge |
| 5.1 | Logic | ↑ Mini Knowledge Agent | Facts, predicates, rules, and inference |
| 5.2 | Probabilistic Reasoning | Bayesian Reasoning Demo | Prior → evidence → posterior; reasoning under uncertainty |
| 6 | Learning & Decision Making | Classification Demo | Data → features → training → model → prediction |
| 6.1 | Machine Learning | ↑ Classification Demo | Learning patterns from examples rather than explicitly programmed rules |
| 6.2 | Reinforcement Learning | Grid World Agent | State → action → reward → update; learning a better policy through interaction |
| 7 | Generative & Agentic AI | Goal-Driven AI Agent | Goal → reason → plan → act → observe → replan |
| 7.1 | LLMs | ↑ Goal-Driven AI Agent | Interpret goals, reason about tasks, and generate responses/plans |
| 7.2 | Tools | ↑ Goal-Driven AI Agent | Use external tools as available actions |
| 7.3 | Memory | ↑ Goal-Driven AI Agent | Store and retrieve information needed across steps |
| 7.4 | Planning | ↑ Goal-Driven AI Agent | Break a goal into subtasks and determine next actions |
| 7.5 | Act → Observe → Replan | ↑ Goal-Driven AI Agent | Execute actions, observe results, detect failure/success, and update the plan |
| 7.6 | Multi-Agent Systems | Two-Agent Task | Task delegation, communication, coordination, and combining results |