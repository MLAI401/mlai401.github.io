# C++ Fundamentals

## Goal

One **single** C++ Fundamentals page that shows how the core C++ concepts work together: how data enters a program, is represented and stored, is accessed and manipulated, is passed between functions, and leaves the program.

```text
Concept
├── Data-Flow Demo
├── Topic Buttons → Interactive Topic Demo
└── Code Sandbox
    ├── Subtopic Tabs
    ├── Code Editor
    └── Terminal
```

**Requirements**

- Keep demos visual, compact, and interactive; minimal explanation text.
- Use existing examples from `cpp_demo_sandbox/` where applicable; if a
  `.cpp` file is missing or empty, create it there (use cppreference.com
  as the technical reference).
- Ignore any `.cpp` file whose name contains `test`.
- Keep C++ example lines short (readable on a projected, wrapped editor) —
  move trailing comments to their own line, split long `cout <<` chains,
  rather than one wide line.
- Everything updates **in place**; no navigation away from the page.

---

## Topics

| Group | Subtopics |
|---|---|
| Console I/O | `cout`, output buffering, `cin`, `getline()` |
| String | `string`, `[]`/`at()`/`find()`/`substr()`, storage / SSO |
| File I/O | `ofstream` (program → file), `ifstream` (file → program), checking a stream is open |
| String Stream | `istringstream`, `stringstream`, parsing with `>>` |
| Vector | adding, accessing, storing multiple values, initialization|
| Reference | reference/aliasing (two names for one object, changing through a reference), pointer/dereferencing, pass-by-value vs. pass-by-reference (by value, by reference, by pointer), combined exercise (reference, copy, and pointer together in one trace) |
| Function | declaration vs. definition, parameters & return values, default arguments, overloading, recursion |
| Integrated Examples | demo 0: vector-to-reference; demo 1: loop copy vs. reference; demo 2: read copy vs. const reference; demo 3: value vs. reference vs. pointer parameters; demo 4: vector + function + reference |

---

## Data-Flow Demo

One interactive overview at the top of the page:

```text
Keyboard → Console Input → C++ Program → Console Output → Screen
File     → File Input    → C++ Program → File Output    → File
```

Also connect the program visually to String, String Stream, Vector, Function,
Reference, and Integrated Examples. Every node is clickable; clicking selects
that topic group and updates the rest of the page below it.

---

## Interactive Topic Demo (String, String Stream, Vector, Function, Reference, Integrated Examples)

Sits between the subtopic tabs and the Code Sandbox — a small, visual
"what does this feature do" panel, separate from the Code Sandbox's
"how do I write it" role. Keep it compact; it is not another code
editor.

Selecting a group (`[String] [String Stream] [Function][Vector] [Reference] [Integrated Examples]`):

1. Marks that button active.
2. Updates this Demo for the selected topic.
3. Loads the matching example into the Code Sandbox.
4. Does **not** auto-run the code.
5. Stays on the same page.

Every topic's demo shares a **Header** (topic name + a short subtitle,
no paragraphs) and stays compact — never another code editor. The rest
of the layout follows one of two shapes, per group/topic:

**Integrated Examples demo 0, Reference's "combined exercise"** —
"Trace the Code" stepper:

- **Step counter** (`Step N of M`) with Prev / Next / Reset controls.
- **Code panel** — the exact snippet, one line highlighted per step —
  paired with a one-line "What's happening?" explanation.
- **Variables (Memory) panel** — one box per variable, updated live;
  a reference or pointer variable renders as a dot with an arrow to the
  variable it refers to, tagged `(reference)` or `(pointer)`.
- **Remember** — a short, static list of takeaways, always visible.
- **Program Output** — revealed once the trace reaches its last step.

Integrated Examples demo 0 is its own self-contained lesson, same as
every other Integrated Examples subtopic. Reference's "combined
exercise" is different: it keeps the exact stepper that used to be
shared, as `group.demo`, across *every* Reference subtopic (demoTrace()
in `09_reference.cpp` -- reference, copy, and pointer put together in
one trace), now moved as-is into just this one subtopic's `topic.demo`
while Reference's other four subtopics get their own fresh demos below.

**String, String Stream, Vector, Reference, Function, Integrated
Examples demo 1, 2, 3, 4** — control-flow diagram with live variables
(one or more code blocks, generalized to any number of blocks, beside a
Variables panel rather than below the code). Every group below is
per-topic -- one demo per subtopic, grounded in that subtopic's own
literal Code Sandbox code, rather than one example shared across every
tab in the group:

- **One or more code blocks**, laid out beside a Variables (Memory) panel
  (not below it, unlike the Trace the Code shape) rather than one below
  the other:
  - **String** — `string` and storage/SSO are one block only (`main()`,
    no callee); `[]`/`at()`/`find()`/`substr()` is two blocks -- caller
    `main()` plus callee `firstword(string input)`, since that subtopic's
    example calls a helper function.
  - **String Stream** — `stringstream` is two blocks -- caller `main()`
    (building output with `ostringstream`, then parsing it back with
    `istringstream`) plus callee `firstword(string input)` (which does
    its own `istringstream` parse); parsing with `>>` is one block only
    (`main()`), stepping one loop iteration of `while (iss >> value)` per
    operation button.
  - **Vector** — `initialization` is one block only (`main()`), the 6
    construction styles (default, empty brace-init, brace-init list,
    size ctor, size + fill ctor, copy ctor) stepped one per operation
    button; `vector-basic` and `vectors of different types` are the
    same shape, stepping one `push_back()`/access call, or one element
    type, per operation button -- the same "one button per iteration"
    idea String Stream's loop demo uses. (`vecToString(vector<int> v)`,
    previously traced as this subtopic's callee block, moved to the
    Practice Test's `basics-io` question set as Q9 -- see
    `cpp_demo_sandbox/00_basic_test.cpp` and `instructions/00_test.md`.)
  - **Reference** — one demo per subtopic instead of the single shared
    "Trace the Code" stepper every subtopic used to show before (that
    stepper survives, but only on the "combined exercise" subtopic --
    see above): `two names-one object` and `reference-mutation` are
    each one block only (`main()`, no callee), the same shape as
    Vector's `initialization`, since both are variations stepped
    within a single `main()`; `pointer` is also one block only, but its
    last two operations re-point `ptr` at a second variable (`other`)
    instead of `score` -- the one Reference subtopic that shows a
    pointer being re-seated, which a reference can never do; `pass by
    value vs. by reference` is four blocks -- caller `main()` plus one
    per callee (`printAndSetNoRef`, `printAndSetRef`, `printAndSetPtr`),
    the same shape as Integrated Examples demo 3 (see below), grounded
    in this subtopic's own code (`ref = 5` and `x`/`y`, rather than demo
    3's `ref += 5` reusing `x` for all three calls).
  - **Function** — one demo per subtopic instead of the single shared
    `square(int n)` trace every subtopic used to show before: `declaration
    vs. definition` is two blocks (`main()` + `square`), the simplest
    case; `parameters & return values` is three blocks -- caller `main()`
    plus two callees, `addAndDouble` (returns a value) and `printLine`
    (returns void), contrasting the two return styles; `default
    arguments` is two blocks, calling `power()` twice in one trace --
    once omitting the second argument, once passing it explicitly -- to
    show the default get used, then overridden; `function overloading` is
    four blocks -- caller `main()` plus one block per overload (`int`,
    `double`, `string`), so which "callee" lights up depends on argument
    types; `recursion` is two blocks, but the callee block
    (`factorial(int n)`) represents every recursive call -- the same
    block is reused at each depth, with the Variables panel's `n` box and
    a `(depth N)` tag standing in for the call stack as the trace
    descends `factorial(3) → factorial(2) → factorial(1)` and back out.
  - **Integrated Examples demo 1, demo 2** — one block only (`demo2()` /
    `demo3()`): these compare loop styles within a single function, not
    function calls, so there is no callee to jump to and no arrow. Each
    loop style steps one vector element per operation button (the same
    "one button per iteration" idea String Stream's loop demo and
    Vector's construction-style demos use), so the Variables panel shows
    `vec`/`names` update -- or visibly not update -- element by element
    as the loop runs, not just the loop's before/after snapshot: demo 1
    is 3 declare/summary-free elements × 5 loop styles (index, range
    copy `int`, range reference `int&`, range copy `auto`, range
    reference `auto&`) = 15 steps plus the initial declare; demo 2 is 3
    elements × 3 loop styles (copy `string`, reference `string&`, const
    reference `const string&`) = 9 steps plus the initial declare.
  - **Integrated Examples demo 3** — four blocks: caller `main()` plus one
    per callee (`printAndSetNoRef`, `printAndSetRef`, `printAndSetPtr`).
  - **Integrated Examples demo 4** — six blocks: caller `demo4()` plus its
    five helper functions (`updateCopy`, `updateOriginal`,
    `updateElementCopies`, `updateElements`, `makeUpdated`).
  - Only the caller and the currently-relevant callee (when there is one)
    are highlighted at any step.
  - **Layout**: with exactly one callee (String's `common string
    operations`, String Stream's `stringstream`, Vector's
    `initialization`, Function's `declaration vs. definition`, `default
    arguments`, and `recursion`), the caller and its one callee sit side
    by side in a single row -- there's no grid to fill, so stacking them
    would waste vertical space. With two or more callees (Function's
    `parameters & return values` and `function overloading`, Reference's
    `pass by value vs. by reference`, Integrated Examples demo 3 and
    demo 4), the callees instead sit in their own row below the caller,
    as a grid (3 per row). A demo with no callee at all (String's
    `string`/storage-SSO, Vector's `vector-basic` and `vectors of
    different types`, String Stream's parsing subtopic, Reference's
    `two names-one object`, `reference-mutation`, and `pointer`,
    Integrated Examples demo 1 and 2) shows just the one block.
- **Step controls** — numbered operation buttons move a highlighted line
  between blocks, with a directional arrow + label (e.g. `i = 10 (copy)`,
  `ref = x`, `v (reference)`) showing control and the argument passing
  from the caller into a callee and back, when the demo has callees.
- **Variables (Memory) panel** — the same live variable boxes as the
  Trace the Code shape, updated with every step; a plain value can also
  carry a short tag (e.g. `(copy, int e)`, `(index, last i)`) alongside
  the `(reference)` / `(pointer)` tag already used for aliases.
- No Result line beyond the shared one-line explanation; no Remember
  list or Program Output panel.

---

## Topic Selection & Code Sandbox

The Code Sandbox is part of this page, not a separate page or section —
no "Code Sandbox" heading, no restated instructional text (e.g. "Select
Topic → Demo → Run"), and no topic-group/topic-list card repeated above
it. Subtopic tabs are docked **above the Interactive Topic Demo**, not
on top of the sandbox editor/terminal, so picking a demo reads top to
bottom — pick it, see it explained, then see and run its code:

```text
        Subtopic Tabs
┌─────────────────────────────────────────────────┐
│ cout │ output buffering │ cin │ getline()       │
└─────────────────────────────────────────────────┘
      ↓
Interactive Topic Demo
      ↓
┌─────────────────────────────────────────────────┐
│      Code Editor       │       Terminal         │
├────────────────────────┴────────────────────────┤
│               Sandbox Controls                  │
└─────────────────────────────────────────────────┘
```

- Editor and Terminal are **side by side**, both visible at once; `Run`
  sits above the Terminal.
- Selecting a subtopic tab: highlights it, updates the Demo, loads that
  `.cpp` example into the editor, and lets the instructor edit, Run
  (compile + execute), give interactive `cin` input, see `cout` output
  and compiler/runtime errors in the Terminal, and Reset to the original.
- Console I/O and File I/O have no Interactive Topic Demo (see that
  section) — their subtopic tabs sit directly above the Code Sandbox
  instead, with nothing in between.
- No navigation to another page on any of the above.

---

## Page Flow

```text
Data-Flow Demo
      ↓
Topic Group Buttons
      ↓
Subtopic Tabs
      ↓
Interactive Topic Demo   (String / String Stream / Vector / Function / Reference /
                          Integrated Examples -- skipped for Console I/O / File I/O)
      ↓
Code Sandbox (Editor | Terminal)
```

Prioritize visualization → code → execution → observable behavior over
C++ theory; keep all explanatory text short.
