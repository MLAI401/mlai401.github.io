# MLAI401 - Maze Search Performance & Evaluation

## Goal

An interactive, concept-first **Maze Search Demo** (`maze_search.html` / visualizer module) that uses physical and abstract maze environments to teach and demonstrate the core **Search Performance and Evaluation Concepts** from AIMA:
1. **Time Complexity** (nodes generated and expanded)
2. **Space Complexity** (peak frontier and reached set memory footprint)
3. **Completeness** (guarantee of finding a path or correctly terminating)
4. **Optimality** (guarantee of finding the lowest-cost solution path $C^*$)

---

## Layout & Architecture

The page follows the standardized MLAI401 single-viewport, concept-first lecture interface:
* **Top Bar**: Breadcrumb (`Topic 02: Search & Planning > Maze Search`) and page title.
* **Topic Selector Bar**:
  `Evaluation Criteria | Uninformed Search in Mazes | Informed Search in Mazes | Performance Comparison`
* **Two-Column Split Area**:
  * **Concept Column (50%, Left)**: Definition, AIMA formal notation, live formula derivation, and real-time teaching tips.
  * **Illustration / Visualizer Column (50%, Right)**: Interactive 2D maze visualizer, search tree generation, live frontier queue/stack inspection, and real-time performance metric monitors.
* **Design & Typography Consistency**: Use the shared MLAI401 design tokens (`Outfit` / `Plus Jakarta Sans`, CSS variables `--primary`, `--bg-surface`, `--text-primary`, `--border-light`).

```
┌────────────────────────────────────────┬────────────────────────────────────────┐
│               CONCEPT                  │              ILLUSTRATION              │
│                                        │                                        │
│  Concept Selector Bar                  │  2D Maze Grid / Abstract Graph         │
│  Definition & Evaluation Metrics       │  Live Frontier & Reached Visualizer    │
│  AIMA Formula & Complexity Bounds      │  Step-by-Step Interactive Search       │
│  Live Teaching Tip & Step Summary      │  Real-Time Complexity Metric Dashboard │
│                                        │                                        │
└────────────────────────────────────────┴────────────────────────────────────────┘
```

---

## Core Evaluation Concepts & Formulations

The demo explicitly breaks down the 4 key evaluation criteria using maze-specific examples and parameters.

| Concept | Definition | AIMA Formula / Notation | Teaching Tip | Maze Illustration & Visualizer Behavior |
|---|---|---|---|---|
| **Evaluation Terminology** | Key parameters defining state space geometry and cost structure. | $b$ = branching factor (intersections: 1–3 choices)<br>$d$ = depth of shallowest solution<br>$m$ = maximum search depth / longest path<br>$C^*$ = optimal solution path cost<br>$\varepsilon$ = minimum corridor step cost ($\ge 1$) | Emphasize that $d$ and $m$ describe graph/tree depth, while $C^*$ and $\varepsilon$ describe corridor travel costs. | Display the maze with annotated decision points, highlighting the branching choices ($b$), shortest branch depth ($d$), deepest branch ($m$), and corridor edge weights ($\varepsilon$). |
| **Time Complexity** | The computational effort measured by the number of nodes expanded and generated. | $\text{BFS: } O(b^d)$<br>$\text{DFS: } O(b^m)$<br>$\text{IDS: } O(b^d)$<br>$\text{UCS: } O(b^{1 + \lfloor C^*/\varepsilon \rfloor})$<br>$\text{Greedy: } O(b^m) \text{ worst-case}$<br>$\text{A}^*: O(b^d) \text{ with admissible } h$ | Time reflects how many corridor branches the search is forced to explore before hitting the goal. | Animate the wavefront of explored cells/nodes. Live counter tracks **Nodes Generated** and **Nodes Expanded**. Compare DFS wandering down a dead-end corridor vs BFS checking radially. |
| **Space Complexity** | The maximum memory required during search (peak size of frontier $+$ reached set). | $\text{BFS: } O(b^d) \text{ (High)}$<br>$\text{DFS: } O(b \cdot m) \text{ (Low)}$<br>$\text{IDS: } O(b \cdot d) \text{ (Minimal)}$<br>$\text{UCS: } O(b^{1 + \lfloor C^*/\varepsilon \rfloor}) \text{ (High)}$<br>$\text{A}^*: O(b^d) \text{ (High)}$ | Memory is often the true bottleneck in search—BFS and A* store entire exploration frontiers; DFS and IDS only store the active path. | Show a live memory gauge and visual container of the frontier. Highlight the dramatic difference: BFS frontier grows exponentially with distance, while DFS stack remains slim. |
| **Completeness** | The guarantee that the search will find a solution if one exists, or report failure if none exists. | $\text{Solution Exists} \implies \text{Found}$<br>Graph Search: Safe via `reached`<br>Tree Search: Prone to cycles | In a maze with loops/corridors, tree search without a `reached` table can get stuck in infinite cycles. | Demonstrate a cyclic corridor: toggle between Tree-Like Search (infinitely looping in a corridor loop) and Graph Search (detecting duplicate states via `reached` and terminating safely). |
| **Optimality** | The guarantee that the search will return the path with the lowest cumulative cost ($C^*$). | $C(\text{Path}) = C^*$ | Finding *a* path quickly does not mean finding the *shortest* or *cheapest* path. | Maze features two distinct paths: a short-in-nodes but expensive-in-distance corridor vs a longer-in-nodes but cheap corridor. Contrast BFS picking fewest hops vs UCS/A* finding the true minimal distance $C^*$. |

---

## Maze Topology Requirements for Comparative Evaluation

To effectively contrast the performance differences, the maze must not be a single trivial corridor. It must feature:
1. **Multiple Alternative Routes to Goal $G$**:
   * **Route 1 (Shallow but Long Cost)**: Few turning points/hops (small depth $d$), but long physical corridors (high cost, e.g., cost = 28).
   * **Route 2 (Deep but Low Cost / Optimal $C^*$)**: More turning points (larger depth $d+3$), but shorter physical corridors (low cost, e.g., cost = 16).
   * *Purpose*: Clearly illustrates why **BFS is not optimal for non-uniform step costs**, while **UCS and A\*** find the true optimal path $C^*$.
2. **Deep Misleading Dead-End Branches (Heuristic Traps)**:
   * A branch that heads directly toward the coordinate direction of the goal (low Manhattan distance $h$), but ends in a dead-end wall.
   * *Purpose*: Demonstrates **Greedy Best-First Search** rushing into the dead-end trap due to over-reliance on $h(n)$, expanding unnecessary nodes, while **A\*** balances $g(n) + h(n)$ to avoid being misled.
3. **Corridor Loops / Cycles**:
   * Interconnecting corridors allowing cycles.
   * *Purpose*: Demonstrates the necessity of the `reached` set for **Completeness**.

---

## Search Algorithms in Action

| Algorithm | Selection Rule & Data Structure | Time | Space | Complete? | Optimal? | Behavior on the Maze |
|---|---|---|---|---|---|---|
| **Breadth-First Search (BFS)** | FIFO Queue<br>$f(n) = \text{depth}(n)$ | $O(b^d)$ | $O(b^d)$ | Yes (if $b < \infty$) | Yes (unit costs only) | Explores outward evenly in all directions. Finds the route with the fewest corridor segments, even if physical distance is longer. High memory usage. |
| **Depth-First Search (DFS)** | LIFO Stack<br>$f(n) = -\text{depth}(n)$ | $O(b^m)$ | $O(b \cdot m)$ | Yes (graph search) / No (tree search in loops) | No | Plunges deep into one corridor branch to the end. Fast if lucky; can explore the entire maze worst-case. Extremely small memory footprint. |
| **Iterative Deepening (IDS)** | Repeated Depth-Limited DFS<br>$\text{limit} = 0, 1, 2, \dots$ | $O(b^d)$ | $O(b \cdot d)$ | Yes | Yes (unit costs only) | Combines BFS's shallow optimality with DFS's minimal memory space. Re-explores shallow corridors with increasing depth limits. |
| **Uniform-Cost Search (UCS)** | Priority Queue by $g(n)$<br>$f(n) = g(n)$ | $O(b^{1 + \lfloor C^*/\varepsilon \rfloor})$ | $O(b^{1 + \lfloor C^*/\varepsilon \rfloor})$ | Yes | Yes (general costs $\varepsilon > 0$) | Expands strictly in order of cumulative distance traveled from Start. Ignores hop count; guaranteed to find the true lowest physical path cost $C^*$. |
| **Greedy Best-First** | Priority Queue by $h(n)$<br>$f(n) = h(n)$ (Manhattan) | $O(b^m)$ | $O(b^m)$ | Yes (graph search) | No | Uses Manhattan distance heuristic to rush toward Goal coordinates. Vulnerable to dead-end wall traps. Suboptimal path cost. |
| **A\* Search** | Priority Queue by $f(n)$<br>$f(n) = g(n) + h(n)$ | $O(b^d)$ | $O(b^d)$ | Yes | Yes (admissible $h$) | Perfectly balances distance covered $g(n)$ with remaining estimate $h(n)$. Prunes unpromising corridors and achieves optimal cost $C^*$ with fewer expansions than UCS. |

---

## Interactive Controls & Visualizer Modules

### 1. Maze Search Stepper Controls
* **Algorithm Selector**: Dropdown / pill tabs (BFS, DFS, IDS, UCS, Greedy, A*).
* **Execution Stepper**:
  * `Play / Pause` (Auto-advance search steps with adjustable speed slider: 50ms – 1000ms).
  * `Step Next` ($\rightarrow$) & `Step Back` ($\leftarrow$) for single node expansion stepping.
  * `Reset` to restore initial state.
* **Goal Test Mode**: Toggle between **Standard Goal Test** (on node selection from frontier) and **Early Goal Test** (on child node generation).

### 2. Live Synchronized Data Displays
* **Canvas Visualizer**:
  * Highlighted node states: `Current Selected` (Purple pulse), `Frontier` (Amber halo), `Reached / Explored` (Faint Indigo glow), `Solution Path` (Vibrant Emerald line).
* **Frontier Visual Container**:
  * Real-time FIFO / LIFO / Priority Queue element cards showing `Node ID`, $g(n)$, $h(n)$, and $f(n)$.
* **Live Metric Cards**:
  1. **Nodes Expanded**: Counter and progress bar relative to state space size.
  2. **Peak Frontier Memory (Space)**: Peak number of nodes stored simultaneously.
  3. **Current Path Cost $g(n)$**: Accumulated path cost of the active node.
  4. **Solution Path Cost**: Final cost when Goal is reached vs. Optimal Cost $C^*$.
  5. **Optimality Status**: Badge showing `Optimal Path Found ($C^*$)` or `Suboptimal Path`.

### 3. Side-by-Side Algorithm Comparison Mode
* Allows selecting any **two algorithms** (e.g., **BFS vs UCS** or **Greedy vs A\***) to run simultaneously on the same maze side-by-side.
* Directly contrasts how heuristic guidance reduces expanded nodes (Time) and how cost-awareness guarantees $C^*$ (Optimality).

---

## Summary Comparison Matrix (Dynamic Table)

| Algorithm | Selection Priority | Frontier Structure | Nodes Expanded (Time) | Peak Memory (Space) | Solution Path Cost | Optimal? |
|---|---|---|---|---|---|---|
| **BFS** | Fewest hops ($\text{depth}$) | FIFO Queue | Moderate | High ($O(b^d)$) | 28 (Suboptimal) | No (unit only) |
| **DFS** | Most recent (deepest) | LIFO Stack | High / Variable | Minimal ($O(bm)$) | 34 (Suboptimal) | No |
| **IDS** | Iterative depth | LIFO Stack | Moderate | Minimal ($O(bd)$) | 28 (Suboptimal) | No (unit only) |
| **UCS** | Lowest path cost $g(n)$ | Priority Queue | High | High | **16 ($C^*$)** | **Yes** |
| **Greedy** | Lowest heuristic $h(n)$ | Priority Queue | Low–Moderate | Moderate | 22 (Suboptimal) | No |
| **A\*** | Lowest $f(n) = g(n) + h(n)$ | Priority Queue | **Lowest** | Moderate–High | **16 ($C^*$)** | **Yes** |
