# MLAI401 - Search & Planning

## Goal

One **single** Search & Planning lecture page, `search_planning.html`, that
explains how a search problem (already formulated on Topic 01) gets
*solved*.

Layout: single viewport, concept-first

The page is a fixed-height shell below the navbar, built to need no page
scrolling on a normal desktop or projector screen:

* A slim top bar — a "Search and Planning" breadcrumb and the page title.
* A simple topic selector bar : 
Search Terminology | Search Data Structures | Search Strategies | Evaluating Search
* A two-column main area below the topic tabs:
  * Concept column (50%, left) — the current step's definition, formal
    notation, and a live teaching tip.
  * Illustration column (50%, right) — visual/supporting illustration
    for the current concept.
  * Both columns must remain visually balanced.
  * **Typography consistency:** the Concept and Illustration columns must
    draw from the same font stack, sizes, weights, and color tokens
    (Outfit/Plus Jakarta Sans, `--text-primary/secondary/muted`, etc.) —
    never a stray unstyled control quietly falling back to the browser
    default font. Neither column should read as more prominent than the
    other purely because of type choices.

┌──────────────────────────────┬──────────────────────────────┐
│          CONCEPT             │        ILLUSTRATION          │
│                              │                              │
│  Concept Selector bar        │                              │
│  Definition                  │     Fixed Search Graph       │
│  AIMA Formula / Notation     │                              │
│  Teaching Tip                │     Dynamic Highlighting     │
│                              │                              │
└──────────────────────────────┴──────────────────────────────┘

**Concept Selector:** If the concept selector becomes too long (more than 6) to fit comfortably in one row, wrap the concepts into **two or three balanced rows** rather than shrinking the font size or overcrowding the layout.

### Search Terminology

Introduce the core terminology used in search algorithms. Do not create separate pages or subtopics for each term.

Include a brief introduction explaining that these terms describe how a search algorithm explores a state space and keeps track of what has already been explored and what remains to be explored.In teaching tip, where applicable, include the current values in a simple programming-style notation, e.g., `frontier = {A, B, C}`, `reached = {A, B, C, D}`, `expanded = {A}`, so students can connect the visual search process to its data representation.

Show both the **state-space graph** and the corresponding **search tree** side by side, with matching highlights — the same states/paths highlighted in the graph and the matching nodes/branches highlighted in the search tree. Show both the state-space graph and search tree for all concept pages. 

| Concept | Definition | Notation | Teaching Tip | Illustration Note |
|---|---|---|---|---|
| **Search Tree** | The tree built as search explores the state-space graph. | `search tree ≠ state-space graph` | The same state can appear in more than one search-tree node. | Show the state-space graph and corresponding search tree side by side, including repeated states. |
| **State: Initial → Goal** | A state represents a possible situation; search starts at the initial state and seeks a goal state. | `s ∈ S` · `problem.INITIAL` · `IS-GOAL(problem, s)` | Think: **Where can I be? Where do I start? Where do I want to reach?** | Show the graph with the initial state, an intermediate state, and goal state clearly identified. |
| **Expansion: Successor & Child Node** | Expanding a node applies available actions to produce successor states and corresponding child nodes. | `EXPAND(node)` · `RESULT(s,a)=s′` · `CHILD-NODE(...)` | **Successor** is a state; **child** is a search-tree node representing that state. | Show graph + search tree. Expand A and highlight all successor states and corresponding child nodes. |
| **Reached, Expanded & Frontier** | Reached states have been discovered; expanded nodes have generated their children; frontier nodes are reached but still waiting to be expanded. | `reached` · `expanded` · `frontier` | **Reached** does not mean **expanded**. Frontier nodes have been reached but are still waiting. | Use one search snapshot and visually distinguish reached, expanded, frontier, and unreached regions. Show their current sets in the notation box. |
| **Expansion Order** | The order in which nodes are selected and expanded. | `n₁ → n₂ → n₃ → ...` | `A → B → C` means A was expanded first, then B, then C. | Place numbered badges `1, 2, 3, ...` on expanded nodes in both the graph and search tree. |
| **Redundant Path** | A different path that reaches a state already reached. | `node.STATE ∈ reached` | Different paths can lead to the same state. | Highlight two different paths reaching the same state; show the duplicate occurrence in the search tree. |
| **Tree-Like vs. Graph Search** | Tree-like search can revisit states; graph search uses `reached` to detect repeated states. | Tree-like: `frontier` only · Graph: `reached[state] = node` | The key difference is whether previously reached states are remembered. | Show the same redundant path twice: tree-like search keeps it; graph search detects/prunes it using `reached`. |

### Search Data Structures

Provide the brief data structure concepts needed to understand how search algorithms store, select, and manage nodes during search. The illustration must be interactive and synchronized with the pseudocode and data structures.** Clicking a pseudocode line or an operation such as `POP`, `ADD`, or `TOP` should immediately illustrate that operation on the graph/search tree and show how the corresponding variables change, e.g., `node`, `frontier`, `reached`, and path cost. The left-hand Definition/Teaching Tip explanation is not a static caption — it is also part of the interaction: it must update to explain whichever step the click just produced, not stay fixed on the concept's general definition while only the graph/tree on the right animates.

| Concept | Definition | Notation | Teaching Tip | Illustration Note |
|---|---|---|---|---|
| **Node Structure** | A search node stores the state and information about how it was reached. | `node.STATE` · `node.PARENT` · `node.ACTION` · `node.PATH-COST = g(node)` | Show actual values, e.g., `STATE = C`, `PARENT = A`, `ACTION = Go(C)`, `PATH-COST = 2`. | Highlight one node in the search tree and show its four fields; connect the node to its state, parent, action, and path in the graph. |
| **Frontier Operations** | The frontier stores nodes waiting to be explored and provides operations to inspect, add, and remove nodes. | `IS-EMPTY(frontier)` · `TOP(frontier)` · `POP(frontier)` · `ADD(node, frontier)` | Use programming-style values, e.g., `frontier = {B, C, D}`; demonstrate how each operation changes—or does not change—the frontier. | Show a frontier container beside the graph. Run `IS-EMPTY`, `TOP`, `POP`, and `ADD` as one click-through sequence (Run/Prev/Next, a logged operation, or a node on the graph), updating the displayed frontier after each operation. The Definition/Teaching Tip side is part of the same illustration: it must swap to a sentence explaining THAT operation, and highlight that operation's own notation, so the explanation never sits frozen on one operation while the graph moves through four. |
| **Frontier Types** | The frontier's ordering rule determines which node is selected next. | FIFO: first-in-first-out · LIFO: last-in-first-out · Priority: lowest priority first | With the same starting frontier `{B, C, E}`, run FIFO, LIFO, and Priority Queue side by side over several `POP`/`ADD` cycles — not just one selection — and let the class see each one's own small search tree grow. | Run all three structures over the SAME graph from the SAME starting frontier, one shared Run/Prev/Next control advancing all three together (click a frontier box or a tree node to jump straight to a given point in that structure's own run). Each structure keeps its own small search tree beside its frontier container, so their differing NATURE is visible directly: FIFO's tree grows level by level (breadth-first) and takes the most expansions; LIFO's tree dives straight down whatever it discovered most recently and can reach the goal in very few expansions while never even looking at some nodes; Priority's tree always grows toward the cheapest known node and is the only one guaranteed to reach the goal at its true lowest cost. The left-hand Definition/Teaching Tip explanation updates every tick with one sentence naming what all three structures are doing at that same moment, since that side-by-side contrast — not a single frozen definition — is what actually teaches the difference. |
| **Putting It Together** | Trace how the search data structures work together during execution, starting from the algorithm's true initial state — before `node`, `frontier`, or `reached` even exist. | `POP → GOAL-TEST → EXPAND → ADD / UPDATE` | Every numbered pseudocode line is its own step — even creating the initial node and initializing an EMPTY frontier and EMPTY reached are separate steps — so the trace never skips ahead of what the algorithm has actually done. | Show numbered BFS and UCS pseudocode (line numbers 1–11, matching AIMA's BEST-FIRST-SEARCH) starting from node A with frontier and reached both genuinely empty. Advance ONE PSEUDOCODE LINE AT A TIME with Prev/Next (41 BFS micro-steps, 36 UCS micro-steps, independently verified). Clicking any numbered line jumps straight to the NEXT time that exact line fires (wrapping around), so the graph and the `node`/`frontier`/`reached`/expansion-order readout immediately reflect the program's actual state at that line — not just "advance by one." Clicking a highlighted node on the graph jumps straight to the micro-step where that node was POPped. The left-hand explanation updates every micro-step with a sentence describing exactly what that line just did (e.g., "E was already reached at a higher cost — 7 is cheaper, so reached[E] and its frontier entry are updated" for a UCS cost update), not a single static definition. |

### Search Strategies

Introduce how different search strategies decide **which node to select next from the frontier**.

Each of the 8 algorithms runs **live, in the browser**, exactly like the Playground's own Route-Finding Visualizer — not a precomputed/canned trace. `demos/search_planning_demo/city_engine.js` is a city-relabeled, otherwise byte-for-byte copy of the already-verified Playground engine (`demos/search_demo/graph.js`); loading a real copy of that engine (instead of re-implementing the algorithms by hand) guarantees this page's search behavior can never diverge from the Playground's. Do not reuse the abstract A–H graph from the Playground — the illustration uses real city names so the search feels like a route-finding problem.

Every algorithm's stepper carries the same controls as the Playground: **Start/Goal selectors** (pick any of the 8 cities as start and goal — the SMA* row also gets its own memory-bound selector), **Prev/Next** to step one recorded event at a time, an **Auto-Run/Pause** button that walks the run on a timer, and a **Reset** button back to step 0. The frontier is shown as **visual blocks** (not plain text) — highlighting whichever item will be popped next, split into two rows (Forward/Backward) for BiBF's dual search — plus a compact **step table** listing every significant decision point (selected node, expanded?, frontier, reached), populated up to the current step and auto-scrolled to the bottom, mirroring the Playground's own step table. Picking two cities with no directed path between them (the city graph's edges are one-way, same as the Playground's abstract graph) ends the run in a graceful "no solution found" state instead of erroring.

Because start/goal are user-selectable, the two non-algorithm illustrations below (Uninformed vs. Informed Search, and Goal Test) stay **fixed reference frames**, pulled from one cached NYC → LAX run — they exist to teach a fixed point of comparison, not to be explored themselves.

| Concept | Definition | AIMA Formula / Notation | Teaching Tip | Illustration Note |
|---|---|---|---|---|
| **Uninformed vs. Informed Search** | Uninformed search uses no heuristic; informed search uses an estimate of distance/cost to the goal. | Uninformed: no `h(n)` · Informed: uses `h(n)` | `g(n)` = cost so far; `h(n)` = estimated cost remaining. | Fixed snapshot, no stepper: the SAME frontier after NYC is expanded, shown two ways — uninformed (left) labels each successor with `g(n)` only; informed (right) adds `h(n)`, using the real heuristic values the algorithms below use. |
| **Breadth-First Search (BFS)** | Expands the shallowest node first. | `f(n) = depth(n)` | Explore cities one level away before going farther. | Interactive LIVE stepper (16 steps with the default NYC-LAX; pick any Start/Goal to re-run it live). FIFO frontier, EARLY goal test — LAX is recognized the instant it is generated as ATL's successor (NYC-ATL-LAX, cost 10), even though that is not the cheapest path. |
| **Depth-First Search (DFS)** | Expands the deepest node first. | `f(n) = -depth(n)` | Follow one route as far as possible before backtracking. | Interactive LIVE stepper (20 steps with the default NYC-LAX; pick any Start/Goal to re-run it live). LIFO frontier, STANDARD goal test; successors are pushed in reverse-alphabetical order so the stack still pops them alphabetically. |
| **Uniform-Cost Search (UCS)** | Expands the node with the lowest path cost. | `f(n) = g(n)` | Select the city with the cheapest total travel cost so far. | Interactive LIVE stepper (39 steps with the default NYC-LAX; pick any Start/Goal to re-run it live). Priority queue ordered by `g(n)`, STANDARD goal test; watch NYC-ATL get superseded by the cheaper NYC-CHI-ATL route, ultimately finding the truly optimal path NYC-CHI-DEN-LAX at cost 8. |
| **Iterative Deepening Search (IDS)** | Repeats depth-limited search with increasing limits. | `limit = 0, 1, 2, ...` | Search nearby depths first, then gradually allow longer routes. | Interactive LIVE stepper (48 steps with the default NYC-LAX; pick any Start/Goal to re-run it live). Depth-limited DFS restarted from scratch with `limit = 0, 1, 2, ...`; a limit badge climbs and the frontier visibly resets at the start of every iteration. |
| **Bidirectional Search** | Searches from the start and goal until the two searches meet. | `Forward ∩ Backward ≠ ∅` | Search from both cities and try to meet in the middle. | Interactive LIVE stepper (46 steps with the default NYC-LAX; same live run as BiBF below, told conceptually). A FORWARD search from NYC and a BACKWARD search from LAX run at once, each direction tagged on the graph, until a city has been reached from both directions and no remaining combination could beat the best meeting cost found. |
| **Greedy Best-First Search** | Expands the node estimated to be closest to the goal. | `f(n) = h(n)` | Choose the city that appears closest to the destination. | Interactive LIVE stepper (20 steps with the default NYC-LAX; pick any Start/Goal to re-run it live). Priority queue ordered by `h(n)` alone, ignoring `g(n)` entirely; lands on NYC-ATL-LAX (cost 10) because ATL looks close to LAX, without weighing what it cost to reach ATL in the first place. |
| **A\*** | Expands the node with the lowest estimated total solution cost. | `f(n) = g(n) + h(n)` | Balance distance already traveled with estimated distance remaining. | Interactive LIVE stepper (39 steps with the default NYC-LAX; pick any Start/Goal to re-run it live). Priority queue ordered by `f(n) = g(n) + h(n)`; finds the same optimal path as UCS, NYC-CHI-DEN-LAX at cost 8, typically after generating fewer nodes. |
| **SMA\*** | A* search that operates within a fixed memory limit. | `f(n) = g(n) + h(n)` + memory bound | Keep promising routes; forget less promising ones when memory is full. | Interactive LIVE stepper (22 steps with the default NYC-LAX and a 6-node memory bound; both Start/Goal and the memory bound are selectable). Watch the memory-used counter and the FORGET/BACKUP steps as the search discards its worst (highest-`f`) leaf and backs up that value to the leaf's parent. |
| **BiBF** | Runs best-first search from both the start and goal directions. | `Forward ↔ Backward` | Both sides choose promising cities until their searches connect. | Interactive LIVE stepper (46 steps with the default NYC-LAX; same live run as Bidirectional Search above, told concretely). Both directions are priority queues ordered by `g(n)`; at every step the search expands whichever direction currently has the cheaper frontier top. |
| **Goal Test: Standard vs. Early** | Standard tests when a node is selected; early tests when a child is generated. | Standard: `IS-GOAL(node.STATE)` · Early: `IS-GOAL(child.STATE)` | **BFS:** early is safe. **UCS/A\*:** use standard because the first generated goal may not be lowest-cost. | Fixed snapshot, no stepper: two frozen moments pulled straight from the BFS and UCS traces above, side by side — BFS's EARLY test (LAX recognized the instant it's generated) vs. UCS's STANDARD test (LAX tested only after being selected as the cheapest frontier item). |

### Evaluating Search

Introduce the criteria used to compare search algorithms: whether they find a solution, whether that solution is optimal, and how much time and memory the search requires.

|Concept	Definition	|AIMA Formula / Notation|	Teaching Tip	|Illustration Note|
|Terminology| Key quantities used to describe the size, depth, and cost of a search problem when analyzing time and space complexity.|	b = branching factor · d = depth of shallowest solution · m = maximum depth · C* = optimal solution cost · ε > 0 = minimum positive step cost	Emphasize that d and m describe depth, while C* and ε describe cost. | Use one search tree: label a node’s children as b, the shallowest goal level as d, deepest level as m, the least-cost solution path as C*, and the smallest edge cost as ε.|

| Time Complexity | How many nodes may the search generate/expand? | BFS: O(b^d) · DFS: O(b^m) · IDS: O(b^d) · UCS: O(b^(1+⌊C*/ε⌋)) · A*: exponential in the worst case, often written O(b^d) · Greedy: O(b^m) worst case | Time depends on how far the algorithm may need to search and, for informed search, the quality of the heuristic. | Use a search tree to visually derive why BFS = O(b^d), DFS = O(b^m), IDS = O(b^d), and why UCS depends on C/ε*. For Greedy and A*, show how the heuristic changes which nodes are expanded and can substantially reduce the practical search effort. |

| Space Complexity | How many nodes may the search need to keep in memory? | BFS: O(b^d) · DFS: O(bm) · IDS: O(bd) · UCS: O(b^(1+⌊C*/ε⌋)) · A*: O(b^d) worst case | BFS, UCS, and A* can require large amounts of memory because they keep many generated nodes; DFS/IDS mainly keep the current path and remaining siblings. | Use the same search tree to highlight nodes stored at once and visually derive why BFS = O(b^d), DFS = O(bm), IDS = O(bd), and why UCS and A* may need to retain a large frontier/reached set. |

| **Completeness** | Is the algorithm guaranteed to find a solution if one exists? | `solution exists ⇒ algorithm finds one` | Complete means **find a solution or correctly report failure**. | Show a search tree with an existing goal and highlight whether the strategy (select 5 of them) eventually reaches it. |
| **Optimality** | Is the algorithm guaranteed to find the lowest-cost solution? | `C(solution) = C*` | Finding a solution does not necessarily mean finding the best one. | Show two goal paths with different costs and highlight the optimal path `C*`. |


### Practice Exercises
