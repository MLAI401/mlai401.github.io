# MLAI401 — Knowledge & Reasoning (Topic 05) Specification

## 1. Goal & Architecture Overview

Create the comprehensive specification for **Topic 05: Knowledge & Reasoning**, covering how AI agents maintain an internal model of the world, derive new truths through **formal logical inference**, quantify uncertainty through **probabilistic reasoning and Bayesian networks**, and reason over dynamic belief states through **temporal reasoning and Hidden Markov Models (HMMs)**.

The topic is strictly structured into three core pillars:
```
5. Knowledge & Reasoning
   │
   ├── 1. Knowledge-Based Agents
   │   ├── Knowledge Base (Facts & Rules)
   │   ├── Propositional Logic
   │   └── Logical Inference (Forward Chaining)
   │
   ├── 2. Probabilistic Reasoning
   │   ├── Conditional Probability & Bayes' Rule
   │   └── Bayesian Networks
   │
   └── 3. Temporal Reasoning
       └── Hidden Markov Models
```

Content reference: *Artificial Intelligence: A Modern Approach* (AIMA, 4th ed.):
* **Part III — Knowledge, Reasoning, and Planning:** Chapter 7 (*Logical Agents*: §7.1 Knowledge-Based Agents, §7.3–7.5 Propositional Logic & Entailment, §7.6–7.7 Forward Chaining on Horn KBs).
* **Part IV — Uncertain Knowledge and Reasoning:**
  * Chapter 12 (*Quantifying Uncertainty*: §12.1–12.5 Probability Axioms, Joint Distributions, Bayes' Rule).
  * Chapter 13 (*Probabilistic Reasoning*: §13.1–13.4 Bayesian Networks, Conditional Independence, Exact & Sampling Inference).
  * Chapter 14 (*Probabilistic Reasoning over Time*: §14.1–14.3 Hidden Markov Models, Filtering, Prediction, Smoothing, and Viterbi Decoding).

### Target Deliverables

| File | Role |
|---|---|
| `knowledge.html` | Single-viewport interactive lecture page (concept column + visual illustration column) |
| `demos/knowledge_demo/logic_engine.js` | Pure zero-dependency Propositional & Horn Logic inference engine (`window.LogicEngine`) |
| `demos/knowledge_demo/bayes_engine.js` | Pure zero-dependency Bayesian Network exact & sampling engine (`window.BayesEngine`) |
| `demos/knowledge_demo/hmm_engine.js` | Pure zero-dependency Hidden Markov Model forward filtering and Viterbi decoding engine (`window.HMMEngine`) |
| `demos/knowledge_demo/ui.js` | Lecture page controller — topic tabs, concept chips, interactive visualizers, steppers |
| `demos/knowledge_demo/knowledge_lab.js` | Playground controller for `playground.html#view-knowledge` and `playground.html#view-hmm` |
| `python_sandbox/08_Logic_Reasoning.py` | Standalone Python implementation of Knowledge Base, Propositional Logic, and Forward Chaining (`pl_fc_entails`) |
| `python_sandbox/09_Bayesian_Reasoning.py` | Standalone Python implementation of BayesNet, Exact Enumeration, and Likelihood Weighting |
| `python_sandbox/10_Temporal_Reasoning.py` | Standalone Python implementation of Hidden Markov Models: Forward Filtering, Prediction, and Viterbi Trellis Decoding |
| `python_sandbox/knowledge.py` | Clean reference classes (`HornKB`, `BayesNet`, `BayesNode`, `HMM`) used across demos |
| `topic05_reading.html` | Comprehensive textbook-style reading notes + step-by-step practice problems with full solutions |
| `curriculum.html` | Updated Topic 05 curriculum card linking to lecture, reading notes, and playground |

---

## 2. Design & Layout Specification

Follows the unified MLAI401 design system established in Topics 01–04:

* **Viewport Strategy:** Single-viewport, concept-first layout without page scroll on standard 1080p desktop displays.
* **Top Navigation Bar:** Breadcrumb (`Curriculum > Topic 05`), topic badge (`Topic 05`), title, and action buttons (`Reading Notes`, `Interactive Demo`).
* **Topic Selector Tabs:**
  1. `0 · Progression: Search & CSP → Knowledge & Reasoning`
  2. `1 · Knowledge-Based Agents & Propositional Logic`
  3. `2 · Logical Inference: Forward Chaining`
  4. `3 · Probabilistic Reasoning & Bayes' Rule`
  5. `4 · Bayesian Networks & Independence`
  6. `5 · Temporal Reasoning & Hidden Markov Models`
  7. `6 · Evaluating Knowledge & Reasoning Systems`
  8. `7 · Code Trace`
* **Two-Column Split (50% / 50%):**
  * **Left Column (Concept):** Topic introduction, responsive concept chips, formal Definition, AIMA notation box, Teaching Tip.
  * **Right Column (Illustration / Visualizer):** Dynamic visualizer, Wumpus/Horn inference graph, BayesNet DAG, HMM temporal trellis, interactive parameter controls, step-by-step controls (`Prev`, `Next`, `Run/Pause`, `Reset`), and live execution log.
* **Visual Theme & Palette:** Accent color: **Vibrant Indigo / Violet** (`#6366f1` / `#8b5cf6`), highlighting logical certainty (emerald `#10b981`), falsehood/conflicts (rose `#f43f5e`), probabilistic density gradients (indigo-to-cyan `#06b6d4`), and temporal belief flow (amber `#f59e0b`).
* **Formula Formatting Rule:** Pure HTML/Unicode (`∧`, `∨`, `¬`, `⇒`, `⇔`, `⊨`, `⊢`, `P(A|B)`, `α`, `P(X_{t+1}|X_t)`, `P(E_t|X_t)`) — never raw unprocessed LaTeX syntax.

```
┌─────────────────────────────────────────────────────────────┐
│ NAVBAR: Breadcrumb | Topic 05 Badge | Title | Notes | Demo  │
├─────────────────────────────────────────────────────────────┤
│ TOPIC TABS: Progression | Logic | Forward Chaining | Bayes ...│
├──────────────────────────────┬──────────────────────────────┤
│ CONCEPT COLUMN (50%)         │ ILLUSTRATION COLUMN (50%)    │
│                              │                              │
│ • Concept Chip Selector      │ • Interactive Wumpus Grid /  │
│ • Clear Definition           │   BayesNet / HMM Trellis     │
│ • Formal AIMA Notation       │ • Step Controls & Execution  │
│ • Teaching Tip & Code Intuition│ • Live Value Readout & Logs │
└──────────────────────────────┴──────────────────────────────┘
```

---

## 3. Running Problem Formulations

### Running Example 1: The Wumpus World & Horn Rule-Based System (Knowledge-Based Agents)
* **Environment:** A 4×4 grid of rooms containing pits (breeze in adjacent rooms), a smelly Wumpus (stench in adjacent rooms), and safe start at `[1,1]`.
* **Knowledge Base (KB):**
  * **Base Facts:** $\text{Start}(1,1)$, $\neg\text{Breeze}(1,1)$, $\text{Visited}(1,1)$.
  * **Horn Rules:**
    * $\text{Visited}(x,y) \land \neg\text{Breeze}(x,y) \land \text{Adjacent}(x,y, a,b) \Rightarrow \text{SafePit}(a,b)$
    * $\text{Visited}(x,y) \land \neg\text{Stench}(x,y) \land \text{Adjacent}(x,y, a,b) \Rightarrow \text{SafeWumpus}(a,b)$
    * $\text{SafePit}(a,b) \land \text{SafeWumpus}(a,b) \Rightarrow \text{Safe}(a,b)$
* **Inference:** Forward chaining fires rules as new percepts arrive, deriving that `[1,2]` and `[2,1]` are 100% provably safe to explore.

### Running Example 2: Medical Test & Burglar Alarm Network (Probabilistic Reasoning)
* **Problem 2A — Medical Diagnostic Test (Bayes' Rule):**
  * Prior disease prevalence: $P(\text{Disease}) = 0.01$ (1%).
  * Test sensitivity: $P(+ \mid \text{Disease}) = 0.95$.
  * Test false positive rate: $P(+ \mid \neg\text{Disease}) = 0.05$.
  * **Query:** $P(\text{Disease} \mid +) = \frac{0.95 \times 0.01}{0.95 \times 0.01 + 0.05 \times 0.99} \approx 16.1\%$.
* **Problem 2B — Burglar Alarm Bayesian Network (AIMA Fig 13.2):**
  * 5 Boolean variables: `Burglary` ($B$), `Earthquake` ($E$), `Alarm` ($A$), `JohnCalls` ($J$), `MaryCalls` ($M$).
  * Joint factorization: $P(B, E, A, J, M) = P(B)P(E)P(A \mid B, E)P(J \mid A)P(M \mid A)$.
  * **Queries:** Diagnostic reasoning $P(B \mid J=\text{true}, M=\text{true})$ and explaining away $P(B \mid A=\text{true}, E=\text{true})$.

### Running Example 3: The Umbrella World / Weather Hidden Markov Model (Temporal Reasoning)
* **Environment (AIMA Fig 14.4):** A security guard working in an underground bunker wants to know whether it is raining outside ($R_t \in \{\text{rain}, \neg\text{rain}\}$), but can only observe whether the boss brings an umbrella into work ($U_t \in \{\text{umbrella}, \neg\text{umbrella}\}$).
* **State & Transition Model $P(R_t \mid R_{t-1})$:**
  * $P(R_t = \text{rain} \mid R_{t-1} = \text{rain}) = 0.70$, $P(R_t = \text{rain} \mid R_{t-1} = \neg\text{rain}) = 0.30$.
* **Sensor / Emission Model $P(U_t \mid R_t)$:**
  * $P(U_t = \text{umbrella} \mid R_t = \text{rain}) = 0.90$, $P(U_t = \text{umbrella} \mid R_t = \neg\text{rain}) = 0.20$.
* **Initial Prior:** $P(R_0 = \text{rain}) = 0.50$.
* **Core Tasks:**
  * **Filtering (State Estimation):** Update belief $P(R_t \mid u_{1:t})$ online as days advance.
  * **Prediction:** Compute $P(R_{t+k} \mid u_{1:t})$ for future days without observations.
  * **Smoothing:** Re-estimate past weather $P(R_k \mid u_{1:t})$ ($k < t$) in retrospect.
  * **Viterbi Decoding:** Find the single most likely weather sequence $R_{1:t}$ given umbrella observations $u_{1:t}$.

---

## 4. Topic-by-Topic Concepts & Interactive Visualizers

### 0. Evolution: Search & CSP → Knowledge & Reasoning
*The bridge connecting problem-solving searches to structured knowledge, probabilistic belief, and temporal tracking.*

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **1 · State Representation Evolution** | How the agent "sees" the world: Atomic (black-box dot) $\to$ Factored (variables & domains) $\to$ Structured (facts, rules, probabilities, temporal state transitions). | Atomic ($s \in S$) · Factored ($\{X_i = v_i\}$) · Structured ($\text{Sentences}, P(X), P(X_t \mid X_{t-1})$) | Search treats states as indivisible tokens; CSP decomposes them into constraint variables; Knowledge represents facts, degrees of belief, and temporal dynamics. | 4-panel progression: Route node $\to$ Australia CSP map $\to$ Logic KB / BayesNet $\to$ HMM time slice chain. |
| **2 · Certainty vs. Uncertainty vs. Time** | Logic operates with crisp true/false certainty; Bayes nets quantify static uncertainty; HMMs track evolving beliefs over dynamic time series. | Certainty: $KB \models \alpha$ · Uncertainty: $P(Y \mid E)$ · Temporal: $P(X_t \mid e_{1:t})$ | Use Logic when rules are absolute; use Bayes Nets when relationships are uncertain; use HMMs when the hidden state changes over time. | 3-way toggle comparison: Logic Truth Switch $\leftrightarrow$ Bayes Static Distribution $\leftrightarrow$ HMM Moving Belief Timeline. |
| **3 · The Inference Engine Paradigm** | Decoupling domain knowledge (facts, rules, CPTs, transition matrices) from the general-purpose inference algorithms. | $\text{Agent} = \text{Knowledge Model} + \text{Inference Engine}$ | You can change the problem domain completely just by swapping facts or tables, without rewriting the inference code. | Modular architecture diagram: Interchangeable Knowledge Slot plugging into Forward Chaining / BayesNet / HMM engine. |

---

### 1. Knowledge-Based Agents
*How agents represent world knowledge declaratively and perform deductive reasoning.*

#### 1.1 Knowledge Base (Facts & Rules)

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Knowledge-Based Agent Architecture** | An agent maintaining an internal Knowledge Base (KB) that interacts via two primary operations: `TELL` (add new percepts/facts) and `ASK` (query what action or state follows). | $\text{TELL}(KB, \text{sentence})$ · $\text{ASK}(KB, \text{query})$ | Unlike pure reflex agents, a knowledge-based agent combines general domain rules with specific percept history to infer hidden world properties. | Interactive KB interface: Add percept $\text{TELL}(B_{1,1})$ $\to$ KB expands $\to$ query $\text{ASK}(\text{Safe}(1,2))$ returns $\text{True}$. |
| **Facts & Rules Representation** | Facts state explicit grounded truths about the world; Rules express conditional relationships ("If premise holds, then conclusion follows"). | $\text{Fact}: \text{Breeze}(1,2)$ · $\text{Rule}: \text{Breeze}(x,y) \Rightarrow \dots$ | Declarative programming allows encoding domain knowledge independently of procedural execution order. | Split view: Fact inventory on left, rule catalog on right, highlighting active triggered links. |

#### 1.2 Propositional Logic

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Syntax & Connectives** | Formal grammar for propositional formulas using boolean symbols ($P, Q$) and connectives: Negation ($\neg$), Conjunction ($\land$), Disjunction ($\lor$), Implication ($\Rightarrow$), Biconditional ($\Leftrightarrow$). | $P \land Q$ · $P \lor Q$ · $P \Rightarrow Q \equiv \neg P \lor Q$ · $P \Leftrightarrow Q$ | Crucial intuition: $P \Rightarrow Q$ is false **only** when $P$ is True and $Q$ is False; it is vacuously true whenever $P$ is False. | Interactive Logic Gate & Truth Table builder with live signal inputs and evaluated outputs. |
| **Semantics & Models** | A model $m$ is a complete assignment of truth values ($\text{True}/\text{False}$) to all proposition symbols. $M(\alpha)$ is the set of all models where $\alpha$ evaluates to $\text{True}$. | $m = \{P: \text{True}, Q: \text{False}\}$ · $M(\alpha) = \{m : m \models \alpha\}$ | If there are $n$ symbols, there are $2^n$ possible worlds (models). Semantics defines which worlds make a sentence true. | Universe Venn diagram: $2^n$ possible model dots with the subset $M(\alpha)$ highlighted. |
| **Logical Entailment ($KB \models \alpha$)** | A sentence $\alpha$ is entailed by $KB$ if and only if $\alpha$ is true in every model where $KB$ is true ($M(KB) \subseteq M(\alpha)$). | $KB \models \alpha \iff M(KB) \subseteq M(\alpha)$ | Entailment means: whenever the KB is true, $\alpha$ is guaranteed to be true. No counterexample model exists. | Venn diagram showing $M(KB)$ strictly contained inside $M(\alpha)$; interactive counterexample finder. |

#### 1.3 Logical Inference (Forward Chaining)

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Definite & Horn Clauses** | A Definite Clause is a disjunction of literals with **exactly one** positive literal ($P_1 \land \dots \land P_k \Rightarrow Q \equiv \neg P_1 \lor \dots \lor \neg P_k \lor Q$). A Horn clause has at most one positive literal. | Premise $\Rightarrow$ Conclusion · $(P_1 \land \dots \land P_k) \Rightarrow Q$ | Horn clauses capture natural cause-and-effect and diagnostic rules while enabling ultra-fast linear-time inference. | Clause structure breakdown: Premise conditions (antecedents) pointing to single Conclusion (consequent). |
| **Forward Chaining Algorithm (`PL-FC-Entails`)** | A data-driven inference algorithm: starts with known atomic facts, decrements premise count for each rule as premises are satisfied, fires rules when count reaches 0, and adds conclusions to facts. | $\text{count}[c] = \text{number of un-inferred premises}$ · $\text{agenda} = \text{queue of new facts}$ | Forward chaining runs in **linear time $O(N)$** in the size of the KB! It is eager, robust, and ideal for monitoring systems. | Step-by-step AND-OR graph visualizer: satisfied facts light up green, rule countdown decrements, goal $Q$ triggers. |
| **Soundness & Completeness of Forward Chaining** | Forward chaining on Horn KBs is **sound** (derives only entailed sentences) and **complete** (derives every atomic sentence that is entailed). | Sound: $KB \vdash \alpha \implies KB \models \alpha$ · Complete: $KB \models \alpha \implies KB \vdash \alpha$ | Horn restrictions guarantee polynomial tractability without losing the ability to prove all entailed facts. | Verification badge table showing Soundness, Completeness, and $O(N)$ runtime guarantees on Horn KBs. |

---

### 2. Probabilistic Reasoning
*How agents quantify uncertainty, combine priors with evidence, and reason across structured networks.*

#### 2.1 Conditional Probability & Bayes' Rule

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Uncertainty & Degrees of Belief** | When worlds are partially observable, non-deterministic, or noisy, logic breaks down. Probabilities express an agent's numerical degree of belief given available evidence. | $P(A) \in [0, 1]$ · $P(\text{True}) = 1, P(\text{False}) = 0$ | Probabilities represent state of knowledge given evidence, not necessarily intrinsic physical randomness. | Continuous belief slider ($0.0 \dots 1.0$) vs binary logical switch ($0 / 1$). |
| **Full Joint Probability & Marginalization** | Complete specification of probability for every atomic event across all variables. Any marginal query is answered by summing out hidden variables. | $\mathbf{P}(Y) = \sum_{\mathbf{z}} \mathbf{P}(Y, \mathbf{z})$ · $\sum_{\mathbf{x}} P(\mathbf{x}) = 1$ | The full joint contains all answers, but requires $2^n - 1$ numbers (exponential in $n$, intractable for large domains). | Interactive Joint Distribution table (Toothache, Catch, Cavity) with row/column marginal sum highlights. |
| **Conditional Probability & Product Rule** | The probability of $A$ given that evidence $B$ is known: $P(A \mid B) = \frac{P(A \land B)}{P(B)}$. Product Rule: $P(A \land B) = P(A \mid B)P(B)$. | $P(A \mid B) = \frac{P(A \land B)}{P(B)}$ (where $P(B) > 0$) | Conditioning restricts the sample space to only worlds where $B$ holds, re-normalizing by $P(B)$. | Sample space area diagram: total space shrinks to $B$ circle; ratio of $A \cap B$ to $B$ highlighted. |
| **Bayes' Rule & Diagnostic Reasoning** | Inverts conditioning to compute posterior $P(\text{Cause} \mid \text{Effect})$ from causal likelihood $P(\text{Effect} \mid \text{Cause})$, prior $P(\text{Cause})$, and marginal evidence $P(\text{Effect})$. | $P(Y \mid X) = \frac{P(X \mid Y)P(Y)}{P(X)} = \alpha P(X \mid Y)P(Y)$ | Causal probabilities ($P(\text{Symptom} \mid \text{Disease})$) are easy to measure from studies; Bayes' rule converts them to diagnostic decisions. | Interactive Medical Test Calculator: adjust Prior $P(D)$, Sensitivity, False Positive rate $\to$ instant posterior $P(D \mid +)$. |
| **Normalization Constant ($\alpha$)** | Normalizes relative unnormalized likelihood products across all query values so the resulting distribution sums to 1. | $\mathbf{P}(Y \mid X) = \alpha \langle P(X \mid y_1)P(y_1), \dots \rangle$ where $\alpha = \frac{1}{\sum_i P(X \mid y_i)P(y_i)}$ | Using $\alpha$ avoids explicitly calculating the difficult marginal denominator $P(X)$. | Balance scale animation: raw weighted bars normalizing to $100\%$ probability distribution. |

#### 2.2 Bayesian Networks

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **Bayesian Network Syntax & DAG Representation** | A Directed Acyclic Graph (DAG) where nodes represent random variables and directed edges represent direct conditional dependencies. Each node $X_i$ has a CPT $P(X_i \mid \text{Parents}(X_i))$. | $\text{DAG } G = (V, E)$ · $\text{CPT for } X_i: P(X_i \mid \text{Parents}(X_i))$ | A Bayesian Network is a compact, factored representation of the full joint distribution! | Interactive Burglar Alarm DAG: click any node to open its Conditional Probability Table (CPT). |
| **Compact Joint Factorization** | The full joint distribution equals the product of the conditional distributions of all nodes given their parents. | $P(x_1, \dots, x_n) = \prod_{i=1}^n P(x_i \mid \text{Parents}(X_i))$ | A full joint needs $O(2^n)$ numbers; a sparse Bayesian network with maximum parent count $k$ needs only $O(n \cdot 2^k)$! | Parameter counter comparison: For $n=30, k=5$, full joint needs $10^9$ numbers vs. BN needing only $960$. |
| **Conditional Independence & Markov Blanket** | A node is conditionally independent of all other nodes given its **Markov Blanket** (its parents, its children, and its children's other parents). | $\text{MB}(X) = \text{Parents}(X) \cup \text{Children}(X) \cup \text{Coparents}(X)$ | The Markov Blanket forms a complete protective shield of evidence around a variable. | Interactive DAG selector: click any node to highlight its exact Markov Blanket in gold. |
| **Probabilistic Inference: Exact & Sampling** | Computing $\mathbf{P}(\text{Query} \mid \text{Evidence})$. Exact methods sum out hidden variables (Enumeration); approximate methods generate simulated rollouts (Likelihood Weighting). | $\text{Exact}: \mathbf{P}(X \mid \mathbf{e}) = \alpha \sum_{\mathbf{y}} P(X, \mathbf{e}, \mathbf{y})$ · $\text{Sampling}: \hat{P}(x \mid \mathbf{e}) = \frac{\sum w_i}{\sum w}$ | Exact inference is $O(2^n)$ in worst case; likelihood weighting fixes evidence and weights samples by evidence likelihood. | Side-by-side: Exact summation tree vs. animated Monte Carlo particle rollout stream. |

---

### 3. Temporal Reasoning
*How agents model dynamic worlds that change over time and maintain updated belief states from sequences of noisy observations.*

#### 3.1 Hidden Markov Models (HMMs)

| Concept | Definition | AIMA Notation | Teaching Tip | Illustration |
|---|---|---|---|---|
| **States Over Time & Markov Property** | The world state changes across discrete time slices $t=0, 1, 2, \dots$. The **First-Order Markov Property** assumes the current state depends only on the immediately preceding state. | $P(X_{t+1} \mid X_0, X_1, \dots, X_t) = P(X_{t+1} \mid X_t)$ | "The future is conditionally independent of the past, given the present." | Dynamic time-slice chain showing state nodes $X_0 \to X_1 \to X_2 \to X_t \to X_{t+1}$. |
| **Sensor / Observation Model & Stationarity** | The evidence $E_t$ at time $t$ depends only on the current state $X_t$. A process is **stationary** if transition and sensor probabilities are invariant over time. | $\text{Sensor}: P(E_t \mid X_t)$ · $\text{Transition}: P(X_{t+1} \mid X_t)$ | Even if true states $X_t$ are hidden, observable evidence $E_t$ provides noisy clues about current state. | Two-layer HMM network: Hidden state layer $X_t$ emitting observable evidence layer $E_t$. |
| **The HMM Formulation Tuple** | An HMM is completely defined by: (1) State space $S$, (2) Transition matrix $T_{i,j} = P(X_{t+1}=j \mid X_t=i)$, (3) Sensor/Emission matrix $O_{i,k} = P(E_t=k \mid X_t=i)$, and (4) Initial prior distribution $\mathbf{f}_0 = \mathbf{P}(X_0)$. | $\text{HMM} = \langle S, E, \mathbf{T}, \mathbf{O}, \mathbf{f}_0 \rangle$ | Simple matrices fully specify infinite temporal reasoning capabilities! | Interactive matrix editor: Edit $T$ and $O$ values and observe instant shifts in belief evolution. |

#### 3.2 Core HMM Inference Tasks

| Inference Task | Mathematical Definition | Algorithmic Mechanism | Real-World Application | Interactive Visualizer |
|---|---|---|---|---|
| **1 · Filtering (State Estimation)** | Compute the current belief state given all observations up to the present: $\mathbf{f}_{1:t} = \mathbf{P}(X_t \mid e_{1:t})$. | **Forward Algorithm:** Recursive Predict $\to$ Update cycle: $\mathbf{P}(X_{t+1} \mid e_{1:t+1}) = \alpha \mathbf{P}(e_{t+1} \mid X_{t+1}) \sum_{x_t} \mathbf{P}(X_{t+1} \mid x_t) P(x_t \mid e_{1:t})$. | Robot localization, GPS tracking, weather tracking. | Live Umbrella World gauge: stepping days updates Rain belief % with animated predict/update steps. |
| **2 · Prediction** | Compute posterior distribution over a future state without new observations: $\mathbf{P}(X_{t+k} \mid e_{1:t})$ for $k > 0$. | Project current belief forward using matrix powers: $\mathbf{P}(X_{t+k} \mid e_{1:t}) = \mathbf{T}^k \mathbf{P}(X_t \mid e_{1:t})$. Belief converges toward stationary distribution. | Weather forecasting, stock trajectory forecasting. | Multi-day horizon forecast chart showing belief converging to steady-state baseline. |
| **3 · Smoothing (Hindsight)** | Compute posterior distribution over a past state given all evidence up to the present: $\mathbf{P}(X_k \mid e_{1:t})$ for $0 \le k < t$. | **Forward-Backward Algorithm:** Combines forward message $\mathbf{f}_{1:k}$ from past with backward message $\mathbf{b}_{k+1:t}$ from future. | Historical data cleanup, audio speech reconstruction. | Two-way message collision visualizer: forward blue wave meets backward purple wave at day $k$. |
| **4 · Most Likely Sequence (Viterbi)** | Find the single overall state sequence $x_{1:t}^*$ that maximizes joint probability $P(x_{1:t} \mid e_{1:t})$. | **Viterbi Algorithm:** Dynamic programming over trellis: $m_t[j] = \max_i (m_{t-1}[i] \cdot T_{i,j}) \cdot P(e_t \mid j)$ with backpointers. | Speech-to-text recognition, DNA gene sequence alignment. | Interactive Viterbi Trellis matrix: highlights maximum path in gold with backtrack arrows. |

---

### 4. Evaluating Knowledge & Reasoning Systems

Comprehensive comparison of the three primary reasoning paradigms:

| Dimension | 1. Knowledge-Based Agents (Horn Logic) | 2. Probabilistic Reasoning (Bayesian Networks) | 3. Temporal Reasoning (Hidden Markov Models) |
|---|---|---|---|
| **Representation** | Propositional Horn clauses & definite rules | Directed Acyclic Graph (DAG) with CPTs | Two-layer temporal chain (Hidden states + Observations) |
| **World Model** | Static, fully or partially observable | Static, uncertain / noisy | Dynamic (changes across time slices $t=0, 1, 2, \dots$) |
| **Certainty Model** | Strict Boolean truth values ($0$ or $1$) | Continuous probability distributions $[0, 1]$ | Continuous dynamic belief state $\mathbf{P}(X_t \mid e_{1:t})$ |
| **Core Inference Engine** | Forward Chaining (`PL-FC-Entails`) | Exact Enumeration / Likelihood Weighting | Forward Algorithm (Filtering) & Viterbi Algorithm |
| **Computational Complexity** | **$O(N)$ Linear in KB size** | Exact: $O(2^n)$ worst-case; Sampling: $O(N_{\text{samples}} \cdot n)$ | Filtering: $O(|S|^2)$ per time step; Viterbi: $O(t \cdot |S|^2)$ |
| **Soundness & Completeness** | Sound & Complete for Horn KBs | Exact for polytrees; asymptotically consistent for sampling | Exact recursive state estimation |
| **Handling Noisy Observations** | Poor (single false fact can break deductions) | Excellent (quantified via conditional probabilities) | Excellent (sensor model filters out transient noise) |
| **Best Application Domain** | Automated rule verification, medical protocols | Medical diagnosis, fault detection, risk analysis | Tracking, robot localization, speech recognition, NLP |

---

### 5. Code Trace Specification (`knowledge.html#code`)

Interactive line-by-line stepping through clean, runnable Python code with real-time state visualization:

```
┌──────────────────────────────────────┬──────────────────────────────────────┐
│ PYTHON SOURCE TRACE (Left 50%)       │ RUNTIME STATE & VISUALIZER (Right 50%)│
│                                      │                                      │
│ • Line numbers with execution arrow  │ • Active agenda / factors / trellis  │
│ • Highlighted active expressions     │ • State inspect tables & belief bars │
│ • Step commentary & variable watch   │ • Step k of N | Prev | Next | Run/Pause│
└──────────────────────────────────────┴──────────────────────────────────────┘
```

#### Presets Traced

1. **`trace_pl_fc_entails` (`python_sandbox/08_Logic_Reasoning.py`):**
   * **Problem:** Horn clause knowledge base with facts $A, B$ and rules $A \land B \Rightarrow C$, $C \land D \Rightarrow E$, $B \Rightarrow D$; Query goal $E$.
   * **State Display:** Live $\text{count}$ table per rule, $\text{inferred}$ boolean map, FIFO $\text{agenda}$ queue, active rule premise decrement, and derivation of goal $E$.
2. **`trace_bayes_rule` (`python_sandbox/09_Bayesian_Reasoning.py`):**
   * **Problem:** Rare medical test: Prior $P(D)=0.01$, Sensitivity $P(+|D)=0.95$, False Alarm $P(+|\neg D)=0.05$.
   * **State Display:** Joint likelihoods $P(+ \cap D)$ vs $P(+ \cap \neg D)$, normalization factor $\alpha = \frac{1}{P(+)}$, and final posterior $P(D|+)=16.1\%$.
3. **`trace_bayes_enumeration` (`python_sandbox/09_Bayesian_Reasoning.py`):**
   * **Problem:** Burglar Alarm query $\mathbf{P}(B \mid j=\text{true}, m=\text{true})$.
   * **State Display:** Recursive evaluation tree over hidden variables $E$ and $A$, product computation $P(B)P(E)P(A|B,E)P(j|A)P(m|A)$, and normalization $\alpha$.
4. **`trace_hmm_forward_filtering` (`python_sandbox/10_Temporal_Reasoning.py`):**
   * **Problem:** Umbrella World 2-day filtering with evidence $U_1=\text{true}, U_2=\text{true}$.
   * **State Display:** Day 0 prior $\mathbf{f}_0=\langle 0.5, 0.5 \rangle$; Day 1 prediction $\mathbf{T}^T \mathbf{f}_0 \to$ sensor update $\to \mathbf{f}_1=\langle 0.818, 0.182 \rangle$; Day 2 prediction $\to$ update $\to \mathbf{f}_2=\langle 0.883, 0.117 \rangle$.
5. **`trace_hmm_viterbi` (`python_sandbox/10_Temporal_Reasoning.py`):**
   * **Problem:** 3-day Umbrella sequence $[U_1=\text{true}, U_2=\text{true}, U_3=\text{false}]$.
   * **State Display:** Trellis matrix $m_t[s]$, backpointer table, max transition selection, and backwards traceback yielding optimal sequence $[\text{Rain}, \text{Rain}, \text{NoRain}]$.

---

## 5. Python Sandbox Scripts

### File 1: `python_sandbox/08_Logic_Reasoning.py`
Standalone, zero-dependency Python script runnable directly with `python 08_Logic_Reasoning.py`:
* `HornKB` class storing atomic facts and Horn rules ($P_1 \land \dots \land P_k \Rightarrow Q$).
* `pl_fc_entails(kb, query)` — Linear-time Forward Chaining algorithm with agenda and premise count tracking.
* **Built-in Test Cases:**
  * Wumpus World safe room deduction from breeze/stench percepts.
  * Medical diagnostic rule-chain verification.
  * Cycle detection and unsatisfiable query handling.

### File 2: `python_sandbox/09_Bayesian_Reasoning.py`
Standalone, zero-dependency Python script runnable directly with `python 09_Bayesian_Reasoning.py`:
* `BayesNode` and `BayesNet` classes representing DAG structure and Conditional Probability Tables.
* `bayes_rule(prior, sensitivity, false_positive)` — Exact Bayes' Rule posterior calculator with normalization.
* `enumeration_ask(query, evidence, bn)` — Exact inference by recursive joint distribution enumeration.
* `likelihood_weighting(query, evidence, bn, N)` — Approximate inference via weighted Monte Carlo sampling.
* **Built-in Test Cases:**
  * Complete AIMA Burglar Alarm network benchmarks.
  * Rare disease screening sensitivity vs. specificity test.
  * Explaining away diagnostic reasoning test.

### File 3: `python_sandbox/10_Temporal_Reasoning.py`
Standalone, zero-dependency Python script runnable directly with `python 10_Temporal_Reasoning.py`:
* `HiddenMarkovModel` class initialized with state list, transition matrix $\mathbf{T}$, emission matrix $\mathbf{O}$, and initial prior $\mathbf{f}_0$.
* `forward_filter(evidence_sequence)` — Online state estimation computing $\mathbf{P}(X_t \mid e_{1:t})$ for each step.
* `predict(k_steps, current_belief)` — Future state forecasting.
* `viterbi(evidence_sequence)` — Dynamic programming trellis decoding for the most likely state sequence.
* **Built-in Test Cases:**
  * Classic AIMA Umbrella World sequence ($U = [\text{true}, \text{true}, \text{false}, \text{true}, \text{true}]$).
  * 1D Robot Hallway Localization with noisy wall sensors.

---

## 6. Reading Notes & Practice Exercises (`topic05_reading.html`)

Textbook-style reading notes structured into three comprehensive modules, followed by fully worked-out analytical practice problems:

### Module Structure
1. **Module 1: Knowledge-Based Agents & Logical Inference**
   * Declarative knowledge representation, Knowledge Bases, and `TELL`/`ASK` cycles.
   * Propositional logic syntax, models, truth tables, and entailment ($KB \models \alpha$).
   * Horn clauses and the linear-time Forward Chaining algorithm (`PL-FC-Entails`).
2. **Module 2: Probabilistic Reasoning & Bayesian Networks**
   * Quantifying uncertainty, probability axioms, joint distributions, and conditional probability.
   * Bayes' rule, diagnostic reasoning, prior odds, and normalization constant $\alpha$.
   * Bayesian Networks: DAG topology, compact joint factorization, and conditional independence.
3. **Module 3: Temporal Reasoning & Hidden Markov Models**
   * Dynamic environments, state transitions across time, and the First-Order Markov Property.
   * Sensor models, stationarity, and the complete HMM tuple.
   * The Four Core Inference Tasks: Filtering (Forward algorithm), Prediction, Smoothing, and Most Likely Sequence (Viterbi algorithm).

### Practice Problems Included

1. **Horn Clause Forward Chaining Trace:**
   * Given facts $\{A, B\}$ and rules $A \land B \Rightarrow C$, $C \land D \Rightarrow E$, $B \Rightarrow D$, $E \Rightarrow F$: trace initial $\text{count}$ table, agenda queue progression, and determine if $F$ is entailed.
2. **Medical Screening with Bayes' Rule:**
   * Disease prevalence $P(D) = 0.002$. Test sensitivity $P(+ \mid D) = 0.98$. False positive rate $P(+ \mid \neg D) = 0.03$. Calculate exact posterior probability $P(D \mid +)$ showing normalization factor $\alpha$.
3. **Bayesian Network Joint Probability & Factorization:**
   * Given the Burglar Alarm network, write the algebraic factorization for $P(B=\text{true}, E=\text{false}, A=\text{true}, J=\text{true}, M=\text{false})$ and compute its numerical value using standard AIMA CPT parameters.
4. **HMM Forward Filtering Step-by-Step:**
   * Using the Umbrella World model ($P(R_0)=0.5$, $T = [[0.7, 0.3], [0.3, 0.7]]$, $O = [0.9, 0.2]$), compute the exact filtered belief state $\mathbf{P}(R_1 \mid U_1=\text{umbrella})$ and $\mathbf{P}(R_2 \mid U_1=\text{umbrella}, U_2=\text{umbrella})$.
5. **HMM Viterbi Trellis Calculation:**
   * Given umbrella observations $[U_1=\text{true}, U_2=\text{false}]$, manually compute the Viterbi trellis probabilities $m_1[\text{Rain}], m_1[\neg\text{Rain}]$ and $m_2[\text{Rain}], m_2[\neg\text{Rain}]$, and reconstruct the optimal state sequence via backpointers.

---

## 7. Interactive Playground Specifications (`playground.html#view-knowledge`)

Interactive lab sub-views:

1. **Knowledge Base & Forward Chaining Studio:**
   * Rule and Fact editor with interactive clause graph visualization.
   * Step-by-step forward chaining execution with live premise counter decrements and agenda queue animation.
2. **Bayesian Network Interactive Workbench:**
   * Preloaded networks: *Burglar Alarm*, *Medical Diagnostic Test*, *Sprinkler / Wet Grass*.
   * Click nodes to toggle observed evidence ($\text{True} / \text{False}$); watch real-time posterior probability meters update across all nodes via exact enumeration.
3. **Hidden Markov Model Temporal Studio:**
   * Preloaded models: *Umbrella World* and *Robot Hallway Tracking*.
   * Step through time slices, toggle observation sequences, and view real-time side-by-side Forward Filtering gauge and Viterbi Trellis decoding matrix.

---

## 8. Academic & Textbook References

### Primary Textbooks & Standard Curricula
* **AIMA (4th Edition):**
  * Chapter 7: *Logical Agents* (§7.1 Knowledge-Based Agents, §7.3–7.5 Propositional Logic & Entailment, §7.6–7.7 Forward Chaining on Horn KBs).
  * Chapter 12: *Quantifying Uncertainty* (§12.1–12.5 Probability Axioms, Joint Distributions, Bayes' Rule).
  * Chapter 13: *Probabilistic Reasoning* (§13.1–13.4 Bayesian Networks, Conditional Independence, Exact & Sampling Inference).
  * Chapter 14: *Probabilistic Reasoning over Time* (§14.1–14.3 Hidden Markov Models, Forward Filtering, Prediction, Smoothing, and Viterbi Algorithm).
* **AIMA Python Reference Code:**
  * Logic algorithms: [`reference/aima-python/aima/logic.py`](file:///Volumes/Data/MLAI_Projects/MLAI401/reference/aima-python/aima/logic.py) (`KB`, `pl_fc_entails`).
  * Probability & BayesNet: [`reference/aima-python/aima/probability.py`](file:///Volumes/Data/MLAI_Projects/MLAI401/reference/aima-python/aima/probability.py) (`BayesNet`, `BayesNode`, `enumeration_ask`, `likelihood_weighting`).
  * Temporal HMM algorithms: [`reference/aima-python/aima/probability.py`](file:///Volumes/Data/MLAI_Projects/MLAI401/reference/aima-python/aima/probability.py) (`forward_backward`, `HMM`).

### Foundational Papers & Historical Milestones
* **Knowledge & Logic:**
  * Davis, M., & Putnam, H. (1960). *A Computing Procedure for Quantification Theory*. Journal of the ACM, 7(3), 201–215.
  * Dowling, W. F., & Gallier, J. H. (1984). *Linear-time algorithms for testing the satisfiability of propositional Horn formulae*. Journal of Logic Programming, 1(3), 267–284. (Linear Forward Chaining).
* **Probabilistic Reasoning & Bayesian Networks:**
  * Bayes, T. (1763). *An Essay towards solving a Problem in the Doctrine of Chances*. Philosophical Transactions of the Royal Society of London.
  * Pearl, J. (1988). *Probabilistic Reasoning in Intelligent Systems: Networks of Plausible Inference*. Morgan Kaufmann. (Turing Award-winning formulation of Bayesian Networks).
* **Temporal Reasoning & Hidden Markov Models:**
  * Baum, L. E., & Petrie, T. (1966). *Statistical Inference for Probabilistic Functions of Finite State Markov Chains*. The Annals of Mathematical Statistics, 37(6), 1554–1563.
  * Viterbi, A. (1967). *Error bounds for convolutional codes and an asymptotically optimum decoding algorithm*. IEEE Transactions on Information Theory, 13(2), 260–269.
  * Rabiner, L. R. (1989). *A Tutorial on Hidden Markov Models and Selected Applications in Speech Recognition*. Proceedings of the IEEE, 77(2), 257–286.
