# BMAD vs. AGENTS.md + skills.md + instructions.md

| Aspect | BMAD Method | AGENTS.md + skills.md + instructions.md |
| :--- | :--- | :--- |
| **Main purpose** | Structured AI-driven software development workflow | Lightweight project guidance for AI coding agents |
| **Best for** | Larger or more complex projects | Small to medium projects |
| **Setup effort** | Higher | Low |
| **Structure** | Uses defined roles, planning stages, stories, architecture, and implementation flow | You define your own rules and task sequence |
| **Roles** | Often includes PM, Architect, Scrum Master, Developer, Reviewer, etc. | Usually no formal roles unless you define them |
| **Requirements** | More formal and detailed | Can be concise |
| **Architecture planning** | Usually explicit | Optional |
| **Task breakdown** | Often converted into stories/tasks before coding | Usually written directly in `instructions.md` |
| **Coding workflow** | AI agents work through predefined development stages | AI agents follow the project instructions directly |
| **Flexibility** | More structured, but can feel rigid | Very flexible |
| **Learning curve** | Higher | Very low |
| **Documentation overhead** | More files and artifacts | Usually just a few files |
| **Good for teaching projects** | Sometimes overkill | Very suitable |
| **Good for production projects** | Strong when requirements are complex | Good when the team already understands the architecture |
| **Good for one developer + AI** | Useful for larger projects | Usually simpler and faster |
| **Typical flow** | Idea → PRD → Architecture → Stories → Development → Review | Requirements → Tasks → Development |
| **AI agent integration** | External methodology layered on top of the coding agent | Simple, repository-based guidance for coding agents |
| **Maintenance** | More process to maintain | Easy to update |

- **`AGENTS.md`** → Defines **how the AI agent should work** in the repository.
- **`instructions.md`** → Defines **what should be built or completed**.

--- 

## Example for Small–Medium Project

| File / Folder | Purpose |
| :--- | :--- |
| `AGENTS.md` | Permanent rules AI agents should follow for the whole repository |
| `instructions.md` | Current development tasks and implementation order |
| `skills/` | Reusable instructions for specialized tasks |
| `README.md` | Project description and usage instructions |
| `documents/` | Requirements, problem background, and reference materials |
| `tests/` | Expected behavior and validation |
| `src/` | Main implementation |

---

```
project/
├── AGENTS.md
├── instructions.md
├── README.md
├── documents/
├── skills/
│   └── SKILL.md
├── src/
└── tests/
```
