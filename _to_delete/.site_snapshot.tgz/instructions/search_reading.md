
Reading Page : Topic 02 Reading

- Create a textbook-style reading page that mirrors the same conceptual order as the interactive lecture in search_planning.html.
- Follow the presentation and reading style of the CS 188 Search textbook page: https://inst.eecs.berkeley.edu/~cs188/textbook/search/
- Use the content and concepts from search_planning.html as the primary source.
- Refer to Artificial Intelligence: A Modern Approach by Stuart Russell and Peter Norvig for terminology, notation, formulas, and supporting material when additional reference is needed.
- Keep terminology and notation consistent between the reading page and search_planning.html.
- Add a small citation note: “Materials and content adapted from Artificial Intelligence: A Modern Approach.”
- Add a Reading Notes button to the Topic 02 · Search & Planning page that links to the new reading page.

- Add a single **Practice Exercises** section at the end of the reading page. Use the problems under the Search topics in `exercises.md` and combine the relevant exercises into this section. For each practice exercise, keep the answer hidden by default and provide a “Show Answer” button. When revealed, show the answer with a concise explanation of the reasoning or key steps. Preserve multi-part exercises as a single numbered question with subparts (a), (b), (c), etc., rather than displaying each subpart as a separate exercise. Provide one “Show Answer” control for the complete exercise, with answers organized by the same subpart labels.