"""
knowledge.py — Reference base classes for Knowledge Representation & Reasoning.
Covers Propositional Logic, Horn Clauses, and Bayesian Networks.
Follows AIMA (Artificial Intelligence: A Modern Approach, 4th Ed.) Parts III & IV.
"""

from collections import defaultdict, deque
import random


# =============================================================================
# Logical Expressions & Knowledge Bases
# =============================================================================

class Expr:
    """
    A mathematical logical expression with an operator and arguments.
    Supports boolean operations: & (AND), | (OR), ~ (NOT), >> (IMPLIES), <=> (BICONDITIONAL).
    """
    def __init__(self, op, *args):
        self.op = str(op)
        self.args = list(args)

    def __repr__(self):
        if not self.args:
            return self.op
        elif len(self.args) == 1:
            return f"{self.op}{self.args[0]}"
        elif len(self.args) == 2 and not self.op.isalnum():
            return f"({self.args[0]} {self.op} {self.args[1]})"
        else:
            return f"{self.op}({', '.join(map(str, self.args))})"

    def __eq__(self, other):
        return isinstance(other, Expr) and self.op == other.op and self.args == other.args

    def __hash__(self):
        return hash((self.op, tuple(self.args)))

    def __invert__(self):
        return Expr('~', self)

    def __and__(self, other):
        return Expr('&', self, other)

    def __or__(self, other):
        return Expr('|', self, other)

    def __rshift__(self, other):
        return Expr('>>', self, other)


def expr(s):
    """
    Parse a string into an Expr object.
    Supports symbols, ~, &, |, >>, <=>.
    Example: expr('P & Q >> R'), expr('B11 <=> (P12 | P21)')
    """
    if isinstance(s, Expr):
        return s
    s = s.strip()
    if not s:
        return None

    # Check biconditional
    parts = _split_top_level(s, '<=>')
    if len(parts) == 2:
        return Expr('<=>', expr(parts[0]), expr(parts[1]))
    
    # Check implication
    parts = _split_top_level(s, '>>')
    if len(parts) == 2:
        return Expr('>>', expr(parts[0]), expr(parts[1]))
    parts = _split_top_level(s, '==>')
    if len(parts) == 2:
        return Expr('>>', expr(parts[0]), expr(parts[1]))
        
    # Check OR
    parts = _split_top_level(s, '|')
    if len(parts) > 1:
        res = expr(parts[0])
        for p in parts[1:]:
            res = Expr('|', res, expr(p))
        return res
        
    # Check AND
    parts = _split_top_level(s, '&')
    if len(parts) > 1:
        res = expr(parts[0])
        for p in parts[1:]:
            res = Expr('&', res, expr(p))
        return res

    # Check NOT
    if s.startswith('~') or s.startswith('¬'):
        return Expr('~', expr(s[1:]))

    # Strip outer parentheses
    if s.startswith('(') and s.endswith(')'):
        if _is_enclosed(s):
            return expr(s[1:-1])

    # Atomic symbol
    return Expr(s)


def _is_enclosed(s):
    if not (s.startswith('(') and s.endswith(')')):
        return False
    depth = 0
    for i, c in enumerate(s):
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0 and i < len(s) - 1:
                return False
    return depth == 0


def _split_top_level(s, op):
    depth = 0
    op_len = len(op)
    i = 0
    while i <= len(s) - op_len:
        c = s[i]
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
        elif depth == 0 and s[i:i+op_len] == op:
            return [s[:i], s[i+op_len:]]
        i += 1
    return [s]


def prop_symbols(x):
    """Return the set of all propositional symbols in an Expr."""
    if not isinstance(x, Expr):
        return set()
    if not x.args:
        return {x} if x.op not in ('True', 'False') else set()
    s = set()
    for arg in x.args:
        s.update(prop_symbols(arg))
    return s


def pl_true(exp, model={}):
    """
    Return True if the propositional expression is true in the model.
    model is a dict mapping symbol Expr/str -> True/False.
    """
    if exp in (True, 'True'):
        return True
    if exp in (False, 'False'):
        return False
    if not isinstance(exp, Expr):
        return exp

    op, args = exp.op, exp.args
    if not args:
        return model.get(exp, model.get(exp.op, False))
    elif op == '~' or op == '¬':
        return not pl_true(args[0], model)
    elif op == '&' or op == '∧':
        return pl_true(args[0], model) and pl_true(args[1], model)
    elif op == '|' or op == '∨':
        return pl_true(args[0], model) or pl_true(args[1], model)
    elif op == '>>' or op == '⇒' or op == '==>':
        return (not pl_true(args[0], model)) or pl_true(args[1], model)
    elif op == '<=>' or op == '⇔':
        return pl_true(args[0], model) == pl_true(args[1], model)
    else:
        raise ValueError(f"Unknown operator: {op}")


class KB:
    """Abstract Knowledge Base interface (AIMA Chapter 7)."""
    def __init__(self, sentence=None):
        self.clauses = []
        if sentence:
            self.tell(sentence)

    def tell(self, sentence):
        raise NotImplementedError

    def ask(self, query):
        raise NotImplementedError

    def retract(self, sentence):
        raise NotImplementedError


class PropositionalKB(KB):
    """Knowledge base for propositional logic sentences."""
    def __init__(self, sentence=None):
        super().__init__(sentence)

    def tell(self, sentence):
        if isinstance(sentence, (list, tuple)):
            for s in sentence:
                self.tell(s)
            return
        e = expr(sentence)
        self.clauses.append(e)

    def ask(self, query):
        return tt_entails(self, expr(query))

    def sentences(self):
        return list(self.clauses)


def tt_entails(kb, alpha):
    """
    Truth-Table Entailment algorithm (AIMA Figure 7.10).
    Checks if KB |= alpha by enumerating all models over proposition symbols.
    """
    if isinstance(kb, KB):
        kb_expr = kb.clauses[0] if kb.clauses else Expr('True')
        for c in kb.clauses[1:]:
            kb_expr = Expr('&', kb_expr, c)
    else:
        kb_expr = expr(kb)

    alpha_expr = expr(alpha)
    symbols = list(prop_symbols(kb_expr) | prop_symbols(alpha_expr))
    return tt_check_all(kb_expr, alpha_expr, symbols, {})


def tt_check_all(kb, alpha, symbols, model):
    if not symbols:
        if pl_true(kb, model):
            return pl_true(alpha, model)
        else:
            return True
    P = symbols[0]
    rest = symbols[1:]
    return (tt_check_all(kb, alpha, rest, {**model, P: True}) and
            tt_check_all(kb, alpha, rest, {**model, P: False}))


# =============================================================================
# Bayesian Network Reference Classes
# =============================================================================

class BayesNode:
    """
    A single node in a Bayesian Network (AIMA Chapter 13/14).
    Represents a random variable with parents in the DAG and a CPT.
    """
    def __init__(self, var, parents, cpt):
        self.var = var
        self.parents = [parents] if isinstance(parents, str) else list(parents)
        if isinstance(cpt, (int, float)):
            self.cpt = {(): float(cpt)}
        elif isinstance(cpt, dict):
            norm_cpt = {}
            for k, v in cpt.items():
                if isinstance(k, (bool, int, str)):
                    norm_cpt[(k,)] = float(v)
                elif isinstance(k, tuple):
                    norm_cpt[k] = float(v)
                else:
                    norm_cpt[(k,)] = float(v)
            self.cpt = norm_cpt
        else:
            self.cpt = cpt

    def p(self, value, event):
        parent_vals = tuple(event[p] for p in self.parents)
        p_true = self.cpt.get(parent_vals, self.cpt.get(parent_vals[0] if len(parent_vals) == 1 else parent_vals, 0.5))
        return p_true if value else (1.0 - p_true)

    def sample(self, event):
        parent_vals = tuple(event[p] for p in self.parents)
        p_true = self.cpt.get(parent_vals, self.cpt.get(parent_vals[0] if len(parent_vals) == 1 else parent_vals, 0.5))
        return random.random() < p_true

    def __repr__(self):
        return f"BayesNode({self.var}, parents={self.parents})"


class BayesNet:
    """
    Bayesian Network Directed Acyclic Graph (DAG) with Conditional Probability Tables.
    """
    def __init__(self, node_specs=None):
        self.nodes = []
        self.variables = []
        self.node_map = {}
        if node_specs:
            for spec in node_specs:
                self.add(spec)

    def add(self, node_spec):
        if isinstance(node_spec, BayesNode):
            node = node_spec
        else:
            var, parents, cpt = node_spec
            node = BayesNode(var, parents, cpt)
        self.nodes.append(node)
        self.variables.append(node.var)
        self.node_map[node.var] = node

    def getNode(self, var):
        return self.node_map.get(var)

    def topological_sort(self):
        return list(self.variables)

    def __repr__(self):
        return f"BayesNet(variables={self.variables})"


# =============================================================================
# Temporal Reasoning & Hidden Markov Models (AIMA Chapter 14)
# =============================================================================

class HiddenMarkovModel:
    """
    Hidden Markov Model with discrete states, transition matrix, emission matrix, and prior.
    Supports online Forward Filtering and Viterbi Trellis decoding.
    """
    def __init__(self, states, observations, transition_matrix, emission_matrix, prior=None):
        self.states = list(states)
        self.observations = list(observations)
        self.T = transition_matrix  # T[i][j] = P(X_{t+1}=j | X_t=i)
        self.O = emission_matrix    # O[i][k] = P(E_t=k | X_t=i)
        self.prior = prior if prior is not None else [1.0 / len(states)] * len(states)

    def forward_step(self, prev_belief, obs):
        """Single Predict -> Update forward filtering step."""
        obs_idx = self.observations.index(obs) if isinstance(obs, str) else obs
        num_states = len(self.states)

        # Predict: P(X_t | e_{1:t-1}) = sum_i P(X_t | X_{t-1}=i) * P(X_{t-1}=i | e_{1:t-1})
        predicted = [
            sum(prev_belief[i] * self.T[i][j] for i in range(num_states))
            for j in range(num_states)
        ]

        # Update: P(X_t | e_{1:t}) = alpha * P(e_t | X_t) * P(X_t | e_{1:t-1})
        unnorm = [predicted[j] * self.O[j][obs_idx] for j in range(num_states)]
        s = sum(unnorm)
        alpha = 1.0 / s if s > 0 else 1.0
        updated = [v * alpha for v in unnorm]

        return predicted, updated

    def forward_filter(self, obs_sequence):
        """Filters an entire observation sequence online."""
        history = [list(self.prior)]
        f = list(self.prior)
        for obs in obs_sequence:
            _, f = self.forward_step(f, obs)
            history.append(f)
        return history

    def viterbi(self, obs_sequence):
        """Computes the most likely sequence of hidden states via Viterbi trellis."""
        T = len(obs_sequence)
        if T == 0:
            return [], 0.0
        
        num_states = len(self.states)
        obs_0 = self.observations.index(obs_sequence[0]) if isinstance(obs_sequence[0], str) else obs_sequence[0]
        
        # t = 0
        m = [[self.prior[s] * self.O[s][obs_0] for s in range(num_states)]]
        backpointers = []

        # t = 1 .. T-1
        for t in range(1, T):
            obs_t = self.observations.index(obs_sequence[t]) if isinstance(obs_sequence[t], str) else obs_sequence[t]
            m_t = [0.0] * num_states
            bp_t = [0] * num_states

            for j in range(num_states):
                max_val = -1.0
                best_prev = 0
                for i in range(num_states):
                    val = m[t - 1][i] * self.T[i][j]
                    if val > max_val:
                        max_val = val
                        best_prev = i
                m_t[j] = max_val * self.O[j][obs_t]
                bp_t[j] = best_prev

            m.append(m_t)
            backpointers.append(bp_t)

        # Termination & Backtrack
        best_last_state = max(range(num_states), key=lambda s: m[T - 1][s])
        max_prob = m[T - 1][best_last_state]

        path = [best_last_state]
        for t in range(T - 2, -1, -1):
            path.append(backpointers[t][path[-1]])
        path.reverse()

        return [self.states[idx] for idx in path], max_prob

