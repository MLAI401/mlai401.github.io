# python_sandbox

Standalone Python implementations of the classic uninformed and informed
search algorithms taught in `instructions/search.md`, structured after the
`Problem` / `Node` abstraction used in
[aima-python](https://github.com/aimacode/aima-python) (the official code
companion to *Artificial Intelligence: A Modern Approach*). These are
from-scratch reimplementations, not copies of that repo's `search.py` — kept
intentionally small so each numbered script stays easy to read top to
bottom.

All six scripts search the **same graph** used by the site's interactive
"Graph Search Algorithms" demo (`demos/search_demo/graph.js`), from `A` to
`G`, so the printed results here match what you see in the Playground:

```
A → B (3)   A → C (2)   A → E (9)
B → D (2)   B → E (4)
C → E (6)   C → F (9)
D → G (3)
E → G (1)   E → H (2)
F → H (1)
G → H (5)
```

## Files

| File | Algorithm | Frontier |
|---|---|---|
| `graph_problem.py` | shared `Node` / `GraphProblem` + the graph & heuristic table | — (imported by every script below) |
| `01_BFS.py` | Breadth-First Search | FIFO queue |
| `02_DFS.py` | Depth-First Search | LIFO stack |
| `03_UCS.py` | Uniform-Cost Search | priority queue by `g(n)` |
| `04_IDS.py` | Iterative Deepening Search | repeated depth-limited DFS |
| `05_Greedy.py` | Greedy Best-First Search | priority queue by `h(n)` |
| `06_AStar.py` | A* Search | priority queue by `f(n) = g(n) + h(n)` |
| `07_CSP_Heuristics.py` | CSP: backtracking, MRV + Degree, LCV, forward checking, AC-3 / MAC, min-conflicts, efficiency comparison (Australia, n-queens) | — (see `instructions/csp.md` §6, traced on `csp.html#code`) |
| `08_Logic_Reasoning.py` | Propositional & Horn Logic: TT-Entails, CNF conversion, PL-Resolution, PL-FC-Entails (Wumpus, Liars & Truth-Tellers, Medical Horn KB) | — (see `instructions/topic05.md`, traced on `knowledge.html#code`) |
| `09_Bayesian_Reasoning.py` | Bayesian Networks: Exact Enumeration, Variable Elimination, Prior Sampling, Rejection Sampling, Likelihood Weighting (Alarm, Wet Grass, Medical) | — (see `instructions/topic05.md`, traced on `knowledge.html#code`) |
| `knowledge.py` | Reference data structures: `Expr`, `KB`, `PropositionalKB`, `BayesNet`, `BayesNode` | — (shared module) |

## Run

Each script is standalone:

```bash
python 01_BFS.py
python 02_DFS.py
python 03_UCS.py
python 04_IDS.py
python 05_Greedy.py
python 06_AStar.py
python 07_CSP_Heuristics.py
python 08_Logic_Reasoning.py
python 09_Bayesian_Reasoning.py
```

Every run prints the step-by-step frontier/expansion trace (Select → Goal
Test → Expand → Update, in the same AIMA terminology used across
`instructions/`), followed by a summary: Expanded Node Order, Solution Path,
Path Cost, and Nodes Expanded.

## Verified results (A → G)

| Algorithm | Expanded Node Order | Solution Path | Path Cost |
|---|---|---|---|
| BFS | A, B, C, E | A → E → G | 10 |
| DFS | A, B, D | A → B → D → G | 8 |
| UCS | A, C, B, D, E | A → B → D → G | 8 |
| IDS | A, A, B, C, E | A → E → G | 10 |
| Greedy | A, E | A → E → G | 10 |
| A* | A, B, C, D, E | A → B → D → G | 8 |

BFS and UCS match the worked examples in `instructions/search.md` exactly.
Note that BFS/IDS/Greedy land on the *fewest-edges* path (`A → E → G`),
while UCS/A* — the cost-aware algorithms — correctly find the *cheapest*
path (`A → B → D → G`, cost 8) even though it takes one more edge. That gap
is the core teaching point of this demo: different frontier strategies
optimize for different things.
