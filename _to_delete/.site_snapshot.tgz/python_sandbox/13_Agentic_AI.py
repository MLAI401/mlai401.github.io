#!/usr/bin/env python3
"""
MLAI401 — Topic 07: Agentic AI & Autonomous Architectures
Standalone, zero-dependency Python implementation:
- Concrete Tool implementations: Calculator, Search, Python REPL, File Writer
- Structured Scratchpad Working Memory (Thoughts, Actions, Observations)
- Autonomous ReAct Loop with Error Reflection & Self-Correction
- Task Decomposition Planning
- Multi-Agent Collaboration: Manager-Worker & Generator-Critic loops

Can be run directly:
    python 13_Agentic_AI.py
"""

import math
import json
import re
from agentic import (
    Tool,
    ToolRegistry,
    Scratchpad,
    ReActAgent,
    MultiAgentSystem
)


# ==============================================================================
# 1. Concrete Agent Tools
# ==============================================================================

class CalculatorTool(Tool):
    """Safely evaluates mathematical expressions using standard math operations."""
    def __init__(self):
        schema = {
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "Mathematical expression, e.g., 'sqrt(1764) * 3' or '(150 + 155 + 152) / 3'"
                }
            },
            "required": ["expression"]
        }
        super().__init__("calculator", "Evaluates arithmetic and mathematical expressions.", schema)

    def execute(self, expression=""):
        cleaned = expression.strip()
        # Allowed safe math functions and operators
        safe_dict = {
            "sqrt": math.sqrt,
            "pow": math.pow,
            "abs": abs,
            "round": round,
            "pi": math.pi,
            "e": math.e,
            "sin": math.sin,
            "cos": math.cos
        }
        # Security sanitization
        if re.search(r'[^0-9+\-*/()., \ta-zA-Z_]', cleaned):
            return "Error: Expression contains forbidden characters."
        try:
            # Safe restricted eval
            result = eval(cleaned, {"__builtins__": {}}, safe_dict)
            return round(result, 4) if isinstance(result, float) else result
        except ZeroDivisionError:
            return "Error: Division by zero is undefined."
        except Exception as ex:
            return f"Error evaluating expression: {type(ex).__name__} ({str(ex)})"


class SearchTool(Tool):
    """Simulated web search and database lookup tool."""
    def __init__(self):
        schema = {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query string."
                }
            },
            "required": ["query"]
        }
        super().__init__("web_search", "Searches knowledge base and simulated live web index.", schema)
        self.kb = {
            "stock price company x": "Company X closing stock prices over the last 3 days: Day 1: $150.00, Day 2: $155.00, Day 3: $152.00.",
            "population monaco": "Monaco: Population is 39,000 residents. Total land area is 2.08 square kilometers.",
            "mlai401 grid world penalty": "In the MLAI401 Grid World MDP, the living step penalty is -0.04 per movement.",
            "paris weather": "Paris, France: Current temperature 18.5 C with light rain showers.",
            "python division edge case": "In Python, dividing integers by zero raises ZeroDivisionError. Safe division requires validating denominator != 0."
        }

    def execute(self, query=""):
        q_norm = query.lower().strip()
        for key, val in self.kb.items():
            if key in q_norm or all(word in q_norm for word in key.split()[:2]):
                return val
        return f"No direct search matches found for '{query}'. Try refining keywords."


class PythonReplTool(Tool):
    """Executes small self-contained Python statements and returns stdout / return value."""
    def __init__(self):
        schema = {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Python snippet to execute."
                }
            },
            "required": ["code"]
        }
        super().__init__("python_repl", "Executes pure Python arithmetic or data transformations in a sandbox.", schema)

    def execute(self, code=""):
        # Safe mathematical sandbox execution
        safe_globals = {"math": math, "__builtins__": {"range": range, "len": len, "sum": sum, "min": min, "max": max}}
        loc = {}
        try:
            exec(code, safe_globals, loc)
            return loc.get("result", "Execution succeeded with no explicit 'result' variable.")
        except Exception as e:
            return f"Runtime Error: {type(e).__name__}: {str(e)}"


class FileWriterTool(Tool):
    """Simulates writing structured text or reports to disk."""
    def __init__(self):
        schema = {
            "type": "object",
            "properties": {
                "filename": {"type": "string", "description": "Target filename."},
                "content": {"type": "string", "description": "Content string to save."}
            },
            "required": ["filename", "content"]
        }
        super().__init__("file_writer", "Saves text data or reports to a simulated file buffer.", schema)
        self.virtual_fs = {}

    def execute(self, filename="", content=""):
        self.virtual_fs[filename] = content
        return f"File '{filename}' successfully written ({len(content)} bytes)."


# ==============================================================================
# 2. Interactive Code Traces for Lecture Demonstrations
# ==============================================================================

def trace_react_loop():
    """
    Code Trace 4: Autonomous ReAct loop executing multi-step reasoning & tool calling.
    Task: Calculate square root of 1764 and multiply by 3.
    Traced on agentic.html#code
    """
    print("\n" + "=" * 70)
    print("CODE TRACE 4: Autonomous ReAct Loop (Thought -> Act -> Observe -> Replan)")
    print("=" * 70)

    registry = ToolRegistry()
    registry.register(CalculatorTool())
    registry.register(SearchTool())
    registry.register(FileWriterTool())

    agent = ReActAgent("MathResearcher", tool_registry=registry)

    # Deterministic sequence of thoughts and actions
    plan = [
        {
            "thought": "The user wants to find sqrt(1764) * 3. First, I must compute sqrt(1764).",
            "action": {"tool": "calculator", "args": {"expression": "sqrt(1764)"}}
        },
        {
            "thought": "The square root of 1764 is 42.0. Now I need to multiply this result by 3.",
            "action": {"tool": "calculator", "args": {"expression": "42.0 * 3"}}
        },
        {
            "thought": "The product is 126.0. I have accomplished both arithmetic subgoals.",
            "is_final": True,
            "final_answer": "The square root of 1764 is 42, and 42 * 3 = 126.0."
        }
    ]

    result = agent.run("Calculate sqrt(1764) and multiply by 3", plan_steps=plan)

    print("\nExecution Scratchpad Trace:")
    for step in result["scratchpad"]:
        print(f"Step {step['step_index']}:")
        print(f"  Thought:     {step['thought']}")
        if step.get("action"):
            print(f"  Action:      {step['action']}")
        if step.get("observation"):
            print(f"  Observation: {step['observation']}")

    print(f"\nFinal Answer: {result['final_answer']}")


def trace_error_recovery():
    """
    Demonstrates ReAct Self-Correction on unexpected Tool Errors.
    """
    print("\n" + "=" * 70)
    print("CODE TRACE 4B: ReAct Self-Correction on Tool Error")
    print("=" * 70)

    registry = ToolRegistry()
    calc = CalculatorTool()
    registry.register(calc)

    agent = ReActAgent("ResilientAgent", tool_registry=registry)

    # Trace showing an error recovery loop
    plan = [
        {
            "thought": "I need to compute the ratio 100 / (5 - 5). Let me evaluate this expression.",
            "action": {"tool": "calculator", "args": {"expression": "100 / (5 - 5)"}}
        },
        {
            "thought": "The tool returned an error: 'Division by zero is undefined'. The denominator 5 - 5 is 0. I must report this undefined condition rather than crashing.",
            "is_final": True,
            "final_answer": "The expression evaluates to division by zero, which is mathematically undefined."
        }
    ]

    result = agent.run("Evaluate 100 / (5 - 5)", plan_steps=plan)
    print("Self-Correction Scratchpad:")
    for step in result["scratchpad"]:
        print(f"Step {step['step_index']}:")
        print(f"  Thought:     {step['thought']}")
        print(f"  Action:      {step.get('action')}")
        print(f"  Observation: {step.get('observation')}")
    print(f"Result: {result['final_answer']}")


def trace_multi_agent_delegation():
    """
    Code Trace 5: Multi-Agent Collaboration (Hierarchical Generator-Critic Team).
    Manager delegates code writing to Developer Agent; Critic Agent audits for edge cases.
    Traced on agentic.html#code
    """
    print("\n" + "=" * 70)
    print("CODE TRACE 5: Multi-Agent Software Development Squad (Manager -> Coder -> Critic)")
    print("=" * 70)

    system = MultiAgentSystem()

    # Turn 1: Manager receives user request and posts decomposition task to Coder
    task_spec = "Implement a Python function 'safe_divide(a, b)' that handles zero denominators safely."
    msg1 = system.post_message(
        sender="ManagerAgent",
        recipient="DeveloperAgent",
        content={"task": "code_generation", "specification": task_spec},
        message_type="task_assignment"
    )
    print(f"[Msg {msg1['message_id']}] {msg1['sender']} -> {msg1['recipient']}: Assigned task: '{task_spec}'")

    # Turn 2: Developer writes initial implementation (naive draft with potential flaw)
    initial_code = "def safe_divide(a, b):\n    return a / b"
    msg2 = system.post_message(
        sender="DeveloperAgent",
        recipient="CriticAgent",
        content={"draft_code": initial_code, "note": "Initial implementation submitted for audit."},
        message_type="code_submission"
    )
    print(f"[Msg {msg2['message_id']}] {msg2['sender']} -> {msg2['recipient']}: Submitted code draft for review:\n{initial_code}")

    # Turn 3: Critic audits code, flags missing ZeroDivision check, and rejects
    review_verdict = {
        "approved": False,
        "bug_found": "ZeroDivisionError unhandled when b == 0.",
        "recommended_fix": "Add 'if b == 0: return None' check."
    }
    msg3 = system.post_message(
        sender="CriticAgent",
        recipient="DeveloperAgent",
        content=review_verdict,
        message_type="code_review_feedback"
    )
    print(f"[Msg {msg3['message_id']}] {msg3['sender']} -> {msg3['recipient']}: REJECTED. Feedback: {review_verdict['bug_found']}")

    # Turn 4: Developer Agent modifies code to address Critic's feedback
    refined_code = "def safe_divide(a, b):\n    if b == 0:\n        return None\n    return a / b"
    msg4 = system.post_message(
        sender="DeveloperAgent",
        recipient="CriticAgent",
        content={"draft_code": refined_code, "note": "Fixed ZeroDivisionError handling."},
        message_type="code_resubmission"
    )
    print(f"[Msg {msg4['message_id']}] {msg4['sender']} -> {msg4['recipient']}: Resubmitted revised code:\n{refined_code}")

    # Turn 5: Critic audits revised code and approves
    final_approval = {
        "approved": True,
        "verdict": "All edge cases handled. safe_divide(10, 0) safely returns None.",
        "status": "READY_FOR_DEPLOYMENT"
    }
    msg5 = system.post_message(
        sender="CriticAgent",
        recipient="ManagerAgent",
        content=final_approval,
        message_type="final_approval"
    )
    print(f"[Msg {msg5['message_id']}] {msg5['sender']} -> {msg5['recipient']}: APPROVED (Status: {final_approval['status']})")


# ==============================================================================
# 3. Main Verification Suite
# ==============================================================================

if __name__ == "__main__":
    print("Running Topic 07 Agentic AI Test Suite...")
    trace_react_loop()
    trace_error_recovery()
    trace_multi_agent_delegation()
    print("\nAll Agentic AI benchmarks and multi-agent coordination traces passed.")
