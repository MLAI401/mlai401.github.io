"""
04_IDS.py -- Iterative Deepening Search

IDS = repeated depth-limited DFS, with the depth limit increased by one after
every failed iteration. Within a single iteration the frontier behaves
exactly like DFS (a LIFO stack); across iterations, the search restarts from
the root every time, so early nodes are intentionally revisited.

Reference: aima-python's iterative_deepening_search
(https://github.com/aimacode/aima-python/blob/master/search.py), reimplemented
here from scratch against the shared GraphProblem in graph_problem.py.

Teaching point from instructions/search.md ("IDS Reached / Repeated Nodes"):
seeing the start node (and shallow nodes) expanded again in every iteration
is expected, not a bug -- IDS trades repeated work for low memory usage and
completeness.

Run:
    python 04_IDS.py
"""

from graph_problem import GRAPH, GraphProblem, Node, expand, print_result

CUTOFF = "cutoff"  # sentinel: this branch hit the depth limit, keep looking deeper
MAX_DEPTH = len(GRAPH)  # graph is finite/small, so this is a safe upper bound


def depth_limited_search(problem: GraphProblem, depth_limit: int, expanded_order: list):
    frontier = [Node(problem.initial)]
    cutoff_occurred = False

    while frontier:
        node = frontier.pop()  # SELECT (LIFO, same as DFS)

        if problem.goal_test(node.state):
            return node, cutoff_occurred

        if node.depth >= depth_limit:
            print(f"  {node.state} at depth {node.depth} == limit {depth_limit} -> depth limit reached, DO NOT EXPAND")
            cutoff_occurred = True
            continue

        expanded_order.append(node.state)
        children = expand(problem, node)
        print(f"  Expand {node.state:<2} (depth {node.depth}) | successors={[c.state for c in children]}")
        for child in reversed(children):  # push in reverse so alphabetical order is selected first
            frontier.append(child)

    return None, cutoff_occurred


def iterative_deepening_search(problem: GraphProblem):
    all_expanded = []  # combined expanded order across every iteration, for the summary

    for depth_limit in range(MAX_DEPTH + 1):
        print(f"\n-- Iteration: Depth Limit = {depth_limit} (RESET FRONTIER, restart from {problem.initial}) --")
        iteration_expanded = []
        result, cutoff = depth_limited_search(problem, depth_limit, iteration_expanded)
        all_expanded.extend(iteration_expanded)

        if result is not None:
            return result, all_expanded
        if not cutoff:
            # Every branch finished without hitting the depth limit: nothing
            # deeper to find -- the graph truly has no solution.
            return None, all_expanded

    return None, all_expanded


if __name__ == "__main__":
    problem = GraphProblem()
    goal_node, expanded = iterative_deepening_search(problem)
    print_result(problem, goal_node, expanded, "IDS (Iterative Deepening Search)")
