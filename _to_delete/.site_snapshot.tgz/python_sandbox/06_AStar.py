"""
06_AStar.py -- A* Search

Frontier = priority queue ordered by f(n) = g(n) + h(n): accumulated path
cost PLUS the heuristic estimate to the goal. Combines UCS's optimality
guarantee with Greedy's heuristic guidance -- optimal here because the
heuristic table in graph_problem.py is admissible (never overestimates).

Reference: aima-python's astar_search
(https://github.com/aimacode/aima-python/blob/master/search.py), reimplemented
here from scratch against the shared GraphProblem in graph_problem.py.

Same cost-update discipline as UCS ("UCS Cost Updates" in
instructions/search.md): if a cheaper g(n) to an already-reached state is
found, reached[] and the frontier entry are updated. Goal test happens on
SELECTION, not generation -- the same reasoning as UCS applies: a cheaper
path to the goal may still be sitting in the frontier.

    Frontier (ordered by f=g+h) -> Select -> Goal Test -> Expand -> Update

Run:
    python 06_AStar.py
"""

import heapq
import itertools

from graph_problem import GraphProblem, Node, expand, print_result


def astar_search(problem: GraphProblem):
    counter = itertools.count()
    root = Node(problem.initial)

    f_root = root.path_cost + problem.h(root.state)
    frontier = [(f_root, next(counter), root)]  # priority queue by f(n) = g(n) + h(n)
    reached = {root.state: root.path_cost}  # state -> best g(n) found so far
    expanded_order = []

    while frontier:
        f_val, _, node = heapq.heappop(frontier)  # SELECT: lowest f(n)
        if node.path_cost > reached.get(node.state, float("inf")):
            continue  # stale entry, a cheaper one already replaced it

        if problem.goal_test(node.state):  # GOAL TEST only on selection
            return node, expanded_order

        expanded_order.append(node.state)  # EXPAND
        g, h = node.path_cost, problem.h(node.state)
        print(f"Select {node.state:<2} g(n)={g:<3} h(n)={h:<3} f(n)={g + h:<3}")

        for child in expand(problem, node):
            best_known = reached.get(child.state)
            if best_known is None or child.path_cost < best_known:
                if best_known is not None:
                    print(f"  {child.state}: existing g={best_known} -> new g={child.path_cost} -> UPDATE")
                else:
                    h_child = problem.h(child.state)
                    print(f"  {child.state}: new, g={child.path_cost} h={h_child} f={child.path_cost + h_child}")
                reached[child.state] = child.path_cost
                f_child = child.path_cost + problem.h(child.state)
                heapq.heappush(frontier, (f_child, next(counter), child))
            else:
                print(f"  {child.state}: existing g={best_known} <= new g={child.path_cost} -> IGNORE")

    return None, expanded_order


if __name__ == "__main__":
    problem = GraphProblem()
    goal_node, expanded = astar_search(problem)
    print_result(problem, goal_node, expanded, "A* Search")
