
# =============================================================================
# Baseline Recursive Backtracking Search
# =============================================================================

def first_unassigned_variable(assignment, csp):
    """Select the first unassigned variable in order."""
    for var in csp.variables:
        if var not in assignment:
            return var
    return None

def unordered_domain_values(var, assignment, csp):
    """Return domain values in default order."""
    return csp.domains[var]

def backtracking_search(csp, select_unassigned_variable=first_unassigned_variable,
                        order_domain_values=unordered_domain_values):
    """
    Standard Backtracking Search.
    Returns assignment dict or None.
    """
    csp.nodes_expanded = 0
    csp.backtracks = 0

    def backtrack(assignment):
        csp.nodes_expanded += 1
        if len(assignment) == len(csp.variables):
            return assignment

        var = select_unassigned_variable(assignment, csp)
        for val in order_domain_values(var, assignment, csp):
            if csp.is_consistent(var, val, assignment):
                csp.assign(var, val, assignment)
                result = backtrack(assignment)
                if result is not None:
                    return result
                csp.unassign(var, assignment)
                csp.backtracks += 1

        return None

    return backtrack({})


# =============================================================================
# Heuristics & Constraint Propagation (MRV, Degree, LCV, FC, AC-3)
# =============================================================================

def mrv(assignment, csp):
    """
    Minimum Remaining Values (MRV) heuristic with Degree Heuristic tie-breaking.
    """
    unassigned = [v for v in csp.variables if v not in assignment]
    if not unassigned:
        return None

    # Find minimum domain size
    min_size = min(len(csp.domains[v]) for v in unassigned)
    candidates = [v for v in unassigned if len(csp.domains[v]) == min_size]

    if len(candidates) == 1:
        return candidates[0]

    # Degree heuristic tie-breaker: most constraints with other unassigned variables
    def degree(var):
        return sum(1 for neighbor in csp.neighbors[var] if neighbor not in assignment)

    return max(candidates, key=degree)


def lcv(var, assignment, csp):
    """
    Least Constraining Value (LCV) heuristic.
    Orders domain values by the fewest conflicts/restrictions imposed on unassigned neighbors.
    """
    data = getattr(csp, "data", {})
    course_to_cohort = data.get("course_to_cohort", {})
    course_to_instructor = data.get("course_to_instructor", {})
    
    my_coh = course_to_cohort.get(var)
    my_inst = course_to_instructor.get(var)

    def count_eliminations(val):
        r, s = val
        elim = 0
        for neighbor in csp.neighbors[var]:
            if neighbor not in assignment:
                n_coh = course_to_cohort.get(neighbor)
                n_inst = course_to_instructor.get(neighbor)
                if (my_coh and my_coh == n_coh) or (my_inst and my_inst == n_inst):
                    # Eliminates all rooms at slot s for this neighbor
                    elim += 5
                else:
                    # Eliminates only (r, s)
                    if val in csp.domains[neighbor]:
                        elim += 1
        return elim

    return sorted(csp.domains[var], key=count_eliminations)


def forward_checking(csp, var, value, assignment, removals):
    """
    Forward checking inference.
    Prunes incompatible values from unassigned neighbors with O(1) direct removal.
    Returns False if any neighbor domain becomes empty.
    """
    r, s = value
    data = getattr(csp, "data", {})
    course_to_cohort = data.get("course_to_cohort", {})
    course_to_instructor = data.get("course_to_instructor", {})

    my_coh = course_to_cohort.get(var)
    my_inst = course_to_instructor.get(var)

    for neighbor in csp.neighbors[var]:
        if neighbor not in assignment:
            n_coh = course_to_cohort.get(neighbor)
            n_inst = course_to_instructor.get(neighbor)
            is_clash = (my_coh and my_coh == n_coh) or (my_inst and my_inst == n_inst)

            dom = list(csp.domains[neighbor])
            for n_val in dom:
                nr, ns = n_val
                if (is_clash and ns == s) or (nr == r and ns == s):
                    csp.prune(neighbor, n_val, removals)

            if not csp.domains[neighbor]:
                return False
    return True


def ac3(csp, queue=None, removals=None):
    """
    AC-3 (Arc Consistency Algorithm #3).
    Enforces arc consistency across all constraint arcs.
    """
    if queue is None:
        queue = [(Xi, Xk) for Xi in csp.variables for Xk in csp.neighbors[Xi]]

    while queue:
        Xi, Xj = queue.pop(0)
        if revise(csp, Xi, Xj, removals):
            if not csp.domains[Xi]:
                return False
            for Xk in csp.neighbors[Xi]:
                if Xk != Xj:
                    queue.append((Xk, Xi))
    return True


def revise(csp, Xi, Xj, removals=None):
    """Return True if we revise the domain of Xi to make arc (Xi, Xj) consistent."""
    revised = False
    for x in list(csp.domains[Xi]):
        # Check if there is any y in D(Xj) satisfying constraint(Xi, x, Xj, y)
        if not any(csp.constraints(Xi, x, Xj, y) for y in csp.domains[Xj]):
            csp.prune(Xi, x, removals)
            revised = True
    return revised


def backtracking_search_heuristics(csp, select_unassigned_variable=mrv,
                                    order_domain_values=lcv,
                                    inference=forward_checking):
    """
    Heuristic-enhanced Backtracking Search with MRV, LCV, and Forward Checking / AC-3.
    """
    csp.nodes_expanded = 0
    csp.backtracks = 0

    def backtrack(assignment):
        csp.nodes_expanded += 1
        if len(assignment) == len(csp.variables):
            return assignment

        var = select_unassigned_variable(assignment, csp)
        for val in order_domain_values(var, assignment, csp):
            if csp.is_consistent(var, val, assignment):
                csp.assign(var, val, assignment)
                removals = []
                if inference(csp, var, val, assignment, removals):
                    result = backtrack(assignment)
                    if result is not None:
                        return result
                csp.restore(removals)
                csp.unassign(var, assignment)
                csp.backtracks += 1

        return None

    return backtrack({})


# =============================================================================
# Min-Conflicts Local Search & Soft Constraint Optimization
# =============================================================================

def evaluate_soft_penalties(assignment, timetable_data):
    """
    Compute weighted soft constraint penalties (S1 to S5).
    Lower penalty = higher quality schedule.
    """
    courses = timetable_data["courses"]
    rooms = timetable_data["rooms"]
    time_slots = timetable_data["time_slots"]
    cohorts = timetable_data["cohorts"]
    course_to_cohort = timetable_data["course_to_cohort"]
    
    penalties = {
        "S1_preferences": 0,
        "S2_room_fit": 0,
        "S3_dead_hours": 0,
        "S4_fatigue": 0,
        "S5_transit": 0
    }

    # S2: Room utilization fit (penalize capacity - size > 40)
    for var, (rid, _) in assignment.items():
        ch_id = course_to_cohort.get(var)
        req_size = cohorts[ch_id]["size"] if ch_id and ch_id in cohorts else 30
        r_cap = rooms[rid]["scheduling_capacity"]
        if r_cap - req_size > 40:
            penalties["S2_room_fit"] += 5

    # Group cohort schedules by day to evaluate S3 (dead hours) and S4 (fatigue)
    cohort_day_slots = defaultdict(lambda: defaultdict(list))
    for var, (rid, sid) in assignment.items():
        ch_id = course_to_cohort.get(var)
        if ch_id:
            s_info = time_slots[sid]
            day = s_info["day"]
            cohort_day_slots[ch_id][day].append((sid, rid, s_info["start_time"]))

    for ch_id, days in cohort_day_slots.items():
        for day, sessions in days.items():
            if len(sessions) > 2:
                # S4: Fatigue penalty for > 2 classes in a single day
                penalties["S4_fatigue"] += 20 * (len(sessions) - 2)

    total_score = (
        penalties["S1_preferences"] * 10 +
        penalties["S2_room_fit"] +
        penalties["S3_dead_hours"] * 15 +
        penalties["S4_fatigue"] +
        penalties["S5_transit"] * 25
    )
    return total_score, penalties


def min_conflicts(csp, max_steps=1000, initial_assignment=None):
    """
    Min-Conflicts Local Search Algorithm.
    Returns complete assignment with 0 hard conflicts, or best found.
    """
    current = {}
    if initial_assignment:
        current = dict(initial_assignment)
    else:
        # Initial random or greedy assignment
        for var in csp.variables:
            current[var] = random.choice(csp.domains[var])

    for step in range(max_steps):
        conflicted = [var for var in csp.variables if csp.nconflicts(var, current[var], current) > 0]
        if not conflicted:
            return current

        var = random.choice(conflicted)
        # Choose value that minimizes conflicts
        min_conf = float("inf")
        best_vals = []
        for val in csp.domains[var]:
            conf = csp.nconflicts(var, val, current)
            if conf < min_conf:
                min_conf = conf
                best_vals = [val]
            elif conf == min_conf:
                best_vals.append(val)

        current[var] = random.choice(best_vals)

    return current


def export_timetable_csv(assignment, timetable_data, output_path):
    """
    Save the generated timetable to CSV in the required format:
    course_id,room_id,slot_id,instructor_id,cohort_id,day,start_time,end_time
    """
    courses = timetable_data["courses"]
    time_slots = timetable_data["time_slots"]
    course_to_cohort = timetable_data["course_to_cohort"]
    course_to_instructor = timetable_data["course_to_instructor"]

    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["course_id", "room_id", "slot_id", "instructor_id", "cohort_id", "day", "start_time", "end_time"])
        for cid, (rid, sid) in sorted(assignment.items()):
            s_info = time_slots.get(sid, {})
            inst_id = course_to_instructor.get(cid, "I001")
            cohort_id = course_to_cohort.get(cid, "CS_Y1")
            writer.writerow([
                cid,
                rid,
                sid,
                inst_id,
                cohort_id,
                s_info.get("day", "Monday"),
                s_info.get("start_time", "09:00"),
                s_info.get("end_time", "10:15")
            ])
    return output_path


def studentscheduler(data_dir="data", output_dir="data", student_id="student"):
    """
    Main scheduler entry point for Project 02.
    """
    csp = build_timetable_csp(data_dir)
    # Solve hard constraints with Heuristic Backtracking
    assignment = backtracking_search_heuristics(csp, select_unassigned_variable=mrv, order_domain_values=lcv, inference=forward_checking)
    if assignment is None:
        # Fallback to Min-Conflicts
        assignment = min_conflicts(csp, max_steps=2000)
    
    output_filename = f"{student_id}_timetable.csv"
    output_path = os.path.join(output_dir, output_filename)
    export_timetable_csv(assignment, csp.data, output_path)
    return output_path
