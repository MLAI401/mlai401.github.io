"""
Shared graph / problem definitions for the MLAI401 search-algorithm demos.

The graph, edge costs, and heuristic values below are IDENTICAL to the ones
used in the site's interactive "Graph Search Algorithms" demo
(demos/search_demo/graph.js -> GRAPH and DEFAULT_HEURISTICS_TO_G), so running
these scripts reproduces exactly what you see in the Playground.

Structured after the Problem / Node abstraction used in aima-python
(https://github.com/aimacode/aima-python/blob/master/search.py) -- a
lightweight from-scratch reimplementation, not a copy of that file, kept
intentionally small so each numbered algorithm script stays easy to read.

AIMA terminology used throughout (see instructions/search.md):
    State, Node, Frontier, Reached, Selected Node, Expanded Node,
    Successor, Path, Path Cost, Depth, Goal Test.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


# ---------------------------------------------------------------------------
# The graph: same directed, weighted edges as demos/search_demo/graph.js
# ---------------------------------------------------------------------------
GRAPH = {
    "A": [("B", 3), ("C", 2), ("E", 9)],
    "B": [("D", 2), ("E", 4)],
    "C": [("E", 6), ("F", 9)],
    "D": [("G", 3)],
    "E": [("G", 1), ("H", 2)],
    "F": [("H", 1)],
    "G": [("H", 5)],
    "H": [],
}

# Heuristic estimates h(n) -> distance to goal "G". Admissible & consistent
# for this graph -- same values as DEFAULT_HEURISTICS_TO_G in graph.js.
HEURISTIC_TO_G = {"A": 6, "B": 4, "C": 6, "D": 3, "E": 1, "F": 6, "G": 0, "H": 5}

DEFAULT_START = "A"
DEFAULT_GOAL = "G"


def heuristic(node: str, goal: str = DEFAULT_GOAL) -> float:
    """h(n): estimated cost from `node` to `goal`."""
    if node == goal:
        return 0
    if goal == DEFAULT_GOAL:
        return HEURISTIC_TO_G.get(node, 0)
    return 0  # heuristic table is only tuned for goal "G", matching the demo


def successors(node: str):
    """(neighbor, step_cost) pairs for `node`, in alphabetical order.

    search.md requires successors to be processed alphabetically so every
    algorithm's expansion order is deterministic and comparable.
    """
    return sorted(GRAPH.get(node, []), key=lambda pair: pair[0])


@dataclass
class Node:
    """A node in the search tree (distinct from a graph *state*)."""

    state: str
    parent: Optional["Node"] = None
    action: Optional[str] = None  # the edge taken to reach this state
    path_cost: float = 0.0  # g(n): cost from the start to this node
    depth: int = 0

    def path(self) -> list[str]:
        """States from the root to this node, inclusive, start-to-end order."""
        node, states = self, []
        while node is not None:
            states.append(node.state)
            node = node.parent
        return list(reversed(states))

    def __repr__(self) -> str:
        return f"<Node {self.state} g={self.path_cost}>"


class GraphProblem:
    """Minimal Problem formulation, in the spirit of aima-python's Problem class."""

    def __init__(self, initial: str = DEFAULT_START, goal: str = DEFAULT_GOAL, graph=GRAPH):
        self.initial = initial
        self.goal = goal
        self.graph = graph

    def actions(self, state: str) -> list[str]:
        return [to for to, _ in successors(state)]

    def result(self, state: str, action: str) -> str:
        return action  # in this simple graph, the action name IS the resulting state

    def step_cost(self, state: str, action: str) -> float:
        for to, cost in successors(state):
            if to == action:
                return cost
        raise ValueError(f"No edge {state} -> {action}")

    def goal_test(self, state: str) -> bool:
        return state == self.goal

    def h(self, state: str) -> float:
        return heuristic(state, self.goal)


def expand(problem: GraphProblem, node: Node) -> list[Node]:
    """GENERATE: build the child nodes of `node`, in alphabetical successor order."""
    children = []
    for action in problem.actions(node.state):
        child_state = problem.result(node.state, action)
        cost = node.path_cost + problem.step_cost(node.state, action)
        children.append(
            Node(child_state, parent=node, action=action, path_cost=cost, depth=node.depth + 1)
        )
    return children


def print_result(problem: GraphProblem, goal_node: Optional[Node], expanded_order: list[str], algorithm_name: str) -> None:
    """Final Result Panel, matching the site's search demo output."""
    print(f"\n=== {algorithm_name}: {problem.initial} -> {problem.goal} ===")
    print(f"Expanded Node Order : {' -> '.join(expanded_order) if expanded_order else '(none)'}")
    if goal_node is not None:
        print(f"Solution Path       : {' -> '.join(goal_node.path())}")
        print(f"Path Cost           : {goal_node.path_cost}")
    else:
        print("Solution Path       : No solution found.")
    print(f"Nodes Expanded      : {len(expanded_order)}")
