"""
01_BFS.py -- Breadth-First Search

Frontier = FIFO queue (First In, First Out).

Reference: aima-python's breadth_first_graph_search
(https://github.com/aimacode/aima-python/blob/master/search.py), reimplemented
here from scratch against the shared GraphProblem in graph_problem.py.

Teaching point from instructions/search.md ("BFS Early Goal Test"): BFS tests
each newly generated child against the goal *immediately*, before it is ever
placed on the frontier -- it does not wait for that child to be selected.
This lets BFS stop as soon as the goal is generated, even while other nodes
are still waiting in the frontier.

    Frontier -> Select -> Goal Test -> Expand -> Update Frontier

Run:
    python 01_BFS.py
"""

from collections import deque

from graph_problem import GraphProblem, Node, expand, print_result


def breadth_first_search(problem: GraphProblem):
    root = Node(problem.initial)

    # Early goal test: check the start state itself before anything else.
    if problem.goal_test(root.state):
        return root, []

    frontier = deque([root])   # FIFO queue
    reached = {root.state}     # states already discovered (frontier + expanded)
    expanded_order = []

    while frontier:
        node = frontier.popleft()          # SELECT: oldest node in the queue
        expanded_order.append(node.state)  # EXPAND
        print(f"Expand {node.state:<2} | frontier={[n.state for n in frontier]} | reached={sorted(reached)}")

        for child in expand(problem, node):
            if child.state in reached:
                print(f"  generate {child.state} -> already reached, skip")
                continue
            reached.add(child.state)
            print(f"  generate {child.state}")

            if problem.goal_test(child.state):  # EARLY GOAL TEST on generation
                print(f"  {child.state} is the goal -- stop immediately")
                return child, expanded_order

            frontier.append(child)  # UPDATE FRONTIER (added to the back)

    return None, expanded_order  # frontier exhausted, no solution


if __name__ == "__main__":
    problem = GraphProblem()
    goal_node, expanded = breadth_first_search(problem)
    print_result(problem, goal_node, expanded, "BFS (Breadth-First Search)")
