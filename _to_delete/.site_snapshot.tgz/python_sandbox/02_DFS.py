"""
02_DFS.py -- Depth-First Search

Frontier = LIFO stack (Last In, First Out).

Reference: aima-python's depth_first_graph_search
(https://github.com/aimacode/aima-python/blob/master/search.py), reimplemented
here from scratch against the shared GraphProblem in graph_problem.py.

Teaching point from instructions/search.md ("DFS and Alphabetical Successor
Order"): successors must still be *generated* alphabetically (B, C, E, ...),
but because a stack reverses order, they must be *pushed* in reverse
(..., E, C, B) so that B -- the alphabetically-first successor -- ends up on
top and is selected next. Goal test happens on SELECTION here (not on
generation, unlike BFS).

    Frontier -> Select -> Goal Test -> Expand -> Push successors (reversed)

Run:
    python 02_DFS.py
"""

from graph_problem import GraphProblem, Node, expand, print_result


def depth_first_search(problem: GraphProblem):
    frontier = [Node(problem.initial)]  # LIFO stack
    reached = {problem.initial}
    expanded_order = []

    while frontier:
        node = frontier.pop()  # SELECT: most recently pushed node (top of stack)

        if problem.goal_test(node.state):  # GOAL TEST on selection
            return node, expanded_order

        expanded_order.append(node.state)  # EXPAND
        children = expand(problem, node)   # generated alphabetically: e.g. B, C, E
        print(f"Expand {node.state:<2} | successors={[c.state for c in children]} | stack-before={[n.state for n in frontier]}")

        # Push in reverse alphabetical order so the alphabetically-first
        # successor lands on top of the stack and is selected next.
        for child in reversed(children):
            if child.state in reached:
                print(f"  push {child.state} -> already reached, skip")
                continue
            reached.add(child.state)
            frontier.append(child)
        print(f"  stack-after={[n.state for n in frontier]}")

    return None, expanded_order


if __name__ == "__main__":
    problem = GraphProblem()
    goal_node, expanded = depth_first_search(problem)
    print_result(problem, goal_node, expanded, "DFS (Depth-First Search)")
