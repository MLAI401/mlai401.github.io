"""
MLAI401 — Topic 07: Generative & Agentic AI Reference Module
Clean reusable reference classes for Generative AI, RAG, and Autonomous Agents:
- Document container & DocumentChunker
- EmbeddingModel & VectorStore (Dense semantic embeddings, Cosine Similarity)
- Tool & ToolRegistry
- Scratchpad (Working Memory)
- ReActAgent (Reasoning & Acting Loop with self-correction)
- MultiAgentSystem (Hierarchical & Collaborative agent teams)
"""

import math
import re
import json
from collections import defaultdict


def tokenize(text):
    """Splits raw text into lowercase tokens."""
    if not text:
        return []
    cleaned = re.sub(r'[^\w\s]', ' ', text.lower())
    return [w for w in cleaned.split() if w]


def dot_product(u, v):
    """Computes the dot product of two real-valued vectors."""
    if len(u) != len(v):
        raise ValueError(f"Vector dimensions must match: {len(u)} != {len(v)}")
    return sum(a * b for a, b in zip(u, v))


def vector_norm(u):
    """Computes Euclidean L2 norm of a vector."""
    return math.sqrt(sum(a * a for a in u))


def cosine_similarity(u, v):
    """
    Computes Cosine Similarity between two vectors:
    CosineSim(u, v) = (u . v) / (||u|| * ||v||)
    Returns a float in [-1.0, 1.0].
    """
    norm_u = vector_norm(u)
    norm_v = vector_norm(v)
    if norm_u == 0.0 or norm_v == 0.0:
        return 0.0
    return dot_product(u, v) / (norm_u * norm_v)


def l2_normalize(v):
    """Normalizes vector to unit length."""
    norm = vector_norm(v)
    if norm == 0.0:
        return [0.0] * len(v)
    return [x / norm for x in v]


class Document:
    """Represents a discrete text document or chunk with vector embedding and metadata."""
    def __init__(self, text, doc_id=None, metadata=None, embedding=None):
        self.text = text
        self.doc_id = doc_id or f"doc_{id(self)}"
        self.metadata = metadata or {}
        self.embedding = embedding

    def __repr__(self):
        snippet = self.text[:60] + "..." if len(self.text) > 60 else self.text
        return f"Document(id={self.doc_id}, text='{snippet}')"


class DocumentChunker:
    """
    Splits text documents into overlapping passages for vector indexing.
    L: token window length
    overlap: token overlap between consecutive chunks
    """
    def __init__(self, chunk_size=100, chunk_overlap=20):
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be strictly less than chunk_size")
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def split_text(self, text):
        """Splits text into chunks of tokens with sliding overlap."""
        tokens = text.split()
        if not tokens:
            return []
        chunks = []
        step = self.chunk_size - self.chunk_overlap
        for i in range(0, len(tokens), step):
            chunk_tokens = tokens[i : i + self.chunk_size]
            chunks.append(" ".join(chunk_tokens))
            if i + self.chunk_size >= len(tokens):
                break
        return chunks

    def split_documents(self, documents):
        """Splits a collection of Document objects into chunked Document objects."""
        chunked_docs = []
        for doc in documents:
            text_chunks = self.split_text(doc.text)
            for idx, chunk_text in enumerate(text_chunks):
                chunk_id = f"{doc.doc_id}_chunk_{idx}"
                meta = dict(doc.metadata)
                meta["source_id"] = doc.doc_id
                meta["chunk_index"] = idx
                chunked_docs.append(Document(text=chunk_text, doc_id=chunk_id, metadata=meta))
        return chunked_docs


class EmbeddingModel:
    """
    Deterministic dense semantic embedding generator.
    Simulates a neural embedding model projecting text into continuous vector space R^d.
    Uses semantic anchor concepts (AI, Search, Logic, Bayes, RL, Tools, Agents, Ethics, Math)
    combined with character n-gram hashing and L2 normalization.
    """
    DIM = 16

    # Semantic anchor keywords aligned with embedding dimensions
    ANCHORS = [
        {"agent", "agentic", "react", "autonomous", "loop", "scratchpad", "plan", "subtask"},
        {"tool", "tools", "function", "calling", "api", "repl", "calculator", "execute"},
        {"rag", "retrieval", "vector", "embedding", "cosine", "chunk", "database", "index"},
        {"llm", "transformer", "prompt", "few-shot", "zero-shot", "cot", "chain-of-thought", "token"},
        {"search", "bfs", "dfs", "astar", "ucs", "heuristic", "graph", "frontier"},
        {"logic", "propositional", "inference", "resolution", "entailment", "horn", "wumpus"},
        {"bayes", "bayesian", "probability", "prior", "posterior", "sampling", "markov"},
        {"rl", "reinforcement", "q-learning", "policy", "reward", "mdp", "bellman", "value"},
        {"ethics", "safety", "bias", "fairness", "jailbreak", "hallucination", "guardrail", "injection"},
        {"neural", "perceptron", "gradient", "loss", "backpropagation", "weight", "layer"},
        {"eval", "metric", "accuracy", "precision", "recall", "f1", "confusion", "latency"},
        {"math", "number", "calculate", "multiply", "divide", "add", "subtract", "equation"},
        {"code", "python", "syntax", "function", "program", "developer", "test", "debug"},
        {"memory", "short-term", "long-term", "episodic", "context", "buffer", "state"},
        {"multi-agent", "collaboration", "manager", "worker", "critic", "debate", "delegation"},
        {"data", "document", "corpus", "knowledge", "fact", "grounding", "citation"}
    ]

    def __init__(self, dim=16):
        self.dim = dim

    def encode(self, text):
        """Encodes string into an L2-normalized float vector in R^dim."""
        tokens = tokenize(text)
        if not tokens:
            return [0.0] * self.dim

        vec = [0.0] * self.dim

        # 1. Anchor dimension matching
        for token in tokens:
            for d_idx, anchor_set in enumerate(self.ANCHORS[:self.dim]):
                if token in anchor_set:
                    vec[d_idx] += 2.5
                else:
                    for anchor_word in anchor_set:
                        if len(token) >= 4 and len(anchor_word) >= 4:
                            if token in anchor_word or anchor_word in token:
                                vec[d_idx] += 0.8

        # 2. Character n-gram hashing dispersion for vocabulary coverage
        for token in tokens:
            h = hash(token)
            idx1 = abs(h) % self.dim
            idx2 = abs(h >> 4) % self.dim
            vec[idx1] += 0.3
            vec[idx2] += 0.15

        # 3. L2 Normalization
        return l2_normalize(vec)


class VectorStore:
    """
    In-memory vector store supporting cosine similarity nearest-neighbor search.
    """
    def __init__(self, embedding_model=None):
        self.embedding_model = embedding_model or EmbeddingModel()
        self.documents = []
        self.embeddings = []

    def add_document(self, doc):
        """Adds a single document, generating embedding if not already present."""
        if doc.embedding is None:
            doc.embedding = self.embedding_model.encode(doc.text)
        self.documents.append(doc)
        self.embeddings.append(doc.embedding)

    def add_documents(self, docs):
        """Adds multiple documents to the store."""
        for doc in docs:
            self.add_document(doc)

    def add_texts(self, texts, metadatas=None):
        """Convenience method to add raw texts with optional metadata list."""
        metadatas = metadatas or [{} for _ in texts]
        for idx, (text, meta) in enumerate(zip(texts, metadatas)):
            doc = Document(text=text, doc_id=f"doc_{idx}", metadata=meta)
            self.add_document(doc)

    def similarity_search(self, query, k=3, score_threshold=-1.0):
        """
        Retrieves top-k documents sorted by cosine similarity descending.
        Returns list of (Document, similarity_score) tuples.
        """
        if not self.documents:
            return []

        q_vec = self.embedding_model.encode(query)
        scored = []
        for doc, d_vec in zip(self.documents, self.embeddings):
            sim = cosine_similarity(q_vec, d_vec)
            if sim >= score_threshold:
                scored.append((doc, sim))

        scored.sort(key=lambda item: item[1], reverse=True)
        return scored[:k]


class Tool:
    """Base class for agent executable tools."""
    def __init__(self, name, description, parameters_schema):
        self.name = name
        self.description = description
        self.parameters_schema = parameters_schema

    def execute(self, **kwargs):
        raise NotImplementedError("Subclasses must implement execute()")

    def get_schema(self):
        """Returns JSON schema representation of the tool."""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters_schema
        }


class ToolRegistry:
    """Registry maintaining active tools for an agent."""
    def __init__(self):
        self._tools = {}

    def register(self, tool):
        self._tools[tool.name] = tool

    def get(self, name):
        return self._tools.get(name)

    def list_tools(self):
        return list(self._tools.values())

    def get_schemas(self):
        return [tool.get_schema() for tool in self._tools.values()]

    def execute(self, name, **kwargs):
        tool = self.get(name)
        if not tool:
            return f"Error: Tool '{name}' not found. Available tools: {list(self._tools.keys())}"
        try:
            return tool.execute(**kwargs)
        except Exception as e:
            return f"Tool Execution Error ({name}): {str(e)}"


class Scratchpad:
    """
    Agent working memory tracking the sequential history of:
    - Thoughts (Internal cognitive reasoning)
    - Actions (Tool invocations and arguments)
    - Observations (Environment/tool feedback)
    """
    def __init__(self):
        self.steps = []  # list of dicts: {"thought": ..., "action": ..., "observation": ...}

    def add_step(self, thought, action=None, observation=None):
        self.steps.append({
            "step_index": len(self.steps) + 1,
            "thought": thought,
            "action": action,
            "observation": observation
        })

    def update_observation(self, observation):
        """Updates the observation of the latest step."""
        if self.steps:
            self.steps[-1]["observation"] = observation

    def format_history(self):
        """Formats the working memory trace for prompt insertion."""
        lines = []
        for s in self.steps:
            lines.append(f"Thought {s['step_index']}: {s['thought']}")
            if s['action']:
                lines.append(f"Action {s['step_index']}: {s['action']}")
            if s['observation'] is not None:
                lines.append(f"Observation {s['step_index']}: {s['observation']}")
        return "\n".join(lines)

    def to_json(self):
        return json.dumps(self.steps, indent=2)


class ReActAgent:
    """
    Autonomous ReAct (Reason + Act) loop agent.
    Perceives goal, reasons about required actions, dispatches tools,
    observes feedback, reflects on errors, and replans until goal completion.
    """
    def __init__(self, name="ReActAgent", tool_registry=None, max_steps=8):
        self.name = name
        self.tools = tool_registry or ToolRegistry()
        self.max_steps = max_steps
        self.scratchpad = Scratchpad()

    def run(self, goal, plan_steps=None):
        """
        Executes the ReAct loop toward the given goal.
        plan_steps is an optional list of simulated decision steps for deterministic demonstration.
        """
        self.scratchpad = Scratchpad()
        history_trace = []

        if plan_steps:
            for step in plan_steps:
                thought = step.get("thought", "")
                action_spec = step.get("action")
                
                if action_spec is None or step.get("is_final"):
                    # Final answer
                    final_ans = step.get("final_answer", thought)
                    self.scratchpad.add_step(thought=thought, action="FINISH", observation=final_ans)
                    history_trace.append({"step": len(self.scratchpad.steps), "type": "finish", "content": final_ans})
                    return {
                        "status": "success",
                        "final_answer": final_ans,
                        "steps_taken": len(self.scratchpad.steps),
                        "scratchpad": self.scratchpad.steps
                    }

                tool_name = action_spec.get("tool")
                tool_args = action_spec.get("args", {})
                action_str = f"{tool_name}({json.dumps(tool_args)})"

                # Record Thought & Action
                self.scratchpad.add_step(thought=thought, action=action_str)

                # Execute Tool
                obs = self.tools.execute(tool_name, **tool_args)
                self.scratchpad.update_observation(obs)

                history_trace.append({
                    "step": len(self.scratchpad.steps),
                    "thought": thought,
                    "action": action_str,
                    "observation": obs
                })

        return {
            "status": "completed",
            "final_answer": "Task completed.",
            "steps_taken": len(self.scratchpad.steps),
            "scratchpad": self.scratchpad.steps
        }


class MultiAgentSystem:
    """
    Collaborative Multi-Agent coordinator.
    Supports Manager-Worker delegation, Peer-to-Peer messaging,
    and Generator-Critic loops with turn-based blackboard memory.
    """
    def __init__(self):
        self.agents = {}
        self.message_board = []

    def register_agent(self, role, agent_instance):
        self.agents[role] = agent_instance

    def post_message(self, sender, recipient, content, message_type="data"):
        entry = {
            "message_id": len(self.message_board) + 1,
            "sender": sender,
            "recipient": recipient,
            "type": message_type,
            "content": content
        }
        self.message_board.append(entry)
        return entry

    def get_messages_for(self, recipient):
        return [m for m in self.message_board if m["recipient"] in (recipient, "ALL")]
