#!/usr/bin/env python3
"""
08_Logic_Reasoning.py — Propositional Logic & Horn Clause Inference Algorithms
Covers:
  1. Truth Table Model Checking (TT-Entails) — AIMA Fig 7.10
  2. Conjunctive Normal Form (CNF) & Resolution Theorem Prover (PL-Resolution) — AIMA Fig 7.12
  3. Linear-Time Horn Clause Forward Chaining (PL-FC-Entails) — AIMA Fig 7.15
  4. Running Benchmarks: Wumpus World Safety Proof, Liars & Truth-Tellers, Medical Horn KB

Run directly:
  python 08_Logic_Reasoning.py
"""

from collections import defaultdict, deque
import itertools


# =============================================================================
# 1. Propositional Expressions & Parser
# =============================================================================

class Expr:
    """A logical proposition expression tree."""
    def __init__(self, op, *args):
        self.op = str(op)
        self.args = list(args)

    def __repr__(self):
        if not self.args:
            return self.op
        elif len(self.args) == 1 and self.op in ('~', '¬'):
            return f"¬{self.args[0]}"
        elif len(self.args) == 2 and not self.op.isalnum():
            op_sym = {'&': '∧', '|': '∨', '>>': '⇒', '<=>': '⇔'}.get(self.op, self.op)
            return f"({self.args[0]} {op_sym} {self.args[1]})"
        else:
            return f"{self.op}({', '.join(map(str, self.args))})"

    def __eq__(self, other):
        return isinstance(other, Expr) and self.op == other.op and self.args == other.args

    def __hash__(self):
        return hash((self.op, tuple(self.args)))

    def __invert__(self):
        return Expr('~', self)

    def __and__(self, other):
        return Expr('&', self, other)

    def __or__(self, other):
        return Expr('|', self, other)

    def __rshift__(self, other):
        return Expr('>>', self, other)


def expr(s):
    """Parse string expression into an Expr object."""
    if isinstance(s, Expr):
        return s
    s = s.strip()
    if not s:
        return None

    # Handle biconditional (<=> or ⇔)
    for bi in ('<=>', '⇔'):
        parts = _split_top_level(s, bi)
        if len(parts) == 2:
            return Expr('<=>', expr(parts[0]), expr(parts[1]))

    # Handle implication (>> or ==> or ⇒)
    for imp in ('>>', '==>', '⇒'):
        parts = _split_top_level(s, imp)
        if len(parts) == 2:
            return Expr('>>', expr(parts[0]), expr(parts[1]))

    # Handle OR (| or ∨)
    for or_op in ('|', '∨'):
        parts = _split_top_level(s, or_op)
        if len(parts) > 1:
            res = expr(parts[0])
            for p in parts[1:]:
                res = Expr('|', res, expr(p))
            return res

    # Handle AND (& or ∧)
    for and_op in ('&', '∧'):
        parts = _split_top_level(s, and_op)
        if len(parts) > 1:
            res = expr(parts[0])
            for p in parts[1:]:
                res = Expr('&', res, expr(p))
            return res

    # Handle NOT (~ or ¬)
    if s.startswith('~') or s.startswith('¬'):
        return Expr('~', expr(s[1:]))

    # Strip enclosing matching parentheses
    if s.startswith('(') and s.endswith(')'):
        if _is_enclosed(s):
            return expr(s[1:-1])

    return Expr(s)


def _is_enclosed(s):
    if not (s.startswith('(') and s.endswith(')')):
        return False
    depth = 0
    for i, c in enumerate(s):
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0 and i < len(s) - 1:
                return False
    return depth == 0


def _split_top_level(s, op):
    depth = 0
    op_len = len(op)
    i = 0
    while i <= len(s) - op_len:
        c = s[i]
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
        elif depth == 0 and s[i:i+op_len] == op:
            return [s[:i], s[i+op_len:]]
        i += 1
    return [s]


def prop_symbols(x):
    """Extract set of propositional variable symbols from expression."""
    if not isinstance(x, Expr):
        return set()
    if not x.args:
        return {x} if x.op not in ('True', 'False') else set()
    s = set()
    for arg in x.args:
        s.update(prop_symbols(arg))
    return s


def pl_true(exp, model):
    """Evaluate propositional sentence in a given boolean truth assignment model."""
    if exp in (True, 'True'):
        return True
    if exp in (False, 'False'):
        return False
    if not isinstance(exp, Expr):
        return exp

    op, args = exp.op, exp.args
    if not args:
        return model.get(exp, model.get(exp.op, False))
    elif op in ('~', '¬'):
        return not pl_true(args[0], model)
    elif op in ('&', '∧'):
        return pl_true(args[0], model) and pl_true(args[1], model)
    elif op in ('|', '∨'):
        return pl_true(args[0], model) or pl_true(args[1], model)
    elif op in ('>>', '⇒', '==>'):
        return (not pl_true(args[0], model)) or pl_true(args[1], model)
    elif op in ('<=>', '⇔'):
        return pl_true(args[0], model) == pl_true(args[1], model)
    else:
        raise ValueError(f"Unknown operator {op}")


# =============================================================================
# 2. Truth-Table Entailment (TT-Entails)
# =============================================================================

def tt_entails(kb, alpha, verbose=False):
    """
    Truth-Table Entailment algorithm (AIMA Fig 7.10).
    Checks if KB |= alpha by enumerating all 2^n models over symbols(KB) U symbols(alpha).
    """
    kb_expr = _combine_clauses(kb)
    alpha_expr = expr(alpha)
    symbols = sorted(list(prop_symbols(kb_expr) | prop_symbols(alpha_expr)), key=lambda x: x.op)
    
    table_rows = []
    models_checked = 0
    kb_true_models = 0
    
    def tt_check_all(kb_e, alpha_e, syms, model):
        nonlocal models_checked, kb_true_models
        if not syms:
            models_checked += 1
            kb_val = pl_true(kb_e, model)
            alpha_val = pl_true(alpha_e, model)
            if verbose:
                table_rows.append((dict(model), kb_val, alpha_val))
            if kb_val:
                kb_true_models += 1
                return alpha_val
            return True
        P = syms[0]
        rest = syms[1:]
        return (tt_check_all(kb_e, alpha_e, rest, {**model, P: True}) and
                tt_check_all(kb_e, alpha_e, rest, {**model, P: False}))

    entailed = tt_check_all(kb_expr, alpha_expr, symbols, {})
    
    if verbose:
        print(f"\n--- TT-Entails Table ({len(symbols)} symbols, {models_checked} models) ---")
        headers = [s.op for s in symbols] + ["KB", "Query (α)"]
        print(" | ".join(f"{h:>6}" for h in headers))
        print("-" * (len(headers) * 9))
        for row, kb_v, a_v in table_rows:
            vals = [str(row[s])[0] for s in symbols] + [str(kb_v)[0], str(a_v)[0]]
            marker = " ★ (KB is True)" if kb_v else ""
            print(" | ".join(f"{v:>6}" for v in vals) + marker)
        print(f"\nResult: Models checked = {models_checked}, Models where KB=True = {kb_true_models}")
        print(f"Entailment KB |= α : {entailed}\n")

    return entailed


def _combine_clauses(kb):
    if isinstance(kb, (list, tuple, set)):
        if not kb:
            return Expr('True')
        res = expr(kb[0])
        for c in kb[1:]:
            res = Expr('&', res, expr(c))
        return res
    return expr(kb)


# =============================================================================
# 3. CNF Conversion & Resolution Theorem Prover (PL-Resolution)
# =============================================================================

def to_cnf(s):
    """
    Convert a propositional logical sentence into Conjunctive Normal Form (CNF).
    Step 1: Eliminate <=>
    Step 2: Eliminate >>
    Step 3: Move ~ inwards (De Morgan & Double Negation)
    Step 4: Distribute | over &
    """
    s = expr(s)
    s = _eliminate_biconditionals(s)
    s = _eliminate_implications(s)
    s = _move_not_inwards(s)
    s = _distribute_and_over_or(s)
    return s


def _eliminate_biconditionals(s):
    if not isinstance(s, Expr) or not s.args:
        return s
    args = [_eliminate_biconditionals(a) for a in s.args]
    if s.op == '<=>':
        return Expr('&', Expr('>>', args[0], args[1]), Expr('>>', args[1], args[0]))
    return Expr(s.op, *args)


def _eliminate_implications(s):
    if not isinstance(s, Expr) or not s.args:
        return s
    args = [_eliminate_implications(a) for a in s.args]
    if s.op == '>>':
        return Expr('|', Expr('~', args[0]), args[1])
    return Expr(s.op, *args)


def _move_not_inwards(s):
    if not isinstance(s, Expr) or not s.args:
        return s
    if s.op == '~':
        a = s.args[0]
        if a.op == '~':
            return _move_not_inwards(a.args[0])
        elif a.op == '&':
            return Expr('|', _move_not_inwards(Expr('~', a.args[0])), _move_not_inwards(Expr('~', a.args[1])))
        elif a.op == '|':
            return Expr('&', _move_not_inwards(Expr('~', a.args[0])), _move_not_inwards(Expr('~', a.args[1])))
        else:
            return s
    return Expr(s.op, *[_move_not_inwards(a) for a in s.args])


def _distribute_and_over_or(s):
    if not isinstance(s, Expr) or not s.args:
        return s
    if s.op == '|':
        s = Expr('|', _distribute_and_over_or(s.args[0]), _distribute_and_over_or(s.args[1]))
        if s.args[0].op == '&':
            return Expr('&', _distribute_and_over_or(Expr('|', s.args[0].args[0], s.args[1])),
                             _distribute_and_over_or(Expr('|', s.args[0].args[1], s.args[1])))
        if s.args[1].op == '&':
            return Expr('&', _distribute_and_over_or(Expr('|', s.args[0], s.args[1].args[0])),
                             _distribute_and_over_or(Expr('|', s.args[0], s.args[1].args[1])))
    return Expr(s.op, *[_distribute_and_over_or(a) for a in s.args])


def _clause_to_literals(clause):
    """Extract set of literals (e.g. {P, ~Q}) from a disjunctive clause."""
    if clause.op == '|':
        return _clause_to_literals(clause.args[0]) | _clause_to_literals(clause.args[1])
    return {clause}


def _cnf_to_clause_set(cnf_expr):
    """Convert a CNF expression into a set of frozenset clauses."""
    def extract_conjunctions(e):
        if e.op == '&':
            return extract_conjunctions(e.args[0]) + extract_conjunctions(e.args[1])
        return [e]
    clauses = set()
    for conj in extract_conjunctions(cnf_expr):
        literals = _clause_to_literals(conj)
        clauses.add(frozenset(literals))
    return clauses


def pl_resolve(ci, cj):
    """
    Apply the propositional resolution rule to clauses ci and cj.
    Returns set of resolvent clauses.
    """
    resolvents = set()
    for di in ci:
        for dj in cj:
            # Check if complementary
            if (di.op == '~' and di.args[0] == dj) or (dj.op == '~' and dj.args[0] == di):
                new_clause = (ci - {di}) | (cj - {dj})
                # Check for tautology (e.g. P and ~P in same clause)
                has_tautology = any(Expr('~', lit) in new_clause for lit in new_clause if lit.op != '~')
                if not has_tautology:
                    resolvents.add(frozenset(new_clause))
    return resolvents


def pl_resolution(kb, alpha, verbose=False):
    """
    Propositional Resolution Refutation theorem prover (AIMA Fig 7.12).
    Proves KB |= alpha by refutation: (KB AND ~alpha) is unsatisfiable -> derives empty clause.
    """
    kb_expr = _combine_clauses(kb)
    alpha_expr = expr(alpha)
    combined = Expr('&', kb_expr, Expr('~', alpha_expr))
    
    clauses = _cnf_to_clause_set(to_cnf(combined))
    if verbose:
        print(f"\n--- Initial Clauses for PL-Resolution ({len(clauses)} clauses) ---")
        for i, c in enumerate(clauses):
            c_str = " ∨ ".join(map(str, c)) if c else "□ (Empty Clause)"
            print(f"  C{i+1}: {c_str}")

    new = set()
    step = 0
    while True:
        pairs = list(itertools.combinations(clauses, 2))
        for ci, cj in pairs:
            resolvents = pl_resolve(ci, cj)
            step += 1
            if frozenset() in resolvents:
                if verbose:
                    ci_s = " ∨ ".join(map(str, ci))
                    cj_s = " ∨ ".join(map(str, cj))
                    print(f"\nDerived empty clause □ from ({ci_s}) and ({cj_s}) at step {step}!")
                    print("Contradiction reached: KB |= α is TRUE.\n")
                return True
            new.update(resolvents)

        if new.issubset(clauses):
            if verbose:
                print("\nNo new clauses can be derived. KB does NOT entail α.\n")
            return False

        clauses.update(new)


# =============================================================================
# 4. Horn Clause Forward Chaining (PL-FC-Entails)
# =============================================================================

class HornClause:
    """Represents a definite Horn clause: (P1 & P2 & ... & Pk) >> Q."""
    def __init__(self, premises, conclusion):
        self.premises = [expr(p) for p in premises]
        self.conclusion = expr(conclusion)

    def __repr__(self):
        if not self.premises:
            return str(self.conclusion)
        return f"({' ∧ '.join(map(str, self.premises))} ⇒ {self.conclusion})"


def pl_fc_entails(horn_clauses, facts, query, verbose=False):
    """
    Linear-time propositional Forward Chaining algorithm (AIMA Fig 7.15).
    horn_clauses: list of HornClause objects
    facts: list of initial atomic true symbols
    query: target proposition symbol
    """
    query = expr(query)
    count = {c: len(c.premises) for c in horn_clauses}
    inferred = defaultdict(bool)
    for f in facts:
        inferred[expr(f)] = True

    agenda = deque([expr(f) for f in facts])
    derivation_trace = []

    if verbose:
        print(f"\n--- PL-FC-Entails (Linear Forward Chaining) ---")
        print(f"Known Facts: {[str(f) for f in facts]}")
        print(f"Rules: {[str(c) for c in horn_clauses]}")
        print(f"Target Query: {query}")

    step = 0
    while agenda:
        p = agenda.popleft()
        step += 1
        if p == query:
            if verbose:
                print(f"\n[Step {step}] Reached goal query {query}! Entailment holds.")
            return True, derivation_trace

        for c in horn_clauses:
            if p in c.premises:
                count[c] -= 1
                if count[c] == 0:
                    if not inferred[c.conclusion]:
                        inferred[c.conclusion] = True
                        agenda.append(c.conclusion)
                        derivation_trace.append((c, c.conclusion))
                        if verbose:
                            print(f"[Step {step}] Rule fired: {c} -> Inferred: {c.conclusion}")

    if verbose:
        print(f"\nAgenda empty without deriving {query}. Query is NOT entailed.")
    return False, derivation_trace


# =============================================================================
# 5. Benchmarks & Validation Test Suite
# =============================================================================

def run_wumpus_benchmark():
    print("\n" + "="*70)
    print("BENCHMARK 1: Wumpus World Propositional Safety Deduction")
    print("="*70)
    # 2-room physics:
    # 1. No pit in [1,1]: ~P11
    # 2. Breeze in [1,1] <=> (Pit in [1,2] or Pit in [2,1]): B11 <=> (P12 | P21)
    # 3. Observed percept at [1,1]: ~B11 (No breeze)
    wumpus_kb = [
        expr('~P11'),
        expr('B11 <=> (P12 | P21)'),
        expr('~B11')
    ]
    
    query = expr('~P12')
    print("KB Sentences:")
    for s in wumpus_kb:
        print(f"  • {s}")
    print(f"Query: {query} (Is [1,2] guaranteed pit-free?)")

    print("\n--- 1. Testing via TT-Entails (Model Checking) ---")
    tt_res = tt_entails(wumpus_kb, query, verbose=True)
    assert tt_res is True

    print("\n--- 2. Testing via PL-Resolution (Proof by Refutation) ---")
    res_res = pl_resolution(wumpus_kb, query, verbose=True)
    assert res_res is True
    print("✓ Wumpus World safety deduction verified successfully!")


def run_liars_and_truth_tellers():
    print("\n" + "="*70)
    print("BENCHMARK 2: Russell & Norvig Liars & Truth-Tellers Puzzle (AIMA Ex 7.2)")
    print("="*70)
    # Amy says: "I am a knave (liar) or Bob is a knight (truth-teller)"
    # A <=> (~A | B)
    puzzle_kb = [
        expr('A <=> (~A | B)')
    ]
    print("Puzzle KB:")
    for s in puzzle_kb:
        print(f"  • {s}")

    prove_A = tt_entails(puzzle_kb, expr('A'), verbose=False)
    prove_B = tt_entails(puzzle_kb, expr('B'), verbose=False)
    print(f"Result: Proved Amy is Truth-Teller (A): {prove_A}")
    print(f"Result: Proved Bob is Truth-Teller (B): {prove_B}")
    assert prove_A is True and prove_B is True
    print("✓ Liars & Truth-tellers puzzle solved!")


def run_medical_horn_benchmark():
    print("\n" + "="*70)
    print("BENCHMARK 3: Medical Diagnostic Forward Chaining (Horn KB)")
    print("="*70)
    # Facts: Patient has Fever and Cough
    # Rules:
    #   Fever & Cough => RespiratoryInfection
    #   RespiratoryInfection & SoreThroat => Flu
    #   Fever => ElevatedTemp
    #   RespiratoryInfection => PrescribeRest
    facts = ['Fever', 'Cough']
    rules = [
        HornClause(['Fever', 'Cough'], 'RespiratoryInfection'),
        HornClause(['RespiratoryInfection', 'SoreThroat'], 'Flu'),
        HornClause(['Fever'], 'ElevatedTemp'),
        HornClause(['RespiratoryInfection'], 'PrescribeRest'),
    ]

    entailed, trace = pl_fc_entails(rules, facts, 'PrescribeRest', verbose=True)
    assert entailed is True
    print("✓ Horn Clause Forward Chaining verified successfully!")


if __name__ == '__main__':
    run_wumpus_benchmark()
    run_liars_and_truth_tellers()
    run_medical_horn_benchmark()
    print("\n" + "="*70)
    print("ALL LOGIC REASONING TESTS PASSED PERFECTLY!")
    print("="*70)
