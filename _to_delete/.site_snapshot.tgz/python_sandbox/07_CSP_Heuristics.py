"""
07_CSP_Heuristics.py -- Backtracking, heuristics, inference and local search
for CSPs (AIMA 4th ed., Chapter 6), on the running example of Topic 04:
colouring the map of Australia with {red, green, blue}.

Every function below is the code traced line by line on
csp.html#code (Code Trace topic):

    backtracking_search          basic recursive backtracking
    mrv (+ degree tie-breaker)   variable ordering
    lcv                          value ordering
    forward_checking, ac3/revise inference & constraint propagation
    backtracking_search_heuristics
    min_conflicts                local search
    measure / compare            nodes visited, backtracks, elapsed time

Run:  python 07_CSP_Heuristics.py
"""

import random
import time


# =============================================================================
# The CSP: variables, domains, neighbours, binary constraint
# =============================================================================

class CSP:
    def __init__(self, variables, domains, neighbors, constraints):
        self.variables = list(variables)
        self.domains = {v: list(domains[v]) for v in variables}
        self.neighbors = neighbors
        self.constraints = constraints # constraints(A, a, B, b) -> bool
        self.nodes_expanded = 0
        self.backtracks = 0

    def is_consistent(self, var, val, assignment):
        return all(self.constraints(var, val, n, assignment[n])
                   for n in self.neighbors[var] if n in assignment)

    def nconflicts(self, var, val, assignment):
        return sum(1 for n in self.neighbors[var]
                   if n in assignment and not self.constraints(var, val, n, assignment[n]))

    def assign(self, var, val, assignment):
        assignment[var] = val

    def unassign(self, var, assignment):
        if var in assignment:
            del assignment[var]

    def prune(self, var, val, removals):
        self.domains[var].remove(val)
        if removals is not None:
            removals.append((var, val))

    def restore(self, removals):
        for var, val in removals:
            self.domains[var].append(val)


def different_values(A, a, B, b):
    return a != b


def australia(order=None):
    neighbors = {
        "WA": ["NT", "SA"], "NT": ["WA", "SA", "Q"],
        "SA": ["WA", "NT", "Q", "NSW", "V"], "Q": ["NT", "SA", "NSW"],
        "NSW": ["Q", "SA", "V"], "V": ["SA", "NSW"], "T": [],
    }
    variables = order or ["WA", "NT", "Q", "NSW", "V", "SA", "T"]
    colors = ["red", "green", "blue"]
    return CSP(variables, {v: colors for v in variables}, neighbors, different_values)


def n_queens(n):
    variables = [f"Q{c}" for c in range(n)]
    col = {v: c for c, v in enumerate(variables)}
    neighbors = {v: [u for u in variables if u != v] for v in variables}

    def queens_constraint(A, a, B, b):
        return a != b and abs(a - b) != abs(col[A] - col[B])

    return CSP(variables, {v: list(range(n)) for v in variables}, neighbors, queens_constraint)


# =============================================================================
# 1. Basic recursive backtracking
# =============================================================================

def first_unassigned_variable(assignment, csp):
    for var in csp.variables:
        if var not in assignment:
            return var
    return None


def unordered_domain_values(var, assignment, csp):
    return list(csp.domains[var])


def backtracking_search(csp, select_unassigned_variable=first_unassigned_variable,
                        order_domain_values=unordered_domain_values):
    csp.nodes_expanded = 0
    csp.backtracks = 0

    def backtrack(assignment):
        csp.nodes_expanded += 1
        if len(assignment) == len(csp.variables):
            return assignment

        var = select_unassigned_variable(assignment, csp)
        for val in order_domain_values(var, assignment, csp):
            if csp.is_consistent(var, val, assignment):
                csp.assign(var, val, assignment)
                result = backtrack(assignment)
                if result is not None:
                    return result
                csp.unassign(var, assignment)
                csp.backtracks += 1

        return None

    return backtrack({})


# =============================================================================
# 2. Variable ordering: MRV with the Degree heuristic as tie-breaker
# =============================================================================

def mrv(assignment, csp):
    unassigned = [v for v in csp.variables if v not in assignment]
    if not unassigned:
        return None

    def legal(var):
        return sum(1 for val in csp.domains[var]
                   if csp.is_consistent(var, val, assignment))

    min_size = min(legal(v) for v in unassigned)
    candidates = [v for v in unassigned if legal(v) == min_size]
    if len(candidates) == 1:
        return candidates[0]

    # Degree heuristic tie-breaker
    def degree(var):
        return sum(1 for n in csp.neighbors[var] if n not in assignment)

    return max(candidates, key=degree)


# =============================================================================
# 3. Value ordering: Least Constraining Value
# =============================================================================

def lcv(var, assignment, csp):
    def ruled_out(val):
        count = 0
        for n in csp.neighbors[var]:
            if n not in assignment:
                for y in csp.domains[n]:
                    if not csp.constraints(var, val, n, y):
                        count += 1
        return count

    return sorted(csp.domains[var], key=ruled_out)


# =============================================================================
# 4. Inference: Forward Checking and AC-3 (MAC)
# =============================================================================

def no_inference(csp, var, value, assignment, removals):
    return True


def forward_checking(csp, var, value, assignment, removals):
    for n in csp.neighbors[var]:
        if n not in assignment:
            for y in list(csp.domains[n]):
                if not csp.constraints(var, value, n, y):
                    csp.prune(n, y, removals)
            if not csp.domains[n]:
                return False
    return True


def ac3(csp, queue=None, removals=None):
    if queue is None:
        queue = [(Xi, Xk) for Xi in csp.variables for Xk in csp.neighbors[Xi]]

    while queue:
        Xi, Xj = queue.pop(0)
        if revise(csp, Xi, Xj, removals):
            if not csp.domains[Xi]:
                return False
            for Xk in csp.neighbors[Xi]:
                if Xk != Xj:
                    queue.append((Xk, Xi))
    return True


def revise(csp, Xi, Xj, removals=None):
    revised = False
    for x in list(csp.domains[Xi]):
        if not any(csp.constraints(Xi, x, Xj, y) for y in csp.domains[Xj]):
            csp.prune(Xi, x, removals)
            revised = True
    return revised


def mac(csp, var, value, assignment, removals):
    """Maintaining Arc Consistency: fix var = value, then AC-3 on arcs into var."""
    for x in list(csp.domains[var]):
        if x != value:
            csp.prune(var, x, removals)
    return ac3(csp, [(n, var) for n in csp.neighbors[var] if n not in assignment], removals)


def backtracking_search_heuristics(csp, select_unassigned_variable=mrv,
                                   order_domain_values=lcv,
                                   inference=forward_checking):
    csp.nodes_expanded = 0
    csp.backtracks = 0

    def backtrack(assignment):
        csp.nodes_expanded += 1
        if len(assignment) == len(csp.variables):
            return assignment

        var = select_unassigned_variable(assignment, csp)
        for val in order_domain_values(var, assignment, csp):
            if csp.is_consistent(var, val, assignment):
                csp.assign(var, val, assignment)
                removals = []
                if inference(csp, var, val, assignment, removals):
                    result = backtrack(assignment)
                    if result is not None:
                        return result
                csp.restore(removals)
                csp.unassign(var, assignment)
                csp.backtracks += 1

        return None

    return backtrack({})


# =============================================================================
# 5. Local search: Min-Conflicts
# =============================================================================

def min_conflicts(csp, max_steps=1000):
    csp.nodes_expanded = 0
    current = {}
    for var in csp.variables:  # greedy complete assignment
        counts = {val: csp.nconflicts(var, val, current) for val in csp.domains[var]}
        fewest = min(counts.values())
        current[var] = random.choice([val for val in counts if counts[val] == fewest])

    for step in range(max_steps):
        csp.nodes_expanded += 1
        conflicted = [var for var in csp.variables
                      if csp.nconflicts(var, current[var], current) > 0]
        if not conflicted:
            return current

        var = random.choice(conflicted)
        min_conf = float("inf")
        best_vals = []
        for val in csp.domains[var]:
            conf = csp.nconflicts(var, val, current)
            if conf < min_conf:
                min_conf = conf
                best_vals = [val]
            elif conf == min_conf:
                best_vals.append(val)

        current[var] = random.choice(best_vals)

    return None


# =============================================================================
# 6. Measuring search efficiency
# =============================================================================

def measure(solver, csp):
    csp.nodes_expanded = 0
    csp.backtracks = 0
    start = time.perf_counter()
    result = solver(csp)
    elapsed = (time.perf_counter() - start) * 1000
    return result, csp.nodes_expanded, csp.backtracks, elapsed


SOLVERS = {
    "Backtracking": backtracking_search,
    "BT + MRV/Degree + LCV + FC": lambda c: backtracking_search_heuristics(
        c, mrv, lcv, forward_checking),
    "BT + MRV/Degree + LCV + MAC": lambda c: backtracking_search_heuristics(
        c, mrv, lcv, mac),
    "Min-Conflicts": lambda c: min_conflicts(c, max_steps=10000),
}


def compare(name, make_problem):
    print(f"\n{name}")
    print(f"{'solver':30} {'solved':>6} {'nodes':>8} {'backtracks':>10} {'time (ms)':>10}")
    for label, solver in SOLVERS.items():
        result, nodes, bts, ms = measure(solver, make_problem())
        bts_txt = "-" if label == "Min-Conflicts" else bts
        print(f"{label:30} {str(result is not None):>6} {nodes:>8} {bts_txt:>10} {ms:>10.2f}")


if __name__ == "__main__":
    random.seed(4)
    print("Basic backtracking on Australia:", backtracking_search(australia()))
    print("Heuristic backtracking (MRV/Degree + LCV + FC):",
          backtracking_search_heuristics(australia()))
    compare("Australia (7 regions, 3 colours)", australia)
    compare("Australia, order WA, NSW, NT, Q, SA, V, T",
            lambda: australia(["WA", "NSW", "NT", "Q", "SA", "V", "T"]))
    compare("8-Queens", lambda: n_queens(8))
    compare("20-Queens", lambda: n_queens(20))
