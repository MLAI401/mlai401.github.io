"""
03_UCS.py -- Uniform-Cost Search

Frontier = priority queue ordered by g(n), the accumulated path cost from the
start (NOT by insertion order -- that's what separates UCS from BFS).

Reference: aima-python's uniform_cost_search / best_first_graph_search
(https://github.com/aimacode/aima-python/blob/master/search.py), reimplemented
here from scratch against the shared GraphProblem in graph_problem.py.

Teaching points from instructions/search.md:
  - "UCS Cost Updates": when a cheaper path to a state already in `reached`
    is found, its cost (and frontier entry) is updated rather than ignored.
  - "UCS Goal Test": the goal is NOT accepted the moment it is generated --
    only once it is SELECTED as the minimum-cost node from the frontier,
    since a cheaper path to it may still be discovered first.

    Frontier -> Select (lowest g) -> Goal Test -> Expand -> Update Frontier/Reached

Run:
    python 03_UCS.py
"""

import heapq
import itertools

from graph_problem import GraphProblem, Node, expand, print_result


def uniform_cost_search(problem: GraphProblem):
    counter = itertools.count()  # tie-breaker so heapq never compares Node objects
    root = Node(problem.initial)

    frontier = [(root.path_cost, next(counter), root)]  # priority queue by g(n)
    reached = {root.state: root.path_cost}  # state -> best g(n) found so far
    expanded_order = []

    while frontier:
        cost, _, node = heapq.heappop(frontier)  # SELECT: lowest g(n)
        if cost > reached.get(node.state, float("inf")):
            continue  # stale entry (a cheaper one already replaced it), skip

        if problem.goal_test(node.state):  # GOAL TEST only on selection
            return node, expanded_order

        expanded_order.append(node.state)  # EXPAND
        print(f"Select {node.state:<2} g(n)={node.path_cost:<3} | frontier={sorted((s, round(c)) for c, _, n in frontier for s in [n.state])}")

        for child in expand(problem, node):
            best_known = reached.get(child.state)
            if best_known is None or child.path_cost < best_known:
                if best_known is not None:
                    print(f"  {child.state}: existing cost {best_known} -> new cost {child.path_cost} -> UPDATE")
                else:
                    print(f"  {child.state}: new, cost {child.path_cost}")
                reached[child.state] = child.path_cost
                heapq.heappush(frontier, (child.path_cost, next(counter), child))
            else:
                print(f"  {child.state}: existing cost {best_known} <= new cost {child.path_cost} -> IGNORE")

    return None, expanded_order


if __name__ == "__main__":
    problem = GraphProblem()
    goal_node, expanded = uniform_cost_search(problem)
    print_result(problem, goal_node, expanded, "UCS (Uniform-Cost Search)")
