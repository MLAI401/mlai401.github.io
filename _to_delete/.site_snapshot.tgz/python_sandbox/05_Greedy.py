"""
05_Greedy.py -- Greedy Best-First Search

Frontier = priority queue ordered by h(n) only (the heuristic estimate to the
goal) -- unlike UCS, the accumulated path cost g(n) plays no role in
ordering, which is why Greedy can be fast but is neither optimal nor complete
in general.

Reference: aima-python's greedy_best_first_graph_search
(https://github.com/aimacode/aima-python/blob/master/search.py), reimplemented
here from scratch against the shared GraphProblem in graph_problem.py.

    Frontier (ordered by h(n)) -> Select -> Goal Test -> Expand -> Update Frontier

Run:
    python 05_Greedy.py
"""

import heapq
import itertools

from graph_problem import GraphProblem, Node, expand, print_result


def greedy_best_first_search(problem: GraphProblem):
    counter = itertools.count()
    root = Node(problem.initial)

    frontier = [(problem.h(root.state), next(counter), root)]  # priority queue by h(n)
    reached = {root.state}
    expanded_order = []

    while frontier:
        h_val, _, node = heapq.heappop(frontier)  # SELECT: lowest h(n)

        if problem.goal_test(node.state):  # GOAL TEST on selection
            return node, expanded_order

        expanded_order.append(node.state)  # EXPAND
        print(f"Select {node.state:<2} h(n)={h_val:<3} | frontier={sorted((n.state, problem.h(n.state)) for _, _, n in frontier)}")

        for child in expand(problem, node):
            if child.state in reached:
                print(f"  generate {child.state} -> already reached, skip")
                continue
            reached.add(child.state)
            child_h = problem.h(child.state)
            print(f"  generate {child.state}, h(n)={child_h}")
            heapq.heappush(frontier, (child_h, next(counter), child))

    return None, expanded_order


if __name__ == "__main__":
    problem = GraphProblem()
    goal_node, expanded = greedy_best_first_search(problem)
    print_result(problem, goal_node, expanded, "Greedy Best-First Search")
