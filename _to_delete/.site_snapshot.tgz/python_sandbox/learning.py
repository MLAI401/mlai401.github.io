"""
MLAI401 — Topic 06: Learning & Decision Making Reference Module
Clean reusable classes for Machine Learning, Neural Networks, and Reinforcement Learning:
- Dataset container
- TextCorpus, TFIDFVectorizer, NaiveBayesClassifier
- Perceptron
- KMeans
- MDP & GridWorldMDP
- QLearner
"""

import math
import random
import re
from collections import defaultdict, Counter


def tokenize(text):
    """Splits raw text into lowercase word tokens, removing punctuation."""
    if not text:
        return []
    text = re.sub(r'[^\w\s]', ' ', text.lower())
    return [w for w in text.split() if len(w) > 1]


class TextCorpus:
    """Text corpus for vocabulary construction and document frequencies."""
    def __init__(self, documents):
        self.documents = list(documents)
        self.tokenized_docs = [tokenize(d) for d in self.documents]
        self.vocabulary = sorted(list(set(w for doc in self.tokenized_docs for w in doc)))
        self.vocab_index = {w: idx for idx, w in enumerate(self.vocabulary)}
        self.doc_frequencies = self._compute_df()

    def _compute_df(self):
        df = {w: 0 for w in self.vocabulary}
        for doc in self.tokenized_docs:
            for w in set(doc):
                df[w] += 1
        return df

    def get_bow(self, doc):
        tokens = tokenize(doc) if isinstance(doc, str) else doc
        counts = Counter(tokens)
        return {w: counts.get(w, 0) for w in self.vocabulary}

    def get_tfidf(self, doc):
        tokens = tokenize(doc) if isinstance(doc, str) else doc
        tf = Counter(tokens)
        n = len(self.documents)
        total = len(tokens) or 1
        tfidf = {}
        for w in self.vocabulary:
            tf_norm = tf.get(w, 0) / total
            df = self.doc_frequencies.get(w, 0)
            idf = math.log((n + 1) / (df + 1)) + 1.0
            tfidf[w] = tf_norm * idf
        return tfidf


class NaiveBayesClassifier:
    """Multinomial Naive Bayes classifier with Laplace Add-1 smoothing."""
    def __init__(self, alpha=1.0):
        self.alpha = alpha
        self.classes = []
        self.priors = {}
        self.word_counts = {}
        self.total_words = {}
        self.vocabulary = set()

    def fit(self, docs, labels):
        self.classes = sorted(list(set(labels)))
        n_docs = len(docs)
        self.priors = {c: labels.count(c) / n_docs for c in self.classes}
        self.word_counts = {c: defaultdict(int) for c in self.classes}
        self.total_words = {c: 0 for c in self.classes}
        self.vocabulary = set()

        for doc, c in zip(docs, labels):
            tokens = tokenize(doc)
            for w in tokens:
                self.vocabulary.add(w)
                self.word_counts[c][w] += 1
                self.total_words[c] += 1

    def predict(self, doc):
        tokens = tokenize(doc)
        v_size = len(self.vocabulary)
        scores = {}
        for c in self.classes:
            log_prob = math.log(self.priors[c])
            for w in tokens:
                count = self.word_counts[c].get(w, 0)
                prob = (count + self.alpha) / (self.total_words[c] + self.alpha * v_size)
                log_prob += math.log(prob)
            scores[c] = log_prob
        return max(scores, key=scores.get)


class Perceptron:
    """Single artificial perceptron with step activation function."""
    def __init__(self, n_features=2, learning_rate=0.1):
        self.weights = [0.0] * n_features
        self.bias = 0.0
        self.lr = learning_rate

    def forward(self, x):
        z = sum(self.weights[i] * x[i] for i in range(len(self.weights))) + self.bias
        return 1 if z >= 0 else 0

    def fit_step(self, x, y):
        y_hat = self.forward(x)
        error = y - y_hat
        for i in range(len(self.weights)):
            self.weights[i] += self.lr * error * x[i]
        self.bias += self.lr * error
        return error


class KMeans:
    """K-Means clustering with Lloyd's algorithm."""
    def __init__(self, k=3, max_iters=30):
        self.k = k
        self.max_iters = max_iters
        self.centroids = []

    def fit(self, points):
        self.centroids = [list(p) for p in points[:self.k]]
        for _ in range(self.max_iters):
            clusters = defaultdict(list)
            for p in points:
                best_k = min(
                    range(self.k),
                    key=lambda k: sum((p[d] - self.centroids[k][d])**2 for d in range(len(p)))
                )
                clusters[best_k].append(p)

            new_centroids = []
            for k in range(self.k):
                if clusters[k]:
                    mean_p = [sum(p[d] for p in clusters[k]) / len(clusters[k]) for d in range(len(points[0]))]
                    new_centroids.append(mean_p)
                else:
                    new_centroids.append(self.centroids[k])
            self.centroids = new_centroids
        return self.centroids


class MDP:
    """Markov Decision Process: <S, A, P, R, gamma>."""
    def __init__(self, states, actions, transitions, rewards, gamma=0.99):
        self.states = states
        self.actions = actions
        self.transitions = transitions
        self.rewards = rewards
        self.gamma = gamma
