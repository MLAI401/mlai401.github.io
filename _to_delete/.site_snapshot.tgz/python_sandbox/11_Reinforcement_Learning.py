#!/usr/bin/env python3
"""
MLAI401 — Topic 06: Reinforcement Learning & Sequential Decision Making
Standalone zero-dependency Python implementation of foundational RL algorithms:
- Markov Decision Process (MDP) and GridWorld environment formulation
- Dynamic Programming: Value Iteration & Policy Iteration (Model-Based)
- Model-Free Reinforcement Learning: Tabular Q-Learning (Off-Policy TD Control)
- Model-Free Reinforcement Learning: SARSA (On-Policy TD Control)
- Cliff Walking safety comparison (Q-Learning vs SARSA)

Can be run directly: python 11_Reinforcement_Learning.py
"""

import math
import random


# ==============================================================================
# 1. GridWorld Environment (MDP Formulation)
# ==============================================================================

class GridWorld:
    """
    Classic AIMA 4x3 Grid World MDP.
    Grid coordinates: (col, row) where col in 1..4 (x), row in 1..3 (y).
    States: (x, y)
    Actions: 'N', 'S', 'E', 'W' (Up, Down, Right, Left)
    Dynamics: 0.8 intended direction, 0.1 veer left, 0.1 veer right.
    """
    def __init__(self, cols=4, rows=3, terminals=None, walls=None, living_reward=-0.04, slip_prob=0.2):
        self.cols = cols
        self.rows = rows
        # Terminal states with scalar rewards: {(4, 3): +1.0, (4, 2): -1.0}
        self.terminals = terminals if terminals is not None else {(4, 3): 1.0, (4, 2): -1.0}
        # Impassable wall obstacles: {(2, 2)}
        self.walls = walls if walls is not None else {(2, 2)}
        self.living_reward = living_reward
        self.slip_prob = slip_prob
        self.actions = ['N', 'S', 'E', 'W']

        # Precompute valid state space
        self.states = []
        for r in range(1, self.rows + 1):
            for c in range(1, self.cols + 1):
                if (c, r) not in self.walls:
                    self.states.append((c, r))

    def is_terminal(self, state):
        return state in self.terminals

    def get_reward(self, state):
        if state in self.terminals:
            return self.terminals[state]
        return self.living_reward

    def _move(self, state, action):
        if self.is_terminal(state):
            return state
        c, r = state
        if action == 'N':
            next_state = (c, r + 1)
        elif action == 'S':
            next_state = (c, r - 1)
        elif action == 'E':
            next_state = (c + 1, r)
        elif action == 'W':
            next_state = (c - 1, r)
        else:
            next_state = state

        # Check bounds and wall collisions
        nc, nr = next_state
        if nc < 1 or nc > self.cols or nr < 1 or nr > self.rows or next_state in self.walls:
            return state
        return next_state

    def get_transitions(self, state, action):
        """
        Returns list of tuples: (probability, next_state, reward)
        P(s' | s, a)
        """
        if self.is_terminal(state):
            return [(1.0, state, 0.0)]

        # Determine slip outcomes
        perp_actions = {
            'N': ['W', 'E'],
            'S': ['W', 'E'],
            'E': ['N', 'S'],
            'W': ['N', 'S']
        }
        main_prob = 1.0 - self.slip_prob
        side_prob = self.slip_prob / 2.0

        outcomes = {}
        # Main intended action
        s_main = self._move(state, action)
        outcomes[s_main] = outcomes.get(s_main, 0.0) + main_prob

        # Slip actions
        for slip_a in perp_actions[action]:
            s_slip = self._move(state, slip_a)
            outcomes[s_slip] = outcomes.get(s_slip, 0.0) + side_prob

        results = []
        for next_s, prob in outcomes.items():
            reward = self.get_reward(next_s) if next_s in self.terminals else self.living_reward
            results.append((prob, next_s, reward))
        return results

    def step(self, state, action):
        """Executes a stochastic step in the environment."""
        if self.is_terminal(state):
            return state, 0.0, True
        trans = self.get_transitions(state, action)
        r = random.random()
        cum = 0.0
        for prob, next_s, reward in trans:
            cum += prob
            if cum >= r:
                return next_s, reward, self.is_terminal(next_s)
        return trans[-1][1], trans[-1][2], self.is_terminal(trans[-1][1])


# ==============================================================================
# 2. Dynamic Programming: Value Iteration & Policy Iteration
# ==============================================================================

def value_iteration(env, gamma=0.99, epsilon=1e-4, max_iter=500):
    """
    Computes optimal state values V*(s) using Bellman Optimality updates:
    V_{k+1}(s) = max_a sum_{s'} P(s'|s,a) [ R(s,a,s') + gamma * V_k(s') ]
    """
    V = {s: 0.0 for s in env.states}
    # Initialize terminal state values to their respective rewards
    for s in env.states:
        if env.is_terminal(s):
            V[s] = env.terminals[s]

    for it in range(max_iter):
        delta = 0.0
        new_V = V.copy()

        for s in env.states:
            if env.is_terminal(s):
                continue
            
            # Bellman Optimality Equation over available actions
            best_val = float('-inf')
            for a in env.actions:
                q_sa = 0.0
                for prob, s_prime, reward in env.get_transitions(s, a):
                    q_sa += prob * (reward + gamma * V[s_prime])
                if q_sa > best_val:
                    best_val = q_sa

            new_V[s] = best_val
            delta = max(delta, abs(new_V[s] - V[s]))

        V = new_V
        if delta < epsilon * (1.0 - gamma) / gamma if gamma < 1.0 else delta < epsilon:
            break

    # Policy Extraction: pi*(s) = argmax_a Q*(s, a)
    policy = {}
    for s in env.states:
        if env.is_terminal(s):
            policy[s] = None
            continue
        best_a = None
        best_q = float('-inf')
        for a in env.actions:
            q_sa = sum(prob * (reward + gamma * V[s_prime]) for prob, s_prime, reward in env.get_transitions(s, a))
            if q_sa > best_q:
                best_q = q_sa
                best_a = a
        policy[s] = best_a

    return V, policy


def policy_iteration(env, gamma=0.99, max_iter=100):
    """
    Alternates between Policy Evaluation and Policy Improvement until policy stability.
    """
    # Initialize arbitrary policy
    policy = {s: env.actions[0] if not env.is_terminal(s) else None for s in env.states}
    V = {s: 0.0 for s in env.states}
    for s in env.states:
        if env.is_terminal(s):
            V[s] = env.terminals[s]

    for it in range(max_iter):
        # 1. Policy Evaluation
        while True:
            delta = 0.0
            new_V = V.copy()
            for s in env.states:
                if env.is_terminal(s):
                    continue
                a = policy[s]
                v_s = sum(prob * (reward + gamma * V[s_prime]) for prob, s_prime, reward in env.get_transitions(s, a))
                new_V[s] = v_s
                delta = max(delta, abs(new_V[s] - V[s]))
            V = new_V
            if delta < 1e-4:
                break

        # 2. Policy Improvement
        policy_stable = True
        for s in env.states:
            if env.is_terminal(s):
                continue
            old_a = policy[s]
            best_a = None
            best_q = float('-inf')
            for a in env.actions:
                q_sa = sum(prob * (reward + gamma * V[s_prime]) for prob, s_prime, reward in env.get_transitions(s, a))
                if q_sa > best_q:
                    best_q = q_sa
                    best_a = a
            if best_a != old_a:
                policy_stable = False
            policy[s] = best_a

        if policy_stable:
            break

    return V, policy


# ==============================================================================
# 3. Model-Free Reinforcement Learning: Q-Learning & SARSA
# ==============================================================================

class QLearningAgent:
    """
    Tabular Q-Learning (Off-Policy TD Control):
    Q(s, a) <- Q(s, a) + alpha * [ r + gamma * max_a' Q(s', a') - Q(s, a) ]
    """
    def __init__(self, env, alpha=0.1, gamma=0.99, epsilon=0.2):
        self.env = env
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.q_table = {}
        for s in env.states:
            self.q_table[s] = {a: 0.0 for a in env.actions}

    def choose_action(self, state):
        if self.env.is_terminal(state):
            return None
        # epsilon-greedy exploration
        if random.random() < self.epsilon:
            return random.choice(self.env.actions)
        else:
            # Greedy action
            best_a = max(self.q_table[state].items(), key=lambda item: item[1])[0]
            return best_a

    def update(self, state, action, reward, next_state, done):
        curr_q = self.q_table[state][action]
        if done:
            td_target = reward
        else:
            max_next_q = max(self.q_table[next_state].values())
            td_target = reward + self.gamma * max_next_q
        td_error = td_target - curr_q
        self.q_table[state][action] += self.alpha * td_error

    def train(self, episodes=1000, max_steps=100, start_state=(1, 1)):
        for ep in range(episodes):
            s = start_state
            for step in range(max_steps):
                a = self.choose_action(s)
                if a is None:
                    break
                next_s, r, done = self.env.step(s, a)
                self.update(s, a, r, next_s, done)
                s = next_s
                if done:
                    break

    def extract_policy(self):
        policy = {}
        for s in self.env.states:
            if self.env.is_terminal(s):
                policy[s] = None
            else:
                policy[s] = max(self.q_table[s].items(), key=lambda item: item[1])[0]
        return policy


class SARSAAgent:
    """
    Tabular SARSA (On-Policy TD Control):
    Q(s, a) <- Q(s, a) + alpha * [ r + gamma * Q(s', a') - Q(s, a) ]
    """
    def __init__(self, env, alpha=0.1, gamma=0.99, epsilon=0.2):
        self.env = env
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.q_table = {}
        for s in env.states:
            self.q_table[s] = {a: 0.0 for a in env.actions}

    def choose_action(self, state):
        if self.env.is_terminal(state):
            return None
        if random.random() < self.epsilon:
            return random.choice(self.env.actions)
        else:
            return max(self.q_table[state].items(), key=lambda item: item[1])[0]

    def update(self, state, action, reward, next_state, next_action, done):
        curr_q = self.q_table[state][action]
        if done or next_action is None:
            td_target = reward
        else:
            next_q = self.q_table[next_state][next_action]
            td_target = reward + self.gamma * next_q
        td_error = td_target - curr_q
        self.q_table[state][action] += self.alpha * td_error

    def train(self, episodes=1000, max_steps=100, start_state=(1, 1)):
        for ep in range(episodes):
            s = start_state
            a = self.choose_action(s)
            for step in range(max_steps):
                if a is None:
                    break
                next_s, r, done = self.env.step(s, a)
                next_a = self.choose_action(next_s) if not done else None
                self.update(s, a, r, next_s, next_a, done)
                s = next_s
                a = next_a
                if done:
                    break


# ==============================================================================
# 4. Standalone Execution & Verification
# ==============================================================================

def print_grid_values(V, policy, env):
    arrows = {'N': '^', 'S': 'v', 'E': '>', 'W': '<', None: '.'}
    for r in range(env.rows, 0, -1):
        row_str = " | "
        for c in range(1, env.cols + 1):
            s = (c, r)
            if s in env.walls:
                row_str += "  WALL  | "
            elif env.is_terminal(s):
                row_str += f"{env.terminals[s]:+6.2f} | "
            else:
                act = arrows.get(policy.get(s), '?')
                val = V.get(s, 0.0)
                row_str += f"{val:5.2f}{act} | "
        print(row_str)


if __name__ == "__main__":
    print("=" * 65)
    print(" MLAI401 — Topic 06: Reinforcement Learning Verification")
    print("=" * 65)

    env = GridWorld(living_reward=-0.04, slip_prob=0.2)

    # 1. Value Iteration Verification
    print("\n[1] Model-Based Planning: Value Iteration (gamma=0.99):")
    V_vi, pi_vi = value_iteration(env, gamma=0.99)
    print("Optimal State Values and Policy Grid:")
    print_grid_values(V_vi, pi_vi, env)

    # 2. Policy Iteration Verification
    print("\n[2] Model-Based Planning: Policy Iteration:")
    V_pi, pi_pi = policy_iteration(env, gamma=0.99)
    print("Policy Iteration Converged Values and Policy Grid:")
    print_grid_values(V_pi, pi_pi, env)

    # 3. Q-Learning Verification (Model-Free)
    print("\n[3] Model-Free Reinforcement Learning: Tabular Q-Learning:")
    random.seed(42)
    q_agent = QLearningAgent(env, alpha=0.1, gamma=0.99, epsilon=0.2)
    q_agent.train(episodes=3000, start_state=(1, 1))
    pi_q = q_agent.extract_policy()
    V_q = {s: max(q_agent.q_table[s].values()) if not env.is_terminal(s) else env.terminals.get(s, 0.0) for s in env.states}
    print("Q-Learned State Values and Policy Grid:")
    print_grid_values(V_q, pi_q, env)

    print("\n" + "=" * 65)
    print(" All Reinforcement Learning algorithms executed successfully!")
    print("=" * 65)
