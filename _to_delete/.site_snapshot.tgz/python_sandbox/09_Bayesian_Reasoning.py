#!/usr/bin/env python3
"""
09_Bayesian_Reasoning.py — Bayesian Networks & Probabilistic Inference Algorithms
Covers:
  1. Bayesian Network DAG & CPT Representation (BayesNet, BayesNode)
  2. Exact Inference by Enumeration (enumeration_ask) — AIMA Fig 13.11 / 14.9
  3. Exact Inference by Variable Elimination (elimination_ask) — AIMA Fig 13.12 / 14.11
  4. Approximate Inference: Prior Sampling, Rejection Sampling, Likelihood Weighting
  5. Built-in Benchmarks: AIMA Burglar Alarm Network, Medical Diagnostic Test, Wet Grass Network

Run directly:
  python 09_Bayesian_Reasoning.py
"""

from collections import defaultdict
import random


# =============================================================================
# 1. Bayesian Network DAG & CPT Data Structures
# =============================================================================

class BayesNode:
    """
    A single node in a Bayesian Network.
    - var: variable name (str)
    - parents: list of parent variable names
    - cpt: dictionary mapping parent boolean tuples -> P(var=True | parents)
           or a single float for root nodes with no parents.
    """
    def __init__(self, var, parents, cpt):
        self.var = var
        self.parents = [parents] if isinstance(parents, str) else list(parents)
        if isinstance(cpt, (int, float)):
            self.cpt = {(): float(cpt)}
        elif isinstance(cpt, dict):
            norm_cpt = {}
            for k, v in cpt.items():
                if isinstance(k, tuple):
                    norm_cpt[k] = float(v)
                elif isinstance(k, (bool, int, str)):
                    norm_cpt[(k,)] = float(v)
                else:
                    norm_cpt[tuple(k)] = float(v)
            self.cpt = norm_cpt
        else:
            raise ValueError(f"Invalid CPT format for {var}: {cpt}")

    def p(self, value, event):
        """Return P(var=value | parents in event)."""
        parent_vals = tuple(event[p] for p in self.parents)
        p_true = self.cpt.get(parent_vals, self.cpt.get(parent_vals[0] if len(parent_vals) == 1 else parent_vals, 0.5))
        return p_true if value else (1.0 - p_true)

    def sample(self, event):
        """Draw a sample boolean True/False conditioned on parents in event."""
        parent_vals = tuple(event[p] for p in self.parents)
        p_true = self.cpt.get(parent_vals, self.cpt.get(parent_vals[0] if len(parent_vals) == 1 else parent_vals, 0.5))
        return random.random() < p_true

    def __repr__(self):
        return f"BayesNode({self.var}, parents={self.parents})"


class BayesNet:
    """Directed Acyclic Graph of BayesNodes representing a factored joint distribution."""
    def __init__(self, node_specs=None):
        self.nodes = []
        self.variables = []
        self.node_map = {}
        if node_specs:
            for spec in node_specs:
                self.add(spec)

    def add(self, node_spec):
        if isinstance(node_spec, BayesNode):
            node = node_spec
        else:
            var, parents, cpt = node_spec
            node = BayesNode(var, parents, cpt)
        self.nodes.append(node)
        self.variables.append(node.var)
        self.node_map[node.var] = node

    def getNode(self, var):
        return self.node_map.get(var)

    def topological_sort(self):
        return list(self.variables)


# =============================================================================
# 2. Exact Inference by Enumeration (AIMA Fig 13.11 / 14.9)
# =============================================================================

def normalize(dist_dict):
    """Normalize a probability distribution dictionary so values sum to 1.0."""
    total = sum(dist_dict.values())
    if total == 0:
        return {k: 1.0 / len(dist_dict) for k in dist_dict}
    return {k: v / total for k, v in dist_dict.items()}


def enumeration_ask(query, evidence, bn):
    """
    Exact inference by recursive enumeration of all hidden variable assignments.
    Returns normalized distribution dict {True: P(Q=True|e), False: P(Q=False|e)}.
    """
    qx = {}
    for val in (True, False):
        extended_evidence = {**evidence, query: val}
        vars_list = bn.topological_sort()
        qx[val] = enumerate_all(vars_list, extended_evidence, bn)
    return normalize(qx)


def enumerate_all(vars_list, event, bn):
    """Recursive helper for enumeration_ask."""
    if not vars_list:
        return 1.0
    Y = vars_list[0]
    rest = vars_list[1:]
    node = bn.getNode(Y)
    if Y in event:
        return node.p(event[Y], event) * enumerate_all(rest, event, bn)
    else:
        return sum(node.p(y_val, event) * enumerate_all(rest, {**event, Y: y_val}, bn)
                   for y_val in (True, False))


# =============================================================================
# 3. Exact Inference by Variable Elimination (AIMA Fig 13.12 / 14.11)
# =============================================================================

class Factor:
    """A multi-dimensional table representing a factor over variables."""
    def __init__(self, variables, values_dict):
        self.variables = list(variables)
        self.values = dict(values_dict)  # mapping tuple(var_vals) -> prob

    def pointwise_product(self, other):
        """Multiply two factors together, joining on common variables."""
        merged_vars = list(self.variables)
        for v in other.variables:
            if v not in merged_vars:
                merged_vars.append(v)
        
        new_values = {}
        # Enumerate all combinations of merged_vars
        import itertools
        for combo in itertools.product([True, False], repeat=len(merged_vars)):
            assign = dict(zip(merged_vars, combo))
            self_key = tuple(assign[v] for v in self.variables)
            other_key = tuple(assign[v] for v in other.variables)
            v1 = self.values.get(self_key, 0.0)
            v2 = other.values.get(other_key, 0.0)
            new_values[combo] = v1 * v2
        return Factor(merged_vars, new_values)

    def sum_out(self, var):
        """Sum out variable var from this factor."""
        if var not in self.variables:
            return self
        new_vars = [v for v in self.variables if v != var]
        var_idx = self.variables.index(var)
        new_values = defaultdict(float)
        for key, val in self.values.items():
            new_key = tuple(k for i, k in enumerate(key) if i != var_idx)
            new_values[new_key] += val
        return Factor(new_vars, new_values)

    def normalize(self):
        total = sum(self.values.values())
        if total > 0:
            for k in self.values:
                self.values[k] /= total
        return self


def make_factor(node, evidence):
    """Convert a BayesNode into an initial Factor conditioned on evidence."""
    vars_list = [node.var] + node.parents
    relevant_vars = [v for v in vars_list if v not in evidence]
    import itertools
    values = {}
    for combo in itertools.product([True, False], repeat=len(relevant_vars)):
        event = dict(evidence)
        event.update(dict(zip(relevant_vars, combo)))
        var_val = event[node.var]
        p_val = node.p(var_val, event)
        values[combo] = p_val
    return Factor(relevant_vars, values)


def variable_elimination(query, evidence, bn):
    """
    Exact inference using Variable Elimination.
    """
    factors = [make_factor(node, evidence) for node in bn.nodes]
    hidden_vars = [v for v in bn.topological_sort() if v != query and v not in evidence]

    for var in hidden_vars:
        # Find all factors containing var
        var_factors = [f for f in factors if var in f.variables]
        if not var_factors:
            continue
        # Remove them from factors list
        factors = [f for f in factors if var not in f.variables]
        # Multiply them together
        prod = var_factors[0]
        for f in var_factors[1:]:
            prod = prod.pointwise_product(f)
        # Sum out var
        summed = prod.sum_out(var)
        factors.append(summed)

    # Multiply remaining factors
    if not factors:
        return {True: 0.5, False: 0.5}
    res = factors[0]
    for f in factors[1:]:
        res = res.pointwise_product(f)
    res.normalize()
    
    q_idx = res.variables.index(query)
    dist = {}
    for key, val in res.values.items():
        dist[key[q_idx]] = val
    return dist


# =============================================================================
# 4. Approximate Inference Sampling Algorithms
# =============================================================================

def prior_sample(bn):
    """Generate a single random complete event drawn from the joint distribution."""
    event = {}
    for var in bn.topological_sort():
        node = bn.getNode(var)
        event[var] = node.sample(event)
    return event


def rejection_sampling(query, evidence, bn, N=5000):
    """
    Approximate inference by Rejection Sampling (AIMA Fig 13.14 / 14.14).
    Rejects samples that do not match the evidence.
    """
    counts = {True: 0, False: 0}
    accepted = 0
    for _ in range(N):
        sample = prior_sample(bn)
        # Check if sample agrees with evidence
        consistent = all(sample[var] == val for var, val in evidence.items())
        if consistent:
            counts[sample[query]] += 1
            accepted += 1
    if accepted == 0:
        return {True: 0.5, False: 0.5}, 0.0
    return normalize(counts), (accepted / N)


def likelihood_weighting(query, evidence, bn, N=5000):
    """
    Approximate inference by Likelihood Weighting (AIMA Fig 13.16 / 14.15).
    Fixes evidence variables and accumulates sample weights.
    """
    W = {True: 0.0, False: 0.0}
    for _ in range(N):
        event = {}
        w = 1.0
        for var in bn.topological_sort():
            node = bn.getNode(var)
            if var in evidence:
                val = evidence[var]
                event[var] = val
                w *= node.p(val, event)
            else:
                event[var] = node.sample(event)
        W[event[query]] += w
    return normalize(W)


# =============================================================================
# 5. Standard Network Builders & Benchmarks
# =============================================================================

def make_alarm_net():
    """
    Construct classic AIMA Burglar Alarm Bayesian Network.
    Variables: Burglary (B), Earthquake (E), Alarm (A), JohnCalls (J), MaryCalls (M).
    """
    return BayesNet([
        ('Burglary', [], 0.001),
        ('Earthquake', [], 0.002),
        ('Alarm', ['Burglary', 'Earthquake'], {
            (True, True): 0.95,
            (True, False): 0.94,
            (False, True): 0.29,
            (False, False): 0.001
        }),
        ('JohnCalls', ['Alarm'], {
            (True,): 0.90,
            (False,): 0.05
        }),
        ('MaryCalls', ['Alarm'], {
            (True,): 0.70,
            (False,): 0.01
        })
    ])


def make_wet_grass_net():
    """
    Construct classic Wet Grass / Sprinkler / Rain network.
    Cloudy -> Sprinkler, Cloudy -> Rain, (Sprinkler, Rain) -> WetGrass.
    """
    return BayesNet([
        ('Cloudy', [], 0.5),
        ('Sprinkler', ['Cloudy'], {
            (True,): 0.10,
            (False,): 0.50
        }),
        ('Rain', ['Cloudy'], {
            (True,): 0.80,
            (False,): 0.20
        }),
        ('WetGrass', ['Sprinkler', 'Rain'], {
            (True, True): 0.99,
            (True, False): 0.90,
            (False, True): 0.90,
            (False, False): 0.00
        })
    ])


def run_alarm_benchmarks():
    print("\n" + "="*70)
    print("BENCHMARK 1: AIMA Burglar Alarm Network Inferences")
    print("="*70)
    bn = make_alarm_net()

    # Query 1: Diagnostic reasoning P(B | JohnCalls=True, MaryCalls=True)
    evidence = {'JohnCalls': True, 'MaryCalls': True}
    print("Query: P(Burglary | JohnCalls=True, MaryCalls=True)")
    
    exact_enum = enumeration_ask('Burglary', evidence, bn)
    print(f"  Exact (Enumeration)       : P(B=True) = {exact_enum[True]:.4f} ({exact_enum[True]*100:.2f}%)")

    exact_ve = variable_elimination('Burglary', evidence, bn)
    print(f"  Exact (Variable Elim)     : P(B=True) = {exact_ve[True]:.4f} ({exact_ve[True]*100:.2f}%)")
    assert abs(exact_enum[True] - exact_ve[True]) < 1e-5

    # Query 2: Explaining Away reasoning: P(B | Alarm=True) vs P(B | Alarm=True, Earthquake=True)
    p_b_given_a = enumeration_ask('Burglary', {'Alarm': True}, bn)[True]
    p_b_given_ae = enumeration_ask('Burglary', {'Alarm': True, 'Earthquake': True}, bn)[True]
    print(f"\nExplaining Away Analysis:")
    print(f"  P(Burglary | Alarm=True)                    = {p_b_given_a:.4f} ({p_b_given_a*100:.2f}%)")
    print(f"  P(Burglary | Alarm=True, Earthquake=True)   = {p_b_given_ae:.4f} ({p_b_given_ae*100:.2f}%)")
    print("  -> Notice how confirming Earthquake 'explains away' the Alarm and DROPS burglary probability!")
    assert p_b_given_ae < p_b_given_a

    # Sampling comparison:
    print("\n--- Approximate Sampling Benchmark (N=20,000 samples) ---")
    rej_dist, acceptance_rate = rejection_sampling('Burglary', evidence, bn, N=20000)
    print(f"  Rejection Sampling        : P(B=True) = {rej_dist[True]:.4f} (Acceptance rate: {acceptance_rate*100:.2f}%)")
    
    lw_dist = likelihood_weighting('Burglary', evidence, bn, N=20000)
    print(f"  Likelihood Weighting      : P(B=True) = {lw_dist[True]:.4f} (100% samples utilized)")
    print("✓ Burglar alarm benchmarks completed successfully!")


def run_medical_test_benchmark():
    print("\n" + "="*70)
    print("BENCHMARK 2: Medical Diagnostic Test (Bayes' Rule & Counter-Intuition)")
    print("="*70)
    # Rare disease: P(Disease) = 0.01 (1%)
    # Test sensitivity: P(+ | Disease) = 0.95
    # False positive: P(+ | ~Disease) = 0.05
    med_net = BayesNet([
        ('Disease', [], 0.01),
        ('TestResult', ['Disease'], {
            (True,): 0.95,
            (False,): 0.05
        })
    ])
    posterior = enumeration_ask('Disease', {'TestResult': True}, med_net)
    print(f"Prior Disease Prevalence P(Disease)        = 1.0%")
    print(f"Test Accuracy (Sensitivity / Specificity)   = 95.0% / 95.0%")
    print(f"Patient Tests Positive (+)")
    print(f"Actual Posterior Probability P(Disease | +) = {posterior[True]:.4f} ({posterior[True]*100:.2f}%)")
    print("-> Counter-intuitive reveal: Despite 95% accuracy, patient has only ~16.1% chance of disease!")
    assert abs(posterior[True] - 0.1610) < 0.01
    print("✓ Medical diagnostic benchmark verified successfully!")


def run_wet_grass_benchmark():
    print("\n" + "="*70)
    print("BENCHMARK 3: Wet Grass Network & Conditional Independence")
    print("="*70)
    bn = make_wet_grass_net()
    # P(Rain | WetGrass=True)
    p_rain_wet = enumeration_ask('Rain', {'WetGrass': True}, bn)[True]
    # P(Rain | WetGrass=True, Sprinkler=True)
    p_rain_wet_sprink = enumeration_ask('Rain', {'WetGrass': True, 'Sprinkler': True}, bn)[True]
    print(f"P(Rain | WetGrass=True)                  = {p_rain_wet:.4f}")
    print(f"P(Rain | WetGrass=True, Sprinkler=True)  = {p_rain_wet_sprink:.4f}")
    assert p_rain_wet_sprink < p_rain_wet
    print("✓ Wet grass benchmark verified successfully!")


if __name__ == '__main__':
    run_alarm_benchmarks()
    run_medical_test_benchmark()
    run_wet_grass_benchmark()
    print("\n" + "="*70)
    print("ALL BAYESIAN REASONING TESTS PASSED PERFECTLY!")
    print("="*70)
