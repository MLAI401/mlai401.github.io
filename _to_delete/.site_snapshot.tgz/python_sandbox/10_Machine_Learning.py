#!/usr/bin/env python3
"""
MLAI401 — Topic 06: Machine Learning
Standalone zero-dependency Python implementation of foundational ML algorithms:
- Shannon Entropy & Information Gain (ID3)
- Decision Tree Classifier with recursive building and prediction
- Logistic Regression with Sigmoid, Cross-Entropy Loss & Batch Gradient Descent
- K-Means Clustering with K-Means++ initialization and Voronoi partitioning
- Model Evaluation Metrics: Confusion Matrix, Accuracy, Precision, Recall, F1-Score

Can be run directly: python 10_Machine_Learning.py
"""

import math
import random


# ==============================================================================
# 1. Information Theory & Decision Trees
# ==============================================================================

def entropy(y):
    """
    Computes Shannon Entropy H(S) for discrete binary or multi-class labels.
    H(S) = - sum(p_i * log2(p_i))
    """
    if not y:
        return 0.0
    total = len(y)
    counts = {}
    for label in y:
        counts[label] = counts.get(label, 0) + 1
    
    ent = 0.0
    for count in counts.values():
        p = count / total
        if p > 0:
            ent -= p * math.log2(p)
    return ent


def information_gain(X, y, feature_idx, threshold=None):
    """
    Calculates Information Gain IG(S, A) = H(S) - sum(|S_v|/|S| * H(S_v)).
    Supports categorical features (threshold is None) or continuous numeric splits.
    """
    parent_entropy = entropy(y)
    total = len(y)
    if total == 0:
        return 0.0, None

    if threshold is None:
        # Categorical splitting
        values = set(row[feature_idx] for row in X)
        weighted_entropy = 0.0
        subsets = {}
        for val in values:
            subset_y = [y[i] for i, row in enumerate(X) if row[feature_idx] == val]
            subsets[val] = subset_y
            weighted_entropy += (len(subset_y) / total) * entropy(subset_y)
        ig = parent_entropy - weighted_entropy
        return ig, subsets
    else:
        # Numeric binary threshold split
        left_y = [y[i] for i, row in enumerate(X) if row[feature_idx] <= threshold]
        right_y = [y[i] for i, row in enumerate(X) if row[feature_idx] > threshold]
        if not left_y or not right_y:
            return 0.0, None
        weighted_entropy = (len(left_y) / total) * entropy(left_y) + (len(right_y) / total) * entropy(right_y)
        ig = parent_entropy - weighted_entropy
        return ig, (left_y, right_y)


class DecisionNode:
    """Represents a node in a Decision Tree."""
    def __init__(self, feature_idx=None, threshold=None, is_leaf=False, value=None, left=None, right=None, gain=0.0):
        self.feature_idx = feature_idx
        self.threshold = threshold
        self.is_leaf = is_leaf
        self.value = value        # Leaf prediction
        self.left = left          # <= threshold child
        self.right = right        # > threshold child
        self.gain = gain


class DecisionTreeClassifier:
    """
    Recursive Decision Tree classifier with Information Gain splitting.
    """
    def __init__(self, max_depth=3, min_samples_split=2):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.root = None

    def fit(self, X, y):
        self.root = self._build_tree(X, y, depth=0)
        return self

    def _majority_class(self, y):
        if not y:
            return None
        counts = {}
        for label in y:
            counts[label] = counts.get(label, 0) + 1
        return max(counts.items(), key=lambda item: item[1])[0]

    def _best_split(self, X, y):
        best_gain = -1.0
        best_feature = None
        best_thresh = None
        n_features = len(X[0]) if X else 0

        for f_idx in range(n_features):
            values = sorted(set(row[f_idx] for row in X))
            for i in range(len(values) - 1):
                thresh = (values[i] + values[i+1]) / 2.0
                gain, _ = information_gain(X, y, f_idx, thresh)
                if gain > best_gain:
                    best_gain = gain
                    best_feature = f_idx
                    best_thresh = thresh

        return best_feature, best_thresh, best_gain

    def _build_tree(self, X, y, depth):
        # Base cases: pure node, max depth, or insufficient samples
        if len(set(y)) == 1:
            return DecisionNode(is_leaf=True, value=y[0])
        if depth >= self.max_depth or len(y) < self.min_samples_split:
            return DecisionNode(is_leaf=True, value=self._majority_class(y))

        feat_idx, thresh, gain = self._best_split(X, y)
        if gain <= 1e-6 or feat_idx is None:
            return DecisionNode(is_leaf=True, value=self._majority_class(y))

        left_X, left_y, right_X, right_y = [], [], [], []
        for i, row in enumerate(X):
            if row[feat_idx] <= thresh:
                left_X.append(row)
                left_y.append(y[i])
            else:
                right_X.append(row)
                right_y.append(y[i])

        left_child = self._build_tree(left_X, left_y, depth + 1)
        right_child = self._build_tree(right_X, right_y, depth + 1)

        return DecisionNode(feature_idx=feat_idx, threshold=thresh, left=left_child, right=right_child, gain=gain)

    def predict_one(self, x):
        curr = self.root
        while not curr.is_leaf:
            if x[curr.feature_idx] <= curr.threshold:
                curr = curr.left
            else:
                curr = curr.right
        return curr.value

    def predict(self, X):
        return [self.predict_one(row) for row in X]

    def print_tree(self, node=None, indent=""):
        if node is None:
            node = self.root
        if node.is_leaf:
            print(f"{indent}-> Predict: Class {node.value}")
            return
        print(f"{indent}[Feature x{node.feature_idx} <= {node.threshold:.2f}] (IG: {node.gain:.3f})")
        print(f"{indent}  |-- True:")
        self.print_tree(node.left, indent + "  |   ")
        print(f"{indent}  \\-- False:")
        self.print_tree(node.right, indent + "      ")


# ==============================================================================
# 2. Linear Models & Logistic Regression
# ==============================================================================

def sigmoid(z):
    """Numerically stable sigmoid activation function."""
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    else:
        exp_z = math.exp(z)
        return exp_z / (1.0 + exp_z)


class LogisticRegression:
    """
    Binary Logistic Regression classifier trained via Batch Gradient Descent.
    h_w(x) = sigmoid(w^T x + b)
    """
    def __init__(self, lr=0.1, epochs=100, lambda_reg=0.0):
        self.lr = lr
        self.epochs = epochs
        self.lambda_reg = lambda_reg
        self.weights = []
        self.bias = 0.0
        self.loss_history = []

    def fit(self, X, y):
        n_samples = len(X)
        n_features = len(X[0])
        self.weights = [0.0] * n_features
        self.bias = 0.0
        self.loss_history = []

        for epoch in range(self.epochs):
            # Forward pass: predictions & loss
            dw = [0.0] * n_features
            db = 0.0
            total_loss = 0.0

            for i in range(n_samples):
                # Linear logit z = w^T x + b
                z = sum(w * x for w, x in zip(self.weights, X[i])) + self.bias
                y_hat = sigmoid(z)
                err = y_hat - y[i]

                # Accumulate gradients
                for j in range(n_features):
                    dw[j] += err * X[i][j]
                db += err

                # Cross-entropy loss
                eps = 1e-15
                y_hat_c = max(eps, min(1.0 - eps, y_hat))
                loss_i = -(y[i] * math.log(y_hat_c) + (1.0 - y[i]) * math.log(1.0 - y_hat_c))
                total_loss += loss_i

            # Average gradients and apply L2 regularization
            avg_loss = (total_loss / n_samples) + 0.5 * self.lambda_reg * sum(w**2 for w in self.weights)
            self.loss_history.append(avg_loss)

            for j in range(n_features):
                grad_j = (dw[j] / n_samples) + self.lambda_reg * self.weights[j]
                self.weights[j] -= self.lr * grad_j
            self.bias -= self.lr * (db / n_samples)

        return self

    def predict_proba(self, X):
        probs = []
        for row in X:
            z = sum(w * x for w, x in zip(self.weights, row)) + self.bias
            probs.append(sigmoid(z))
        return probs

    def predict(self, X, threshold=0.5):
        return [1 if p >= threshold else 0 for p in self.predict_proba(X)]


# ==============================================================================
# 3. Unsupervised K-Means Clustering
# ==============================================================================

def euclidean_distance(p1, p2):
    return math.sqrt(sum((a - b)**2 for a, b in zip(p1, p2)))


class KMeans:
    """
    K-Means clustering with K-Means++ initialization and Voronoi assignment.
    """
    def __init__(self, k=3, max_iter=30, init_method="kmeans++", random_state=42):
        self.k = k
        self.max_iter = max_iter
        self.init_method = init_method
        self.random_state = random_state
        self.centroids = []
        self.labels = []
        self.inertia_ = 0.0  # WCSS

    def _init_centroids(self, X):
        random.seed(self.random_state)
        n_samples = len(X)
        if self.init_method == "kmeans++":
            # Pick first centroid uniformly at random
            centroids = [list(random.choice(X))]
            while len(centroids) < self.k:
                # Compute distance from each point to nearest chosen centroid
                dists_sq = []
                for row in X:
                    min_d = min(euclidean_distance(row, c)**2 for c in centroids)
                    dists_sq.append(min_d)
                total_dist = sum(dists_sq)
                if total_dist == 0:
                    centroids.append(list(random.choice(X)))
                    continue
                # Pick next centroid proportionally to D(x)^2
                r = random.random() * total_dist
                cum = 0.0
                for i, d in enumerate(dists_sq):
                    cum += d
                    if cum >= r:
                        centroids.append(list(X[i]))
                        break
            return centroids
        else:
            return [list(pt) for pt in random.sample(X, self.k)]

    def fit(self, X):
        self.centroids = self._init_centroids(X)
        n_samples = len(X)
        n_features = len(X[0])

        for it in range(self.max_iter):
            # Assignment Step: assign points to nearest centroid
            self.labels = []
            for row in X:
                nearest_k = 0
                min_d = float('inf')
                for k_idx, c in enumerate(self.centroids):
                    d = euclidean_distance(row, c)
                    if d < min_d:
                        min_d = d
                        nearest_k = k_idx
                self.labels.append(nearest_k)

            # Update Step: recalculate centroids
            new_centroids = [[0.0] * n_features for _ in range(self.k)]
            counts = [0] * self.k
            for i, row in enumerate(X):
                cluster_k = self.labels[i]
                counts[cluster_k] += 1
                for j in range(n_features):
                    new_centroids[cluster_k][j] += row[j]

            # Shift centroids
            shifted = False
            for k_idx in range(self.k):
                if counts[k_idx] > 0:
                    for j in range(n_features):
                        new_val = new_centroids[k_idx][j] / counts[k_idx]
                        if abs(new_val - self.centroids[k_idx][j]) > 1e-4:
                            shifted = True
                        self.centroids[k_idx][j] = new_val
                else:
                    # Re-seed empty cluster
                    self.centroids[k_idx] = list(random.choice(X))
                    shifted = True

            if not shifted:
                break

        # Compute inertia (Within-Cluster Sum of Squares)
        self.inertia_ = sum(euclidean_distance(X[i], self.centroids[self.labels[i]])**2 for i in range(n_samples))
        return self


# ==============================================================================
# 4. Evaluation Metrics
# ==============================================================================

def train_test_split(X, y, test_ratio=0.25, seed=42):
    random.seed(seed)
    indices = list(range(len(X)))
    random.shuffle(indices)
    split_idx = int(len(X) * (1.0 - test_ratio))
    train_idx, test_idx = indices[:split_idx], indices[split_idx:]
    X_train = [X[i] for i in train_idx]
    y_train = [y[i] for i in train_idx]
    X_test = [X[i] for i in test_idx]
    y_test = [y[i] for i in test_idx]
    return X_train, X_test, y_train, y_test


def evaluate_metrics(y_true, y_pred):
    """
    Computes Confusion Matrix, Accuracy, Precision, Recall, and F1-Score for binary labels.
    """
    tp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 1)
    tn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 0)
    fp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 1)
    fn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 0)

    total = len(y_true)
    acc = (tp + tn) / total if total > 0 else 0.0
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * (prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0

    return {
        "confusion_matrix": {"TP": tp, "FP": fp, "FN": fn, "TN": tn},
        "accuracy": acc,
        "precision": prec,
        "recall": rec,
        "f1_score": f1
    }


# ==============================================================================
# 5. Standalone Execution & Verification
# ==============================================================================

if __name__ == "__main__":
    print("=" * 65)
    print(" MLAI401 — Topic 06: Machine Learning Algorithms Verification")
    print("=" * 65)

    # 1. Decision Tree Verification on Synthetic Loan/Medical Data
    print("\n[1] Decision Tree Classifier:")
    # Features: [Age, Income_k, Debt_Ratio]
    X_loan = [
        [25, 30, 0.4], [30, 60, 0.2], [45, 80, 0.1], [22, 20, 0.6],
        [35, 75, 0.3], [50, 40, 0.5], [23, 25, 0.5], [40, 90, 0.2],
        [60, 50, 0.3], [28, 45, 0.4], [33, 85, 0.1], [55, 35, 0.7]
    ]
    # Label: 1 = Approve, 0 = Deny
    y_loan = [0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0]

    tree = DecisionTreeClassifier(max_depth=3)
    tree.fit(X_loan, y_loan)
    print("Learned Tree Structure:")
    tree.print_tree()
    preds_tree = tree.predict(X_loan)
    metrics_tree = evaluate_metrics(y_loan, preds_tree)
    print(f"Training Accuracy: {metrics_tree['accuracy']*100:.1f}% | F1: {metrics_tree['f1_score']:.3f}")

    # 2. Logistic Regression Verification
    print("\n[2] Logistic Regression Classifier:")
    X_train, X_test, y_train, y_test = train_test_split(X_loan, y_loan, test_ratio=0.3, seed=42)
    log_reg = LogisticRegression(lr=0.05, epochs=150, lambda_reg=0.01)
    log_reg.fit(X_train, y_train)
    test_preds = log_reg.predict(X_test)
    metrics_lr = evaluate_metrics(y_test, test_preds)
    print(f"Learned Weights: {[round(w, 3) for w in log_reg.weights]}, Bias: {log_reg.bias:.3f}")
    print(f"Test Accuracy: {metrics_lr['accuracy']*100:.1f}% | Metrics: {metrics_lr['confusion_matrix']}")

    # 3. K-Means Clustering Verification
    print("\n[3] K-Means Clustering (K=3):")
    X_cluster = [
        [1.0, 2.0], [1.5, 1.8], [5.0, 8.0], [8.0, 8.0],
        [1.0, 0.6], [9.0, 11.0], [8.0, 2.0], [10.0, 2.0], [9.0, 3.0]
    ]
    kmeans = KMeans(k=3, init_method="kmeans++", random_state=42)
    kmeans.fit(X_cluster)
    print(f"Final Centroids: {[[round(v, 2) for v in c] for c in kmeans.centroids]}")
    print(f"Cluster Assignments: {kmeans.labels}")
    print(f"Within-Cluster Sum of Squares (WCSS / Inertia): {kmeans.inertia_:.2f}")

    print("\n" + "=" * 65)
    print(" All Machine Learning algorithms executed successfully!")
    print("=" * 65)
